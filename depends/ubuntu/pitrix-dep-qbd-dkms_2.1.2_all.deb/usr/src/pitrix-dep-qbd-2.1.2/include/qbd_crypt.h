#ifndef _QBD_CRYPT_H
#define _QBD_CRYPT_H
/*
 * Encrypt keyid and passphrass in simple way to store them in 'encrypted' text,
 * when remap volume with open_volume_common, we have to decrpyt to plain text,
 * so if someone hack in, it will be always unsafe.
 * There is no need to use enhanced cryption algorithm unless neonsan lib redesigned.
 */

static inline void qbd_encrypt(const char *plain, char *crypt, int length)
{
	int i;
	for (i = 0; i < length; i++)
		crypt[i] = plain[i] + 1;
}

static inline void qbd_decrypt(const char *crypt, char *plain, int length)
{
	int i;
	for (i = 0; i < length; i++)
		plain[i] = crypt[i] - 1;
}

#endif
