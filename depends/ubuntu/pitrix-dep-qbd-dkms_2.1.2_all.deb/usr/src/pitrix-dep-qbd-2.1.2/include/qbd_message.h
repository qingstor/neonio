#ifndef _QBD_MESSAGE_H
#define _QBD_MESSAGE_H

#include <linux/types.h>

#define PROTOCOL_VER 1

/* Defination of opcode should be the same with store */
enum QBD_OPCODE {
	QBD_OP_UNKNOWN = 0x0,
	QBD_OP_WRITE = 0x01,
	QBD_OP_READ = 0x02,
	QBD_OP_HEARTBEAT = 0x86,
	QBD_OP_MAX,
};

/* TCP transfer protocol message defined by NeonSan Server */
#pragma pack(1)
struct qbd_command {
	__u8 opcode;
	__u8 flags;
	__le16 command_id;
	__le32 snap_seq;
	__le64 vol_id;
	__le64 client_send_time;
	__le64 buf_addr;
	__le32 rkey;
	__le32 buf_len;
	__le64 slba;
	__le16 nlba;
	__le16 meta_ver;
	__le32 dsmgmt;
	__le32 reftag;
	__le16 apptag;
	__le16 appmask;
};

enum CompleteStatus {
	QBD_SC_SUCCESS = 0x0,
	QBD_SC_INVALID_OPCODE = 0x1,
	QBD_SC_INVALID_FIELD = 0x2,
	QBD_SC_CMDID_CONFLICT = 0x3,
	QBD_SC_DATA_XFER_ERROR = 0x4,
	QBD_SC_POWER_LOSS = 0x5,
	QBD_SC_INTERNAL = 0x6,
	QBD_SC_ABORT_REQ = 0x7,
	QBD_SC_LBA_RANGE = 0x80,
	QBD_SC_NS_NOT_READY = 0x82,
	QBD_SC_NOT_PRIMARY = 0xC0,
	QBD_SC_NOSPACE = 0xC1,
	QBD_SC_READONLY = 0xC2,
	QBD_SC_CONN_LOST = 0xC3,
	QBD_SC_AIOERROR = 0xC4,
	QBD_SC_ERROR_HANDLED = 0xC5,
	QBD_SC_ERROR_UNRECOVERABLE = 0xC6,
	QBD_SC_AIO_TIMEOUT = 0xC7,
	QBD_SC_REPLICATING_TIMEOUT = 0xC8,
	QBD_SC_NODE_LOST = 0xC9,
	QBD_SC_LOGFAILED = 0xCA,
	QBD_SC_METRO_REPLICATING_FAILED = 0xCB,

	QBD_SC_DEGRADE = 0x2000,
	QBD_SC_REOPEN = 0x4000,
	QBD_SC_RETRY = 0x8000,
};

struct qbd_completion {
	__le32 srv_time;
	__le32 task_sequence;
	__le16 meta_ver;
	__le16 sq_id;	/* submission queue that generated this entry */
	__le16 command_id;	/* of the command which completed */
	__le16 status;	/* did the command fail, and if so, why? */
	__le64 client_to_server_trans;	/* The transport time from client server request */
	__le64 server_send_time;	/* The completion send time from server */
};

struct handshake {
        short recfmt;
        union {
                short qid;
                short crqsize;
        };
        short hrqsize;
        short hsqsize;
        uint64_t vol_id;
        int snap_seq;
        short protocol_ver;
        short hs_result;
        uint32_t io_timeout;
        uint64_t rsv3;
};

#pragma pack()

#endif
