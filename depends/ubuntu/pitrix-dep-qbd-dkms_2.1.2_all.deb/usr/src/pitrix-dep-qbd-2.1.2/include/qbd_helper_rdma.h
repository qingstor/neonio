#ifndef _QBD_HELPER_RDMA_H
#define _QBD_HELPER_RDMA_H

#include <rdma/ib_cm.h>
#include <rdma/ib_verbs.h>
#include <rdma/rdma_cm.h>
#include <net/sock.h>
#include "linux/timer_compat.h"

#define QBD_RDMA_MAX_WC	8
struct iotask_rdma;
struct iocmpl_rdma;
struct qbd_conn;

typedef enum {
	DESC_IOTASK = 0,
	DESC_IOCMPL,
} DESC_TYPE;

struct qbd_rdma {
	struct rdma_cm_id *cm_id;
	struct completion cm_done;
	struct timer_list rdma_connect_timer; /* rdma_connect timer */
	enum {
		QBD_RDMA_STATE_INIT,
		QBD_RDMA_STATE_ADDR_RESOLVED,
		QBD_RDMA_STATE_ROUTE_RESOLVED,
		QBD_RDMA_STATE_CONNECTED,
		QBD_RDMA_STATE_CONNECT_FAILED,
		QBD_RDMA_STATE_RETRY,
		QBD_RDMA_STATE_FLUSHING,
		QBD_RDMA_STATE_CLOSING,
		QBD_RDMA_STATE_CLOSED,
	} state;
	struct ib_pd *pd;
	struct ib_qp *qp;
	struct ib_cq *cq;
	struct qbd_conn *conn;

	/* rdma status counter */
	uint64_t post_send_count;
	uint64_t post_recv_count;
	uint64_t cmpl_send_count;
	uint64_t cmpl_recv_count;

	int max_io_depth;
};

int rdma_open(struct qbd_conn *conn, struct sockaddr_in *addr, int conn_timeout);
int rdma_close(struct qbd_conn *conn);
int rdma_post_recv_completion(struct qbd_conn *conn, struct iocmpl_rdma *iocmpl);
int rdma_post_send_command(struct qbd_conn *conn, struct iotask_rdma *iotask);

#endif
