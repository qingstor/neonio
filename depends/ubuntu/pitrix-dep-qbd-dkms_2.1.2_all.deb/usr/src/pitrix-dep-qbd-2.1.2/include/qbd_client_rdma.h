#ifndef _QBD_CLIENT_RDMA_H
#define _QBD_CLIENT_RDMA_H

#include "qbd_client.h"
#include "qbd_iotask_rdma.h"
#include "qbd_iocmpl_rdma.h"

struct qbd_client_rdma {
	struct qbd_volume *vol;
	struct qbd_conn_pool conn_pool;
	struct qbd_iotask_pool_rdma iotask_pool;
	struct qbd_iocmpl_pool_rdma iocmpl_pool;

	struct task_struct *snd_thread;		/* send io requests to store */
	struct task_struct *cmpl_thread;	/* handle rcved io requests from store */
	struct task_struct *watchdog_thread;	/* check iotask timeout */

	struct queue snd_queue;	/* io requests waiting for send */
	struct queue rty_queue;	/* io requests waiting for retry send */
	struct queue cmpl_queue;/* io requests waiting for being handled */
	atomic_t sending_iotask_count;

	struct mutex snd_lock;	/* hold when send io requests to store */
	spinlock_t cmpl_lock;	/* protect cmpl_queue and cmpl_send/recv_count when conn failed */
	struct completion snd_completion;	/* all send out io session has enqueued qs_queue */
	struct completion rty_completion;	/* all failed io requests has enqueued rty_queue */

	struct qbd_tc_info tc;
	unsigned long status;
};

#endif
