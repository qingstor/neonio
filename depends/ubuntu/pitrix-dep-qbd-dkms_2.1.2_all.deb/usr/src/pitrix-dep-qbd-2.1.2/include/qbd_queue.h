#ifndef _QBD_QUEUE_H
#define _QBD_QUEUE_H

#include <linux/spinlock.h>

struct queue {
	void **data;
	int length;
	int space;
	int head;
	int tail;
	spinlock_t lock;
};

int init_queue(struct queue *queue, int length);
void destroy_queue(struct queue *queue);
int __enqueue(struct queue *queue, void *element);
void *__dequeue(struct queue *queue);

static inline int enqueue(struct queue *queue, void *element)
{
	unsigned long flags;
	int ret;

	spin_lock_irqsave(&queue->lock, flags);
	ret = __enqueue(queue, element);
	spin_unlock_irqrestore(&queue->lock, flags);
	return ret;
}

static inline void *dequeue(struct queue *queue)
{
	unsigned long flags;
	void *t;

	spin_lock_irqsave(&queue->lock, flags);
	t = __dequeue(queue);
	spin_unlock_irqrestore(&queue->lock, flags);
	return t;
}

static inline void swap_queue(struct queue *q1, struct queue *q2)
{
	struct queue tmp = *q1;

	q1->data	= q2->data;
	q1->length	= q2->length;
	q1->space	= q2->space;
	q1->head	= q2->head;
	q1->tail	= q2->tail;

	q2->data	= tmp.data;
	q2->length	= tmp.length;
	q2->space	= tmp.space;
	q2->head	= tmp.head;
	q2->tail	= tmp.tail;
}

#define queue_is_empty(queue)	((queue)->space == (queue)->length)
#define queue_is_full(queue)	((queue)->space == 0)

#endif
