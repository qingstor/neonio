#ifndef _QBD_PROC_FS_H
#define _QBD_PROC_FS_H

int qbd_procfs_init(void);
void qbd_procfs_cleanup(void);

#endif
