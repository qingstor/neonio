#ifndef _QBD_SYS_FS_H
#define _QBD_SYS_FS_H

#include <linux/sysfs.h>
#include <linux/genhd.h>

struct qbd_delay_info {
	uint64_t rrange;
	uint64_t lrange;

	atomic64_t send_io_count;
	atomic64_t recv_io_count;
	atomic64_t finish_io_count;

	struct list_head node;
};

struct qbd_device;

#define QBD_DELAY_RANGE_NO_RBOUND UINT64_MAX
extern const struct attribute_group *qbd_attr_groups[];

int qbd_shards_group_create(struct qbd_device *qbd);
void qbd_shards_group_destroy(struct qbd_device *qbd);

int qbd_delay_info_init(struct qbd_device *qbd);
void qbd_delay_info_destroy(struct qbd_device *qbd);

void qbd_delay_send_summarize(struct qbd_device *qbd, uint64_t delay);
void qbd_delay_recv_summarize(struct qbd_device *qbd, uint64_t delay);
void qbd_delay_finish_summarize(struct qbd_device *qbd, uint64_t delay);

#endif
