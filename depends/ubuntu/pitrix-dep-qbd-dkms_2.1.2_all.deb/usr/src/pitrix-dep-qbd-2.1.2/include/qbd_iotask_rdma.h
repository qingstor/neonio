#ifndef _QBD_IOTASK_RDMA_H
#define _QBD_IOTASK_RDMA_H

#include "qbd_queue.h"
#include "qbd_message.h"
#include "qbd_conn.h"
#include "qbd_helper_rdma.h"
#include "qbd_conn_rdma.h"

struct iotask_rdma {
	DESC_TYPE type;
	struct qbd_volume *vol;
	struct qbd_conn *conn;
	void *buf_addr;
	ulp_io_handler ulp_handler;
	void *ulp_arg;
	int status;

	uint64_t ts_post;	/* iotask is ready for ib_post_send timestamp */
	bool snd_processing;	/* iotask post_send is processing */
	bool io_processing;	/* io is processing, in failed case,
				 * io_processing may set to false before iocmpl->rcv_processing is being set
				 */

	/* iotask buffer */
	struct qbd_command *cmd;
	void *block;
};

struct qbd_iotask_pool_rdma {
	int size;
	int nr_alloced;
	struct queue free_list;
	struct iotask_rdma *iotasks;

	/* virtual memroy buffer */
	struct qbd_command *cmd_buf;
	void **block_buf;
	rwlock_t walk_lock; /* walk pool with read_lock, and resize pool with write_lock in case that
			     * invalid memory will be accessed when walk pool.
			     */
};

int qbd_init_iotask_pool_rdma(struct qbd_iotask_pool_rdma *pool, int pool_size, int blocksize);
void qbd_release_iotask_pool_rdma(struct qbd_iotask_pool_rdma *pool, int block_size);

struct qbd_client_rdma;
void qbd_replace_snd_queue_rdma(struct qbd_client_rdma *client, struct queue *new);
void qbd_replace_rty_queue_rdma(struct qbd_client_rdma *client, struct queue *new);
void qbd_replace_cmpl_queue_rdma(struct qbd_client_rdma *client, struct queue *new);
void qbd_replace_iotask_pool_rdma(struct qbd_client_rdma *client, struct qbd_iotask_pool_rdma *new);

struct iotask_rdma *qbd_alloc_iotask_rdma(struct qbd_iotask_pool_rdma *pool);
void qbd_free_iotask_rdma(struct qbd_iotask_pool_rdma *pool, struct iotask_rdma *iotask);

static inline struct iotask_rdma *qbd_pick_iotask_rdma(struct qbd_iotask_pool_rdma *pool, int id)
{
	if (likely(id < pool->size))
		return &pool->iotasks[id];
	else
		return NULL;
}

static inline int get_iodepth_by_pool_size_rdma(int pool_size)
{
	return pool_size;
}

static inline int get_pool_size_by_iodepth_rdma(int iodepth)
{
	return iodepth;
}

#endif
