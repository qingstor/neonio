#ifndef _QBD_CONN_H
#define _QBD_CONN_H

#include "qbd.h"
#include "qbd_message.h"
#include "qbd_conn_tcp.h"

/* if add more qbd_conn_status, qbd_conn_status_char and qbd_shard_show needs update */
enum qbd_conn_status {
	CONN_STATUS_UNKNOWN = 0,
	CONN_STATUS_CONNECTED,
	CONN_STATUS_CLOSING,
	CONN_STATUS_CLOSED,
	CONN_STATUS_FAILED,
	CONN_STATUS_LAST
};
extern const char *qbd_conn_status_char;

struct qbd_rdma;
struct ib_mr;
struct qbd_conn {
	struct qbd_volume *vol;
	enum qbd_conn_status status;
	struct sockaddr_in addr;
	union {
		struct socket *skt;
		struct {
			struct qbd_rdma *rdma;
			/* dma address buffer */
			u64 *cmd_dbuf;
			u64 *cmpl_dbuf;
			u64 *block_dbuf;
			/* rdma connection mr */
			struct ib_mr *mr;
		};
	};
	struct timer_list hb_timer; /* heartbeat timer */
	int shard;		    /* used by headbeat, record the shard which setup this connection */
	uint64_t last_send_time;    /* the last time that send data to store */
};

struct qbd_conn_pool {
	struct sockaddr_hashtable *conn_table;
	struct qbd_volume *vol;
};

int init_conn_pool(struct qbd_conn_pool *pool, struct qbd_volume *vol);
void release_conn_pool(struct qbd_conn_pool *pool);
void cleanup_conn_pool(struct qbd_conn_pool *pool);

int qbd_init_conn(struct qbd_conn *conn, struct qbd_volume *vol, struct sockaddr_in *addr);
void qbd_release_conn(struct qbd_conn *conn);
void _qbd_release_conn(struct qbd_conn *conn);

struct qbd_conn *qbd_get_shard_conn(struct qbd_volume *vol, struct qbd_conn_pool *conn_pool, int shard_index);
char qbd_conn_status_to_char(struct qbd_conn_pool *pool, struct sockaddr_in *addr);

#endif
