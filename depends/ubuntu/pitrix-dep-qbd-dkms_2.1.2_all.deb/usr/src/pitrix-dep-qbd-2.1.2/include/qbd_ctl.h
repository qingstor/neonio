#ifndef _QBD_CTL_H
#define _QBD_CTL_H
#include "qbd_device.h"

int qbd_ctl_init(void);
void qbd_ctl_cleanup(void);

static inline int qbd_device_removing_test_and_set(struct qbd_device *qbd)
{
	int ret = 0;
	spin_lock_irq(&qbd->lock);
	if (qbd->open_count)
		ret = -EBUSY;
	else if (test_and_set_bit(QBD_DEV_FLAG_REMOVING, &qbd->flags))
		ret = -ENOENT;
	spin_unlock_irq(&qbd->lock);
	return ret;
}

static inline int qbd_device_get(struct qbd_device *qbd)
{
	return -EINVAL;
}

static inline int qbd_device_try_get(struct qbd_device *qbd)
{
	int ret = 0;
	spin_lock_irq(&qbd->lock);
	if (test_bit(QBD_DEV_FLAG_REMOVING, &qbd->flags)) {
		ret = -ENOENT;
		goto out_unlock;
	}
	else
		qbd->open_count++;
out_unlock:
	spin_unlock_irq(&qbd->lock);
	return ret;
}

static inline void qbd_device_put(struct qbd_device *qbd)
{
	spin_lock_irq(&qbd->lock);
	qbd->open_count--;
	spin_unlock_irq(&qbd->lock);
	BUG_ON(qbd->open_count < 0);
}

#endif
