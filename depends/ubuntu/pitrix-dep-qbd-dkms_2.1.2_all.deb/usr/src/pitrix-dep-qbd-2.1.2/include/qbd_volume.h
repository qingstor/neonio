#ifndef _QBD_VOLUME_H
#define _QBD_VOLUME_H

#include "qbd_qos.h"

/*
 * this file defines the qbd_volume struct and its' relative definings, and it
 * can be included in the qbd utils (work in user-space) and the qbd kernel
 * modules (work in kernel-space).
 */

#define QBD_VOLUME_MAX          (128)
#define QBD_SNAP_MAX            (128)
#define QBD_CRYPT_MAX		(1024)

enum {
	THROTTLE_SET_NONE = -1,
	THROTTLE_SET_READ_BPS = 0,
	THROTTLE_SET_WRITE_BPS,
	THROTTLE_SET_READ_IOPS,
	THROTTLE_SET_WRITE_IOPS,
	THROTTLE_SET_MAX_NUM,
};
struct qbd_throttle {
        uint64_t value[THROTTLE_SET_MAX_NUM];
};

enum volume_status {
	VOLUME_STATUS_CLOSED = 0,
	VOLUME_STATUS_OPENED,
	VOLUME_STATUS_RESETTING,
	VOLUME_STATUS_ERROR,
};

#ifdef _KERNEL
/* the transport_type must be same with neonsan client */
enum transport_type {
	RDMA = 0,
	TCP = 1,
};
#endif

/*
 * qbd_client_shard will be copied from userspace returned from store,
 * this structure is defined by store.
 */
struct qbd_conn;
struct qbd_client_shard {
	int index;		/* shard index in volume */
	uint64_t id;		/* shard id, := volume_id | (index << 4) */
	struct sockaddr_in ips[16];	/* support at most 16 IPs each shard */
	int current_ip;		/* current ip which the shard using */
	struct qbd_conn *conn;	/* not used in kernel driver */
};

struct qbd_device;
struct qbd_client_operations;
/*
 * this struct is copied between user-space and kernel-space through ioctl, so
 * do not add new members into it in case for unneeded memory coping, unless
 * them are necessary.
 */
struct qbd_volume {
	uint64_t id;		/* volume id */
	uint64_t meta_ver;	/* meta version */
	char name[QBD_VOLUME_MAX];	/* volume name */
	char snap_name[QBD_SNAP_MAX];	/* snapshot name */
	char cfg_file[PATH_MAX + 1];
	size_t size;		/* volume size in bytes */
	uint64_t objsize;
	int snap_seq;
	int max_blocksize;	/* maximum block size in single IO request */
	int max_io_depth;
	int tcp_no_delay;	/* XXX, should be TCP client member only, will fix later */
	int io_timeout;
	int conn_timeout;
	enum transport_type type;
	enum volume_status status;
	unsigned long resume_type;     /* volume is resumed to error state */
	int legacy_protocol;

	int shard_count;
	struct qbd_client_shard *shards;	/* an array of qbd_shard */
	struct qbd_throttle throttle;		/* throttle information */
	struct qbd_qos_info qos;

	char keyid[QBD_CRYPT_MAX + 1];
	char passphrass[QBD_CRYPT_MAX + 1];

	unsigned long __user_end__; /* the end of user-volume */
#ifdef _KERNEL
	/* the following member only used in kernel space */
	struct qbd_client_operations *cops;
	void *client;		/* transport client information */
	uint64_t open_ts;	/* open/reopen timestamp */
	struct qbd_device *qbd;
#endif
};

#define USER_VOLUME_COPY_SIZE (offsetof(struct qbd_volume, __user_end__))

#endif
