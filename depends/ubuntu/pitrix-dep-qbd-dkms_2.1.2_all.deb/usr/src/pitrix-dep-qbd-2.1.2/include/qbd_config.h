/* include/qbd_config.h.  Generated from qbd_config.h.in by configure.  */
/* include/qbd_config.h.in.  Generated from configure.ac by autoheader.  */

/* blk_queue_io_opt() is available */
#define HAVE_BLK_QUEUE_IO_OPT 1

/* blk_queue_max_hw_sectors() is available */
#define HAVE_BLK_QUEUE_MAX_HW_SECTORS 1

/* blk_queue_max_segments() is available */
#define HAVE_BLK_QUEUE_MAX_SEGMENTS 1

/* blk_queue_physical_block_size() is available */
#define HAVE_BLK_QUEUE_PHYSICAL_BLOCK_SIZE 1

/* blk_rq_bytes() is available */
#define HAVE_BLK_RQ_BYTES 1

/* blk_rq_bytes() is GPL-only */
/* #undef HAVE_BLK_RQ_BYTES_GPL_ONLY */

/* blk_rq_pos() is available */
#define HAVE_BLK_RQ_POS 1

/* blk_rq_sectors() is available */
#define HAVE_BLK_RQ_SECTORS 1

/* blk_status_t exists */
#define HAVE_BLK_STATUS_T 1

/* errno_to_blk_status exists */
#define HAVE_ERRNO_TO_BLK_STATUS 1

/* hashtable.h exists */
#define HAVE_HASHTABLE_HEADER 1

/* hlist_for_each_entry() require 3 arguments */
#define HAVE_HLIST_FOR_EACH_ENTRY_3_PARAMS 1

/* Define to 1 if you have the <inttypes.h> header file. */
#define HAVE_INTTYPES_H 1

/* alloc_workqueue() is available */
#define HAVE_KERNEL_ALLOC_WORKQUEUE 1

/* blk single queue is available */
#define HAVE_KERNEL_BLK_SINGLE_QUEUE 1

/* block_device_operations.release() is void */
#define HAVE_KERNEL_BLOCK_DEVICE_OPERATIONS_RELEASE_VOID 1

/* kernel_setsockopt() is available */
#define HAVE_KERNEL_KERNEL_SETSOCKOPT 1

/* ktime_get_raw_ts64() is available */
/* #undef HAVE_KERNEL_KTIME_GET_RAW_TS64 */

/* kvfree() is available */
#define HAVE_KERNEL_KVFREE 1

/* kvmalloc() is available */
#define HAVE_KERNEL_KVMALLOC 1

/* memalloc_noreclaim_save/restore is available */
#define HAVE_KERNEL_MEMALLOC_NORECLAIM 1

/* struct proc_ops is available */
/* #undef HAVE_KERNEL_PROC_OPS */

/* ___ratelimit() is available */
#define HAVE_KERNEL_RATELIMIT_FUN_PARM 1

/* ratelimit_state_init() is available */
#define HAVE_KERNEL_RATELIMIT_INIT 1

/* struct ratelimit_state has spinlock member */
#define HAVE_KERNEL_RATELIMIT_SPINLOCK 1

/* struct __kernel_sock_timeval is available */
/* #undef HAVE_KERNEL_SOCK_TIMEVAL */

/* timer_list.funciton gets a timer_list */
#define HAVE_KERNEL_TIMER_FUNCTION_TIMER_LIST 1

/* Define to 1 if you have the `:libneonsan_tcp_client.a' library
   (-l:libneonsan_tcp_client.a). */
/* #undef HAVE_LIB_LIBNEONSAN_TCP_CLIENT_A */

/* Define to 1 if you have the <memory.h> header file. */
#define HAVE_MEMORY_H 1

/* Define if you have NeonSanLib */
/* #undef HAVE_NEONSANLIB */

/* ib_get_dma_mr() is available */
#define HAVE_RDMA_IB_GET_DMA_MR 1

/* ib_query_device() is available */
/* #undef HAVE_RDMA_IB_QUERY_DEVICE */

/* rq_for_each_segment() is available */
#define HAVE_RQ_FOR_EACH_SEGMENT 1

/* rq_for_each_segment() wants bio_vec */
#define HAVE_RQ_FOR_EACH_SEGMENT_BV 1

/* rq_for_each_segment() wants bio_vec * */
/* #undef HAVE_RQ_FOR_EACH_SEGMENT_BVP */

/* Define to 1 if you have the <stdint.h> header file. */
#define HAVE_STDINT_H 1

/* Define to 1 if you have the <stdlib.h> header file. */
#define HAVE_STDLIB_H 1

/* Define to 1 if you have the <strings.h> header file. */
#define HAVE_STRINGS_H 1

/* Define to 1 if you have the <string.h> header file. */
#define HAVE_STRING_H 1

/* Define to 1 if you have the <sys/stat.h> header file. */
#define HAVE_SYS_STAT_H 1

/* Define to 1 if you have the <sys/types.h> header file. */
#define HAVE_SYS_TYPES_H 1

/* blk_restore_flags() is available */
/* #undef HAVE_TSK_RESTORE_FLAGS */

/* Define to 1 if you have the <unistd.h> header file. */
#define HAVE_UNISTD_H 1

/* Name of package */
#define PACKAGE "pitrix-dep-qbd"

/* Define to the address where bug reports for this package should be sent. */
#define PACKAGE_BUGREPORT "YunifyDevelopers<developer@yunify.com>"

/* Define to the full name of this package. */
#define PACKAGE_NAME "pitrix-dep-qbd"

/* Define to the full name and version of this package. */
#define PACKAGE_STRING "pitrix-dep-qbd 2.1.2-6682c33-202105251057-ubuntu1604"

/* Define to the one symbol short name of this package. */
#define PACKAGE_TARNAME "pitrix-dep-qbd"

/* Define to the home page for this package. */
#define PACKAGE_URL ""

/* Define to the version of this package. */
#define PACKAGE_VERSION "2.1.2-6682c33-202105251057-ubuntu1604"

/* qbd debugging enabled */
/* #undef QBD_DEBUG */

/* qbd rdma protocol enabled */
#define QBD_ENABLE_RDMA 1

/* Define to 1 if you have the ANSI C header files. */
#define STDC_HEADERS 1

/* Version number of package */
#define VERSION "2.1.2-6682c33-202105251057-ubuntu1604"
