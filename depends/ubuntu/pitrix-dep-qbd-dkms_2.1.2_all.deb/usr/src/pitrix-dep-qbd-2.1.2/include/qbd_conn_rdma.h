#ifndef _QBD_CONN_RDMA_H
#define _QBD_CONN_RDMA_H

#include "qbd_conn.h"

int qbd_rdma_init_conn(struct qbd_conn *conn, struct qbd_volume *vol, struct sockaddr_in *addr);
void qbd_rdma_release_conn(struct qbd_conn *conn);
void _qbd_rdma_release_conn(struct qbd_conn *conn);

#endif
