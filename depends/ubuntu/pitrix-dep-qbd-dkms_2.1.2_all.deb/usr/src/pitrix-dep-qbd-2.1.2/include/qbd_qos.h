#ifndef _QBD_QOS_H
#define _QBD_QOS_H

struct qbd_qos_info {
	uint64_t iops;
	uint64_t bps;
	uint64_t burst_iops;
	uint64_t burst_bps;
};

#ifdef _KERNEL
struct qbd_tc_info {
	/* token bucket parameters */
	uint64_t iops_tokens, bps_tokens; /* current number of tokens */
	uint64_t iops_tick, bps_tick;
	uint64_t c_time; /* checkpoint time */
};

/* tc refresh tokens interval 50ms */
#define TC_REFR_INTVL_MSEC 50UL
#define TC_REFR_INTVL_NSEC (TC_REFR_INTVL_MSEC * 1000 * 1000)
/* tc refresh times per second */
#define TC_REFRS_PER_SEC (1000 / TC_REFR_INTVL_MSEC)

static inline void qbd_tc_init(struct qbd_tc_info *tc, const struct qbd_qos_info *qos)
{
	tc->iops_tokens = qos->iops;
	tc->bps_tokens = qos->bps;
	tc->iops_tick = qos->iops / TC_REFRS_PER_SEC + 1;
	tc->bps_tick = qos->bps / TC_REFRS_PER_SEC + 1;
	tc->c_time = get_now_nsec();
}

static inline void qbd_tc_reset(struct qbd_tc_info *tc, const struct qbd_qos_info *qos)
{
	tc->iops_tick = qos->iops / TC_REFRS_PER_SEC + 1;
	tc->bps_tick = qos->bps / TC_REFRS_PER_SEC + 1;
}

static inline void iops_token_add(struct qbd_tc_info *tc, uint64_t ticks, struct qbd_qos_info *qos)
{
	uint64_t toks = tc->iops_tokens + ticks;
	if (toks > qos->burst_iops)
		toks = qos->burst_iops;
	tc->iops_tokens = toks;
}

static inline void bps_token_add(struct qbd_tc_info *tc, uint64_t ticks, struct qbd_qos_info *qos)
{
	uint64_t toks = tc->bps_tokens + ticks;
	if (toks > qos->burst_bps)
		toks = qos->burst_bps;
	tc->bps_tokens = toks;
}

static inline void tc_tokens_refresh(struct qbd_tc_info *tc, struct qbd_qos_info *qos)
{
	uint64_t now = get_now_nsec();
	uint64_t num = (now - tc->c_time) / TC_REFR_INTVL_NSEC;

	if (num != 0) {
		iops_token_add(tc, num * tc->iops_tick, qos);
		bps_token_add(tc, num * tc->bps_tick, qos);
		tc->c_time = now;
	}
}

static bool tc_tokens_acquire(struct qbd_tc_info *tc, struct qbd_qos_info *qos, uint64_t bytes)
{
	if ((qos->iops != 0 && tc->iops_tokens == 0) ||
	    (qos->bps != 0 && tc->bps_tokens < bytes))
		return false;
	if (qos->iops != 0)
		tc->iops_tokens--;
	if (qos->bps != 0)
		tc->bps_tokens -= bytes;
	return true;
}

static inline bool qbd_should_tc(struct qbd_tc_info *tc, struct qbd_qos_info *qos, uint64_t bytes)
{
	if (qos->iops != 0 || qos->bps != 0) {
		tc_tokens_refresh(tc, qos);
		return !tc_tokens_acquire(tc, qos, bytes);
	}
	return false;
}
#endif /* end _KERNEL */

#endif
