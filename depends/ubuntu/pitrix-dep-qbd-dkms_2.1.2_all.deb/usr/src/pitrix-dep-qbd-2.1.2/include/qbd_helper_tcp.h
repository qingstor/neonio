#ifndef _QBD_HELPER_TCP_H
#define _QBD_HELPER_TCP_H

#include <net/sock.h>
#include <linux/net.h>
#include "linux/sock_compat.h"

#define TCP_SEND_TIMEOUT 5	/* 5s */
enum {
	ERROR_READY = 0,
	ERROR_SOCKET_CREATE,
	ERROR_SETSOCKOPT_SNDTIMEO,
	ERROR_SETSOCKOPT_RCVTIMEO,
	ERROR_KERNEL_CONNECT,
	ERROR_MAX_COUNT,
};

int socket_open(struct socket **skt, struct sockaddr_in *addr, int tcp_no_delay, int conn_timeout, int *step);
int socket_close(struct socket *skt);
int socket_send_all(struct socket *skt, void *buf, size_t size);
int socket_recv_all(struct socket *skt, void *buf, size_t size);
int socket_recv(struct socket *skt, void *buf, size_t size);
int socket_disconnect(struct socket *skt);

#endif
