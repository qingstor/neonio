#ifndef _QBD_CONN_TCP_H
#define _QBD_CONN_TCP_H

#include "qbd_conn.h"
#include "qbd_client.h"

/* QBD session for io request */
struct qs_request {
	struct iotask_tcp *iotask;
	int status;
	struct qbd_conn *conn;
};

struct qbd_conn_pool;

int qbd_tcp_init_conn(struct qbd_conn *conn, struct qbd_volume *vol, struct sockaddr_in *addr);
void qbd_tcp_release_conn(struct qbd_conn *conn);
void _qbd_tcp_release_conn(struct qbd_conn *conn);
void qbd_tcp_disconnect_all(struct qbd_conn_pool *pool);

#endif
