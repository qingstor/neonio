#ifndef _QBD_MM_COMPAT_H
#define _QBD_MM_COMPAT_H

#include <linux/mm.h>
#include <linux/vmalloc.h>

#ifndef __GFP_MEMALLOC
#define __GFP_MEMALLOC ((__force gfp_t)0x2000u)	/* Use emergency reserves */
#endif

#ifndef HAVE_KERNEL_KVMALLOC
#ifndef __GFP_RETRY_MAYFAIL
#define __GFP_RETRY_MAYFAIL __GFP_REPEAT
#endif

static inline void *kvmalloc(size_t size, gfp_t flags)
{
	void *ret;
	gfp_t kmalloc_flags = flags;

	if ((flags & GFP_KERNEL) != GFP_KERNEL)
		return kmalloc(size, flags);

	if (size > PAGE_SIZE) {
		kmalloc_flags |= __GFP_NOWARN;

		if (!(flags & __GFP_RETRY_MAYFAIL))
			kmalloc_flags |= __GFP_NORETRY;
	}

	ret = kmalloc(size, kmalloc_flags);
	if (ret || size <= PAGE_SIZE)
		return ret;

	return vmalloc(size);
}
#endif /* HAVE_KERNEL_KVMALLOC */

#ifndef HAVE_KERNEL_KVFREE
static inline void kvfree(const void *addr)
{
	if (is_vmalloc_addr(addr))
		vfree(addr);
	else
		kfree(addr);
}
#endif /* HAVE_KERNEL_KVFREE */

#ifndef HAVE_KERNEL_MEMALLOC_NORECLAIM
static inline unsigned int memalloc_noreclaim_save(void)
{
	unsigned int flags = current->flags & PF_MEMALLOC;
	current->flags |= PF_MEMALLOC;
	return flags;
}

static inline void memalloc_noreclaim_restore(unsigned int flags)
{
	current->flags = (current->flags & ~PF_MEMALLOC) | flags;
}
#else
#include <linux/sched/mm.h>
#endif /* HAVE_KERNEL_KVFREE */

#endif
