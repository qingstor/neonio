#ifndef _QBD_BLKDEV_COMPAT_H
#define _QBD_BLKDEV_COMPAT_H

#include <linux/blkdev.h>
#include <linux/elevator.h>
#include "qbd_config.h"

#ifndef HAVE_BLK_RQ_POS
static inline sector_t blk_rq_pos(struct request *req)
{
	return (req->sector);
}
#endif /* HAVE_BLK_RQ_POS */

#ifndef HAVE_BLK_RQ_SECTORS
static inline unsigned int blk_rq_sectors(struct request *req)
{
	return (req->nr_sectors);
}
#endif /* HAVE_BLK_RQ_SECTORS */

#if !defined(HAVE_BLK_RQ_BYTES) || defined(HAVE_BLK_RQ_BYTES_GPL_ONLY)
/*
 * Define required to avoid conflicting 2.6.29 non-static prototype for a
 * GPL-only version of the helper.  As of 2.6.31 the helper is available
 * to non-GPL modules in the form of a static inline in the header.
 */
#define	blk_rq_bytes __blk_rq_bytes
static inline unsigned int __blk_rq_bytes(struct request *req)
{
	return (blk_rq_sectors(req) << 9);
}
#endif /* !HAVE_BLK_RQ_BYTES || HAVE_BLK_RQ_BYTES_GPL_ONLY */

/*
 * 2.6.34 API change,
 * The blk_queue_max_hw_sectors() function replaces blk_queue_max_sectors().
 */
#ifndef HAVE_BLK_QUEUE_MAX_HW_SECTORS
#define	blk_queue_max_hw_sectors __blk_queue_max_hw_sectors
static inline void __blk_queue_max_hw_sectors(struct request_queue *q, unsigned int max_hw_sectors)
{
	blk_queue_max_sectors(q, max_hw_sectors);
}
#endif

/*
 * 2.6.34 API change,
 * The blk_queue_max_segments() function consolidates
 * blk_queue_max_hw_segments() and blk_queue_max_phys_segments().
 */
#ifndef HAVE_BLK_QUEUE_MAX_SEGMENTS
#define	blk_queue_max_segments __blk_queue_max_segments
static inline void __blk_queue_max_segments(struct request_queue *q, unsigned short max_segments)
{
	blk_queue_max_phys_segments(q, max_segments);
	blk_queue_max_hw_segments(q, max_segments);
}
#endif

/*
 * 2.6.30 API change,
 * The blk_queue_physical_block_size() function was introduced to
 * indicate the smallest I/O the device can write without incurring
 * a read-modify-write penalty.  For older kernels this is a no-op.
 */
#ifndef HAVE_BLK_QUEUE_PHYSICAL_BLOCK_SIZE
#define	blk_queue_physical_block_size(q, x)	((void)(0))
#endif

/*
 * 2.6.30 API change,
 * The blk_queue_io_opt() function was added to indicate the optimal
 * I/O size for the device.  For older kernels this is a no-op.
 */
#ifndef HAVE_BLK_QUEUE_IO_OPT
#define	blk_queue_io_opt(q, x)			((void)(0))
#endif

#ifndef HAVE_RQ_FOR_EACH_SEGMENT
struct req_iterator {
	int i;
	struct bio *bio;
};

#define	for_each_bio(_bio)              \
	for (; _bio; _bio = _bio->bi_next)

#define	__rq_for_each_bio(_bio, rq)     \
	if ((rq->bio))                  \
		for (_bio = (rq)->bio; _bio; _bio = _bio->bi_next)

#define	rq_for_each_segment(bvl, _rq, _iter)                    \
	__rq_for_each_bio(_iter.bio, _rq)                       \
		bio_for_each_segment(bvl, _iter.bio, _iter.i)

#define	HAVE_RQ_FOR_EACH_SEGMENT_BVP 1
#endif /* HAVE_RQ_FOR_EACH_SEGMENT */

/*
 * 3.14 API change
 * rq_for_each_segment changed from taking bio_vec * to taking bio_vec.
 * We provide rq_for_each_segment4 which takes both.
 * You should not modify the fields in @bv and @bvp.
 *
 * Note: the if-else is just to inject the assignment before the loop body.
 */
#ifdef HAVE_RQ_FOR_EACH_SEGMENT_BVP
#define	rq_for_each_segment4(bv, bvp, rq, iter)	\
	rq_for_each_segment(bvp, rq, iter)	\
		if ((bv = *bvp), 1)
#else
#define	rq_for_each_segment4(bv, bvp, rq, iter)	\
	rq_for_each_segment(bv, rq, iter)	\
		if ((bvp = &bv), 1)
#endif

#ifdef HAVE_BLK_STATUS_T
#ifndef HAVE_ERRNO_TO_BLK_STATUS
static inline blk_status_t errno_to_blk_status(int error)
{
	switch (error) {
	case 0:
		return (BLK_STS_OK);
	case EOPNOTSUPP:
		return (BLK_STS_NOTSUPP);
	case ETIMEDOUT:
		return (BLK_STS_TIMEOUT);
	case ENOSPC:
		return (BLK_STS_NOSPC);
	case ENOLINK:
		return (BLK_STS_TRANSPORT);
	case EREMOTEIO:
		return (BLK_STS_TARGET);
	case EBADE:
		return (BLK_STS_NEXUS);
	case ENODATA:
		return (BLK_STS_MEDIUM);
	case EILSEQ:
		return (BLK_STS_PROTECTION);
	case ENOMEM:
		return (BLK_STS_RESOURCE);
#ifdef BLK_STS_AGAIN
	case EAGAIN:
		return (BLK_STS_AGAIN);
#endif
	case EIO:
		return (BLK_STS_IOERR);
	default:
		return (BLK_STS_IOERR);
	}
}
#endif /* HAVE_ERRNO_TO_BLK_STATUS */
#else
#define errno_to_blk_status(errno)	(errno)
#endif /* HAVE_BLK_STATUS_T */

#endif /* _QBD_BLKDEV_H */
