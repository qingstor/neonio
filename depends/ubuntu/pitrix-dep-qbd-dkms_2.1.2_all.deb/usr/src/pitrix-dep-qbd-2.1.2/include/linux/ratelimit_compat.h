#ifndef _QBD_RATELIMIT_COMPAT_H
#define _QBD_RATELIMIT_COMPAT_H

#include <linux/ratelimit.h>

#include "qbd_config.h"

#ifndef HAVE_KERNEL_RATELIMIT_INIT
static inline void ratelimit_state_init(struct ratelimit_state *rs,
                                        int interval, int burst)
{
	memset(rs, 0, sizeof(*rs));

#ifdef HAVE_KERNEL_RATELIMIT_SPINLOCK
	spin_lock_init(rs->lock);
#endif

	rs->interval    = interval;
	rs->burst       = burst;
}
#endif /* end HAVE_KERNEL_RATELIMIT_INIT */

#ifndef HAVE_KERNEL_RATELIMIT_FUN_PARM
#define ___ratelimit(rs, fun) ({ (void) fun; __ratelimit(rs); })
#endif

#endif
