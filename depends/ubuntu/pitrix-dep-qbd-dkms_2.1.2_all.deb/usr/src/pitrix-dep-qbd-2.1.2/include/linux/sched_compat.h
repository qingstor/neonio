#ifndef _QBD_SCHED_COMPAT_H
#define _QBD_SCHED_COMPAT_H

#include <linux/sched.h>

#ifndef MIN_NICE
#define MIN_NICE -20
#endif

#endif
