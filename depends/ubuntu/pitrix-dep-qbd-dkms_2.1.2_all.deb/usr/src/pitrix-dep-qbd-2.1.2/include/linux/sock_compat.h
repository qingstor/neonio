#ifndef _QBD_SOCK_COMPAT_H
#define _QBD_SOCK_COMPAT_H

#include <net/sock.h>
#include <linux/net.h>
#include <linux/tcp.h>
#include "qbd_config.h"

#ifdef HAVE_KERNEL_SOCK_TIMEVAL

#define SO_RCVTIMEO SO_RCVTIMEO_NEW
#define SO_SNDTIMEO SO_SNDTIMEO_NEW

#else

#define __kernel_sock_timeval timeval

#endif

#ifdef HAVE_KERNEL_KERNEL_SETSOCKOPT
static inline void tcp_sock_set_nodelay(struct sock *sk)
{
	int tcp_no_delay = 1;

	(void)kernel_setsockopt(sk->sk_socket, IPPROTO_TCP, TCP_NODELAY, (char *)&tcp_no_delay,
				sizeof(tcp_no_delay));
}
#endif

#endif
