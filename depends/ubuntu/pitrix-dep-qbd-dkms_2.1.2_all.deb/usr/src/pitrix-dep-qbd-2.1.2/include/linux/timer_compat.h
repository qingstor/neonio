#ifndef _QBD_TIMER_COMPAT_H
#define _QBD_TIMER_COMPAT_H

#ifdef HAVE_KERNEL_TIMER_FUNCTION_TIMER_LIST
#define setup_timer(timer, fn, data) timer_setup(timer, fn, 0)
#endif

#endif
