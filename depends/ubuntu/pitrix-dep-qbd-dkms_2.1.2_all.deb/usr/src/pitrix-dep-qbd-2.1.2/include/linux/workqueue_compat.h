#ifndef _QBD_WORKQUEUE_H
#define _QBD_WORKQUEUE_H

#ifndef HAVE_KERNEL_ALLOC_WORKQUEUE
#define alloc_workqueue(name, flags, max_active) create_singlethread_workqueue(name)
#endif

#endif
