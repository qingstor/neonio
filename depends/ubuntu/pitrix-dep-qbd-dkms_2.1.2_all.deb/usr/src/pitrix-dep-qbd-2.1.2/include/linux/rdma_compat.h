#ifndef _QBD_RDMA_COMPAT_H
#define _QBD_RDMA_COMPAT_H

#ifndef HAVE_RDMA_IB_QUERY_DEVICE
static inline int ib_query_device(struct ib_device *device, struct ib_device_attr *device_attr)
{
	memcpy(device_attr, &device->attrs, sizeof(struct ib_device_attr));
	return 0;
}
#endif

#ifndef HAVE_RDMA_IB_GET_DMA_MR
static inline struct ib_mr *ib_get_dma_mr(struct ib_pd *pd, int mr_access_flags)
{
	return pd->device->get_dma_mr(pd, mr_access_flags);
}
#endif

#endif
