#ifndef _QBD_HLIST_COMPAT_H
#define _QBD_HLIST_COMPAT_H

#include "qbd_config.h"

#ifndef HAVE_HASHTABLE_HEADER
#include <linux/list.h>
#else
#include <linux/hashtable.h>
#endif /* HAVE_HASHTABLE_HEADER */

#ifndef HAVE_HLIST_FOR_EACH_ENTRY_3_PARAMS
/* conflict with mlx driver, redefine of compat_hlist_for_each_entry */
#undef compat_hlist_for_each_entry
#define compat_hlist_for_each_entry(tpos, pos, head, member) hlist_for_each_entry(tpos, pos, head, member)
#else
#undef compat_hlist_for_each_entry
#define compat_hlist_for_each_entry(tpos, pos, head, member) \
	pos = NULL; hlist_for_each_entry(tpos, head, member)
#endif /* HAVE_HLIST_FOR_EACH_ENTRY_3_PARAMS */

#endif /* _QBD_HLIST_H */
