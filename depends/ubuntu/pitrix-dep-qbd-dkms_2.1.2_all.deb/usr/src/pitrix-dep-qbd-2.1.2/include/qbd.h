#ifndef _QBD_H
#define _QBD_H

#include <linux/spinlock.h>
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/types.h>
#include <linux/slab.h>
#include <linux/net.h>
#include <net/sock.h>

#include "qbd_config.h"
#include "linux/ratelimit_compat.h"

#define QBD_DRV_NAME		"qbd"
#define QBD_DESCRIPTION		"QingCloud NeonSAN Driver(QBD)"
#define QBD_MAGIC		0x00514641
#define QBD_MINORS_PER_MAJOR	16

#define BDRV_SECTOR_SIZE	512
#define BDRV_SECTOR_BITS	9
#define QBD_SECTOR_SIZE		4096
#define QBD_SECTOR_BITS		12
#define QBD_PER_BDRV		(QBD_SECTOR_SIZE / BDRV_SECTOR_SIZE)
#define QBD_SHARD_SIZE_BITS	36
#define QBD_SHARD_SIZE		(1LL << QBD_SHARD_SIZE_BITS)	/* 64GB */
#define QBD_SECTORS_PER_OBJ_BITS	(QBD_OBJ_SIZE_BITS - QBD_SECTOR_BITS)
#define QBD_SECTORS_PER_OBJ(objsize)	((objsize) >> QBD_SECTOR_BITS)
#define QBD_SECTORS_PER_SHARD_BITS	(QBD_SHARD_SIZE_BITS - QBD_SECTOR_BITS)
#define QBD_SECTOR_MASK_IN_OBJ(objsize) (((objsize) >> QBD_SECTOR_BITS) - 1)
#define QBD_SECTOR_OFFSET_IN_OBJ(slba, objsize)	((slba) & QBD_SECTOR_MASK_IN_OBJ(objsize))

#define EDISCARD	(-INT_MAX)

typedef enum {
	QBD_AIO_READ,
	QBD_AIO_WRITE,
	QBD_AIO_PARTIAL_WRITE,	/* only for unaligned requests in qb_request */
	QBD_AIO_MAX
} QBDAIOCmd;

#ifdef min
#undef min
#define min(a, b)	(((a) < (b)) ? (a) : (b))
#endif

#define UINT64_MAX	(uint64_t)(~((uint64_t)0))

#define qbd_fatal(fmt, ...)   panic(QBD_DRV_NAME ":" fmt "\n", ##__VA_ARGS__)
#define qbd_err(fmt, ...)   pr_err(QBD_DRV_NAME ":" fmt "\n", ##__VA_ARGS__)
#define qbd_info(fmt, ...)   pr_info(QBD_DRV_NAME ":" fmt "\n", ##__VA_ARGS__)
#define qbd_debug(fmt, ...)   pr_debug(QBD_DRV_NAME ":" fmt "\n", ##__VA_ARGS__)
#define qbd_err_ratelimited(fmt, ...) \
	pr_err_ratelimited(QBD_DRV_NAME ":" fmt "\n", ##__VA_ARGS__)
#define qbd_info_ratelimited(fmt, ...)	\
	pr_info_ratelimited(QBD_DRV_NAME ":" fmt "\n", ##__VA_ARGS__)

#define qbd_detailed_debug(qbd, fmt, ...)   \
    do {    \
        if (qbd->detailed) {    \
            qbd_debug(fmt, ##__VA_ARGS__);   \
        }   \
	} while(0);

#define qbd_dev_err_ratelimited(qbd, fmt, ...) \
	do { \
		char err[128]; \
		sprintf(err, QBD_DRV_NAME ":[%s] error, %s:%d", qbd->devname, __func__, __LINE__); \
		if (___ratelimit(&qbd->aio_err_rs, err)) { \
			qbd_err(fmt, ##__VA_ARGS__); \
		} \
	} while(0)

#define qbd_dev_info_ratelimited(qbd, fmt, ...) \
	do { \
		char info[128]; \
		sprintf(info, QBD_DRV_NAME ":[%s] info, %s:%d", qbd->devname, __func__, __LINE__); \
		if (___ratelimit(&qbd->aio_info_rs, info)) { \
			qbd_info(fmt, ##__VA_ARGS__); \
		} \
	} while(0)

static inline void qbd_ratelimit_init(struct ratelimit_state *rs)
{
	ratelimit_state_init(rs, DEFAULT_RATELIMIT_INTERVAL, DEFAULT_RATELIMIT_BURST);
}

static inline uint64_t get_now_nsec(void)
{
#ifdef HAVE_KERNEL_KTIME_GET_RAW_TS64
	struct timespec64 now;
	ktime_get_raw_ts64(&now);
#else
	struct timespec now;
	getrawmonotonic(&now);
#endif
	return (((uint64_t)now.tv_sec * NSEC_PER_SEC) + now.tv_nsec);
}

#define disk_to_qbd(disk) ((struct qbd_device *)(disk)->private_data)

#define npow(x, y) ({   \
	int _x =(x), _y = (y); if (_y == 0) _x = 0;  \
	for (; _y > 1; --_y) _x *= x; _x;})

extern struct mutex ctl_mutex;
extern struct list_head qbd_device_list;
extern int qbd_major;
extern const char *QBDAIOStr[QBD_AIO_MAX];

/* module parameters */
extern int qbd_warn_delay;
extern int qbd_detailed;
extern int qbd_read_wait_write_done;
extern int qbd_kvmalloc_noreclaim;
extern int qbd_heartbeat_timeout;
extern int qbd_auto_update_iodepth;
extern int qbd_remap_max_retry;
extern int qbd_retire_seconds;
extern int qbd_kernel_io_timeout;

extern struct kmem_cache *kb_request_cache;
extern struct kmem_cache *qb_request_cache;

extern struct workqueue_struct *qbd_wq;

#endif
