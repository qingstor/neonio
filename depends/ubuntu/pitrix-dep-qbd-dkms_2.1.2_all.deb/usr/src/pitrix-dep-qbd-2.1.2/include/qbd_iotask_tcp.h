#ifndef _QBD_IOTASK_TCP_H
#define _QBD_IOTASK_TCP_H

#include "qbd_queue.h"
#include "qbd_message.h"
#include "qbd_client.h"
#include "qbd_conn_tcp.h"

struct iotask_tcp {
	struct qbd_command io_cmd;
	struct qbd_volume *vol;
	struct qbd_conn *conn;
	ulp_io_handler ulp_handler;
	void *ulp_arg;
	int status;
	bool processing;
	uint64_t ts_iostart; /* a timestamp of a io start time that used for checking timeout
			      * in watchdog. for a kernel io, it is set with kbr->ts_start of
			      * this iotask belongs to, and for a heartbeat io, it is set with
			      * this iotask start time.
			      */
};

struct qbd_iotask_pool_tcp {
	int size;
	int nr_alloced;
	struct queue free_list;
	struct iotask_tcp *iotasks;
	rwlock_t walk_lock; /* walk pool with read_lock, and resize pool with write_lock in case that
			     * invalid memory will be accessed when walk pool.
			     */
};

int qbd_init_iotask_pool_tcp(struct qbd_iotask_pool_tcp *pool, int size);
void qbd_release_iotask_pool_tcp(struct qbd_iotask_pool_tcp *pool);

struct qbd_client_tcp;
void qbd_replace_snd_queue_tcp(struct qbd_client_tcp *client, struct queue *new);
void qbd_replace_rty_queue_tcp(struct qbd_client_tcp *client, struct queue *new);
void qbd_replace_qs_queue_tcp(struct qbd_client_tcp *client, struct queue *new);
void qbd_replace_iotask_pool_tcp(struct qbd_client_tcp *client, struct qbd_iotask_pool_tcp *new);

struct iotask_tcp *qbd_alloc_iotask_tcp(struct qbd_iotask_pool_tcp *pool);
void qbd_free_iotask_tcp(struct qbd_iotask_pool_tcp *pool, struct iotask_tcp *iotask);

static inline struct iotask_tcp *qbd_pick_iotask_tcp(struct qbd_iotask_pool_tcp *pool, int id)
{
	if (likely(id < pool->size))
		return &pool->iotasks[id];
	else
		return NULL;
}

static inline int get_iodepth_by_pool_size_tcp(int pool_size)
{
	return (pool_size / 2);
}

static inline int get_pool_size_by_iodepth_tcp(int iodepth)
{
	return (iodepth * 2);
}

#endif
