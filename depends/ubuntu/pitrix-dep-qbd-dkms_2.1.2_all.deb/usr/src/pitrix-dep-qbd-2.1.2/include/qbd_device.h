#ifndef _QBD_DEVICE_H
#define _QBD_DEVICE_H

#include "qbd.h"
#include "qbd_blk_queue.h"

#define QBD_IOC_MAP_VOLUME		_IO(0xfa, 0)
#define QBD_IOC_UNMAP_VOLUME		_IO(0xfa, 1)
#define QBD_IOC_REMAP_VOLUME		_IO(0xfa, 2)
#define QBD_IOC_SETTHROTTLE_VOLUME	_IO(0xfa, 3)
#define QBD_IOC_SUSPEND_VOLUME		_IO(0xfa, 4)
#define QBD_IOC_RESUME_NORMAL_VOLUME	_IO(0xfa, 5)
#define QBD_IOC_RESUME_ERROR_VOLUME	_IO(0xfa, 6)
#define QBD_IOC_RESUME_DISCARD_VOLUME	_IO(0xfa, 7)

enum qbd_dev_flags {
	QBD_DEV_FLAG_REMOVING,
	QBD_DEV_FLAG_IODEPTH_RESIZING,
};

struct qbd_sysfs_shards {
	struct kobject *dir;
	struct attribute_group *attrs_group;
	char *names;
};

enum SHARD_STAT_TYPE {
	SHARD_STAT_READ = 0,
	SHARD_STAT_WRITE,
	SHARD_STAT_MAX,
};

struct qbd_shard_stat {
	uint64_t ios[SHARD_STAT_MAX];
	uint64_t bytes[SHARD_STAT_MAX];
};

struct qbd_device {
	int id;			/* blkdev unique id */
	int major;		/* blkdev assigned major */
	int magic;		/* magic value for corruption check */
	char devname[32];	/* blkdev name */

	spinlock_t lock;
	unsigned long flags;
	int open_count;

	struct gendisk *disk;	/* blkdev's gendisk and rq */
#ifdef HAVE_KERNEL_BLK_SINGLE_QUEUE
	spinlock_t queue_lock;	/* request queue lock */
#else
	struct blk_mq_tag_set tag_set;
#endif

	struct qbd_volume *vol;	/* qbd volume info */

	struct task_struct *kernel_queue_thread;	/* qbd request handler task */
	struct list_head kernel_queue;		/* qbd requests queue */
	spinlock_t kernel_queue_lock;		/* qbd requests queue lock */
	wait_queue_head_t kernel_request_wait;	/* wait when kernel request is larger than max_io_depth */
	atomic_t kernel_request_count;	/* kernel requests currently handling */
	atomic_t error_count;		/* kernel io error count */

	struct task_struct *qbd_queue_thread;	/* qbd request handler task */
	struct list_head qbd_queue;	/* qbd requests queue */
	spinlock_t qbd_queue_lock;	/* qbd requests queue lock */

	struct list_head wio_range_queue;
	uint64_t read_total;
	uint64_t write_total;
	uint64_t wio_range_read_hits;
	uint64_t wio_range_write_hits;

	int max_sectors;	/* max io blocksize in QBD_SECTOR_SIZE */
	int detailed;		/* enable detailed block information */
	int warn_delay;		/* io request warning when delayed warn_delay(ms) */
	int heartbeat_timeout;	/* heartbeat timeout time in seconds */
	struct list_head delay_info_list;	/* the count of io delay */
	rwlock_t delay_info_lock;		/* qbd delay info list lock */

	struct ratelimit_state aio_err_rs;	/* qbd aio error msg ratelimit state */
	struct ratelimit_state aio_info_rs;	/* qbd aio info msg ratelimit state */

	struct work_struct disk_resize_work;
	struct work_struct iodepth_resize_work;

	/* qbd sysfs related members */
	rwlock_t sysfs_lock;
	struct qbd_sysfs_shards *sysfs_shards;

	struct qbd_shard_stat *shard_stats;	/* an array of qbd_shard_stat */

	struct list_head node;	/* qbd device list node */
};

/* Kernel Block Request */
struct kb_request {
	struct qbd_device *qbd;
	struct request *req;
	char *buf;
	QBDAIOCmd cmd;
	uint64_t sector_num;	/* kernel io request sector_num in 512B */
	unsigned int nb_sectors;/* kernel io request nb_sectors in 512B */
	uint64_t slba;
	uint64_t elba;
	int io_count;		/* aligned io count */
	int uio_count;		/* unaligend io count */
	atomic_t error;
	uint64_t ts_start;	/* kernel io generated timestamp */
	uint64_t ts_finish;	/* kernel io finish timestamp */
	struct list_head entry;
};

/* QBD Block Request */
struct qb_request {
	struct kb_request *kbr;
	QBDAIOCmd cmd;
	uint64_t curr_sector;	/* qbd io request curr_sector in 4k */
	unsigned int nb_sectors;/* qbd io request nb_sectors in 4k */
	int buf_offset;
	struct list_head list;
	uint64_t ts_ready;	/* qbd io dequeued from qbd_queue and ready to send to store */
	uint64_t ts_send;	/* qbd io send to store */
	uint64_t ts_recv;	/* qbd io recv from callback returned */
};

#define shard_index(qlba) ((qlba) >> QBD_SECTORS_PER_SHARD_BITS)
/* return bytes of @qbr */
#define qbr_bytes(qbr) ((uint64_t)(qbr)->nb_sectors << QBD_SECTOR_BITS)

static inline void qbd_update_shard_stat(struct qbd_shard_stat *stat, struct qb_request *qbr)
{
	struct qbd_device *qbd = qbr->kbr->qbd;

	switch (qbr->cmd) {
	case QBD_AIO_READ:
		stat->ios[SHARD_STAT_READ] += 1;
		stat->bytes[SHARD_STAT_READ] += qbr_bytes(qbr);
		break;

	case QBD_AIO_WRITE:
		stat->ios[SHARD_STAT_WRITE] += 1;
		stat->bytes[SHARD_STAT_WRITE] += qbr_bytes(qbr);
		break;

	case QBD_AIO_PARTIAL_WRITE:
		/* used for unaligned write, don't count */
		break;

	default:
		qbd_err("[%s]: %s unknown qbr->cmd %d ", qbd->devname, __func__, qbr->cmd);
	}
}

int qbd_queue_thread(void *opaque);
int kernel_queue_thread(void *opaque);

int qbd_init_disk(struct qbd_device *qbd);
void qbd_free_disk(struct qbd_device *qbd);

#endif
