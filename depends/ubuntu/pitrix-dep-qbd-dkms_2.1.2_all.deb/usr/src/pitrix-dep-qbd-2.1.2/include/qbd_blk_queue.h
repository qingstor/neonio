#ifndef _QBD_BLK_QUEUE_H
#define _QBD_BLK_QUEUE_H

#ifdef HAVE_KERNEL_BLK_SINGLE_QUEUE
#include <linux/blkdev.h>
#else
#include <linux/blk-mq.h>
#endif

#include "linux/blkdev_compat.h"

struct qbd_device;

#ifdef HAVE_KERNEL_BLK_SINGLE_QUEUE
static inline void qbd_blk_end_request(struct request *rq, int error)
{
	blk_end_request_all(rq, errno_to_blk_status(error));
}

static inline void qbd_blk_stop_queue(struct request_queue *q)
{
	spin_lock_irq(q->queue_lock);
	blk_stop_queue(q);
	spin_unlock_irq(q->queue_lock);
}

static inline void qbd_blk_start_queue(struct request_queue *q)
{
	spin_lock_irq(q->queue_lock);
	blk_start_queue(q);
	spin_unlock_irq(q->queue_lock);
}

static inline void qbd_blk_requeue_request(struct request_queue *q, struct request *rq)
{
	spin_lock_irq(q->queue_lock);
	blk_requeue_request(q, rq);
	spin_unlock_irq(q->queue_lock);
}
#else
static inline void qbd_blk_end_request(struct request *rq, int error)
{
	blk_mq_end_request(rq, errno_to_blk_status(error));
}

static inline void qbd_blk_stop_queue(struct request_queue *q)
{
	blk_mq_stop_hw_queues(q);
}

static inline void qbd_blk_start_queue(struct request_queue *q)
{
	blk_mq_start_hw_queues(q);
}

static inline void qbd_blk_requeue_request(struct request_queue *q __attribute__ ((unused)), struct request *rq)
{
	blk_mq_requeue_request(rq, false);
}
#endif /* end HAVE_KERNEL_BLK_SINGLE_QUEUE */

void qbd_blk_cleanup_queue(struct request_queue *q);

struct request_queue *qbd_blk_init_queue(struct qbd_device *qbd);

#endif /* end _QBD_BLK_QUEUE_H */
