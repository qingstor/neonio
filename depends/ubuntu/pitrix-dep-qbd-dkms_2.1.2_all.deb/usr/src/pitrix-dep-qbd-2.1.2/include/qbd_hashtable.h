#ifndef _QBD_HASHTABLE_H
#define _QBD_HASHTABLE_H

#include <net/sock.h>
#include "linux/hlist_compat.h"
#include "qbd_conn.h"

struct sockaddr_hashtable {
	uint32_t size;
	struct hlist_head *hashtable;
	struct mutex lock;
};

struct sockaddr_hashnode {
	struct qbd_conn *conn;
	struct hlist_node hashnode;
};

struct sockaddr_hashtable *sht_init(uint32_t size);
struct qbd_conn *sht_find(struct sockaddr_hashtable *sht, struct sockaddr_in *addr);
int sht_insert(struct sockaddr_hashtable *sht, struct qbd_conn *conn);
int sht_delete(struct sockaddr_hashtable *sht, struct sockaddr_in *addr);
int sht_destroy(struct sockaddr_hashtable *sht);
int sht_cleanup(struct sockaddr_hashtable *sht);

#endif
