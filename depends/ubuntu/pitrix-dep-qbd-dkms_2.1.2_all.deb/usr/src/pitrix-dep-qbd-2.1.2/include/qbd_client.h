#ifndef _QBD_CLIENT_H
#define _QBD_CLIENT_H

#include "qbd.h"
#include "qbd_device.h"
#include "qbd_qos.h"
#include "qbd_crypt.h"
#include "qbd_volume.h"

typedef void (*ulp_io_handler) (int complete_status, void *cbk_arg);

extern const char *volume_status_str[];

/*
 * client's status is set to the *OK* status when volume is normal and
 * set to the other status when volume runs into a abnormal status.
 */
enum client_status {
	CLIENT_STATUS_OK = 0,
	CLIENT_STATUS_REOPEN_VOL = 1U << 0,
	CLIENT_STATUS_RESET_CONN = 1U << 1,
	CLIENT_STATUS_KERNEL_IO_TIMEOUT = 1U << 2,
};

struct qbd_client_operations {
	struct module *owner;
	char name[8];		/* client type name */
	int type;		/* transport type */

	/* volume operations */
	int (*open) (struct qbd_volume * vol);
	int (*close) (struct qbd_volume * vol);
	int (*aio_read) (struct qbd_volume * vol, void *buf, uint64_t slba,
			 uint32_t nlba, void *callback, void *cb_arg);
	int (*aio_write) (struct qbd_volume * vol, void *buf, uint64_t slba,
			  uint32_t nlba, void *callback, void *cb_arg);
	int (*read) (struct qbd_volume * vol, void *buf, uint64_t slba, uint32_t nlba);
	int (*write) (struct qbd_volume * vol, void *buf, uint64_t slba, uint32_t nlba);
	int (*reopen) (struct qbd_volume * vol);
	void (*resize_iodepth) (struct qbd_volume *vol);

	/* connection operations */
	int (*init_conn)(struct qbd_conn *conn, struct qbd_volume *vol, struct sockaddr_in *addr);
	void (*release_conn)(struct qbd_conn *conn);
	void (*_release_conn)(struct qbd_conn *conn);

	/* hold ctl_mutex to change the following member */
	struct list_head entry;
};

static inline int qbd_open_volume(struct qbd_volume *volume)
{
	int ret;
	ret = volume->cops->open(volume);
	if (!ret)
		volume->status = VOLUME_STATUS_OPENED;
	else
		volume->status = VOLUME_STATUS_ERROR;
	volume->open_ts = get_now_nsec();
	return ret;
}

static inline int qbd_close_volume(struct qbd_volume *volume)
{
	int ret;
	ret = volume->cops->close(volume);
	if (!ret)
		volume->status = VOLUME_STATUS_CLOSED;
	return ret;
}

static inline int qbd_reopen_volume(struct qbd_volume *volume)
{
	int ret;
	ret = volume->cops->reopen(volume);
	if (!ret)
		volume->status = VOLUME_STATUS_OPENED;
	else
		volume->status = VOLUME_STATUS_ERROR;
	volume->open_ts = get_now_nsec();
	return ret;
}

static inline void qbd_resize_iodepth(struct qbd_volume *volume)
{
	if (volume->cops->resize_iodepth)
		volume->cops->resize_iodepth(volume);
}

static inline int qbd_aio_read(struct qbd_volume *vol, void *buf, uint64_t slba,
		 unsigned int nlba, ulp_io_handler callback, void *cbk_arg)
{
	return vol->cops->aio_read(vol, buf, slba, nlba, callback, cbk_arg);
}

static inline int qbd_aio_write(struct qbd_volume *vol, void *buf, uint64_t slba,
		  unsigned int nlba, ulp_io_handler callback, void *cbk_arg)
{
	return vol->cops->aio_write(vol, buf, slba, nlba, callback, cbk_arg);
}

static inline int qbd_read(struct qbd_volume *vol, void *buf, uint64_t slba, unsigned int nlba)
{
	return vol->cops->read(vol, buf, slba, nlba);
}

static inline int qbd_write(struct qbd_volume *vol, void *buf, uint64_t slba, unsigned int nlba)
{
	return vol->cops->write(vol, buf, slba, nlba);
}

int qbd_client_register(struct qbd_client_operations *client);
int qbd_client_unregister(struct qbd_client_operations *client);
struct qbd_client_operations *qbd_client_ops_get(enum transport_type type);

void qbd_check_ready_timeout(struct qb_request *qbr);
void qbd_check_send_timeout(struct qb_request *qbr);
void qbd_check_recv_timeout(struct qb_request *qbr, bool aligned);
void qbd_check_finish_timeout(struct kb_request *kbr);
bool qbd_check_kernel_io_timeout(uint64_t start);

#endif
