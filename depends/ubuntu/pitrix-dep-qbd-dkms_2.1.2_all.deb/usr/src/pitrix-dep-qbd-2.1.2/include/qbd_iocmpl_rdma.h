#ifndef _QBD_IOCMPL_RDMA_H
#define _QBD_IOCMPL_RDMA_H

#include "qbd_queue.h"
#include "qbd_message.h"
#include "qbd_helper_rdma.h"

struct iocmpl_rdma {
	DESC_TYPE type;
	uint32_t id;

	struct qbd_conn *conn;
	struct qbd_completion cmpl;
	bool rcv_processing;
};

struct qbd_iocmpl_pool_rdma {
	int size;
	int nr_alloced;
	struct queue free_list;
	struct iocmpl_rdma *iocmpls;
};
int qbd_init_iocmpl_pool_rdma(struct qbd_iocmpl_pool_rdma *pool, int pool_size, int blocksize);
void qbd_release_iocmpl_pool_rdma(struct qbd_iocmpl_pool_rdma *pool, int block_size);

struct qbd_client_rdma;
void qbd_replace_iocmpl_pool_rdma(struct qbd_client_rdma *client, struct qbd_iocmpl_pool_rdma *new);

static inline struct iocmpl_rdma *qbd_alloc_iocmpl_rdma(struct qbd_iocmpl_pool_rdma *pool)
{
	struct iocmpl_rdma *iocmpl;
	unsigned long flags;

	spin_lock_irqsave(&pool->free_list.lock, flags);
	iocmpl = __dequeue(&pool->free_list);
	if (iocmpl != NULL) {
		BUG_ON(iocmpl->type != DESC_IOCMPL);
		BUG_ON(iocmpl->id > pool->size);
		BUG_ON(iocmpl->conn);
		BUG_ON(iocmpl->rcv_processing);
		BUG_ON(iocmpl->cmpl.status != 0);
		iocmpl->rcv_processing = true;
		++pool->nr_alloced;
	}
	spin_unlock_irqrestore(&pool->free_list.lock, flags);

	return iocmpl;
}

static inline void qbd_free_iocmpl_rdma(struct qbd_iocmpl_pool_rdma *pool, struct iocmpl_rdma *iocmpl)
{
	unsigned long flags;

	iocmpl->cmpl.status = 0;
	iocmpl->rcv_processing = false;
	iocmpl->conn = NULL;
	spin_lock_irqsave(&pool->free_list.lock, flags);
	BUG_ON(__enqueue(&pool->free_list, iocmpl));
	--pool->nr_alloced;
	spin_unlock_irqrestore(&pool->free_list.lock, flags);
}

static inline struct iocmpl_rdma *qbd_pick_iocmpl_rdma(struct qbd_iocmpl_pool_rdma *pool, int id)
{
	if (likely(id < pool->size)) {
		BUG_ON(id != pool->iocmpls[id].id);
		return &pool->iocmpls[id];
	}
	else
		return NULL;
}

#endif
