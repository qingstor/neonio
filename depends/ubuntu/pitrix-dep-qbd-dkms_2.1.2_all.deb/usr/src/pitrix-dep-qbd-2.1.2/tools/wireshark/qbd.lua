--[[
author: neilsun@yunify.com

$ wireshark vnet0.tcpdump -X lua_script:/path/to/qbd.lua

--]]
do
    --[[
    Proto.new(name, desc)
        name: displayed in the column of “Protocol” in the packet list
        desc: displayed as the dissection tree root in the packet details
    --]]
    local PROTO_QBD = Proto("QBD", "QBD over TCP")

    --[[
    ProtoField:
        to be used when adding items to the dissection tree
    --]]
    --[[
    (1)QBD, qbd_rw_command
    --]]
    local f_qbd_opcode = ProtoField.uint8("f_qbd_opcode", "opcode", base.DEC, {[1]="write",[2]="read"})
    local f_qbd_flags = ProtoField.uint8("f_qbd_flags", "flags", base.HEX)
    local f_qbd_command_id = ProtoField.uint16("f_qbd_command_id", "command_id", base.DEC)
    local f_qbd_snap_seq = ProtoField.uint32("f_qbd_snap_seq", "snap_seq", base.HEX)
    local f_qbd_vol_id = ProtoField.uint64("f_qbd_vol_id", "vol_id", base.HEX)
    local f_qbd_metadata = ProtoField.uint64("f_qbd_metadata", "metadata", base.HEX)
    local f_qbd_buf_addr = ProtoField.uint64("f_qbd_buf_adder", "buf_addr", base.HEX)
    local f_qbd_rkey = ProtoField.uint32("f_qbd_rkey", "rkey", base.HEX)
    local f_qbd_buf_len = ProtoField.uint32("f_qbd_buf_len", "buf_len", base.DEC)
    local f_qbd_slba = ProtoField.uint64("f_qbd_slba", "slba", base.DEC)
    local f_qbd_nlba = ProtoField.uint16("f_qbd_nlba", "nlba", base.DEC)
    local f_qbd_control = ProtoField.uint16("f_qbd_control", "control", base.HEX)
    local f_qbd_dsmgmt = ProtoField.uint32("f_qbd_dsmgmt", "dsmgmt", base.HEX)
    local f_qbd_reftag = ProtoField.uint32("f_qbd_reftag", "reftag", base.HEX)
    local f_qbd_apptag = ProtoField.uint16("f_qbd_apptag", "apptag", base.HEX)
    local f_qbd_appmask = ProtoField.uint16("f_qbd_appmask", "appmask", base.HEX)


    --[[
    (2)QBD, qbd_completion
    --]]
    local b_qbd_result = ProtoField.uint32("f_qbd_result", "result", base.HEX)
    local b_qbd_rsvd = ProtoField.uint32("f_qbd_rsvd", "rsvd", base.HEX)
    local b_qbd_client_to_server_trans = ProtoField.uint64("f_qbd_client_to_server_trans", "client_to_server_trans", base.HEX)
    local b_qbd_server_send_time = ProtoField.uint64("f_qbd_server_send_time", "server_send_time", base.HEX)
    local b_qbd_sq_head = ProtoField.uint16("f_qbd_sq_head", "sq_head", base.HEX)
    local b_qbd_sq_id = ProtoField.uint16("f_qbd_sq_id", "sq_id", base.HEX)
    local b_qbd_command_id = ProtoField.uint16("f_qbd_command_id", "command_id", base.DEC)
    local b_qbd_status = ProtoField.uint16("f_qbd_status", "status", base.HEX)

    -- define the fields table of this dissector(as a protoField array)
    PROTO_QBD.fields = {
        --qbd_rw_command
        f_qbd_opcode, f_qbd_flags, f_qbd_command_id, f_qbd_snap_seq, f_qbd_vol_id, f_qbd_metadata, f_qbd_buf_addr, f_qbd_rkey, f_qbd_buf_len, f_qbd_slba, f_qbd_nlba, f_qbd_control, f_qbd_dsmgmt, f_qbd_reftag, f_qbd_apptag, f_qbd_appmask,
        --qbd_completion
        b_qbd_result, b_qbd_rsvd, b_qbd_sq_head, b_qbd_sq_id, b_qbd_command_id, b_qbd_status, b_qbd_client_to_server_trans, b_qbd_server_send_time
    }


    --[[
    Data Section
    --]]
    local data_dis = Dissector.get("data")

    --[[
    qbd_rw_command dissector Function
    --]]
    local function qbd_rw_command_dissector(buf, pkt, root)
        -- check buffer length
        local buf_len = buf:len()
        -- qbd_rw_command size:64
        if buf_len ~= 64
        then
            return false
        end

        -- check flag, current 0x80 is default value

        if buf(1,1):uint() ~= 0x80
        then
            return false
        end

        --[[
        dissection tree in packet details
        --]]
        -- tree root
        local t = root:add(PROTO_QBD, buf(0,64))
        -- child items
        if buf(0,1):uint() == 1
        then
            t:add_le(f_qbd_opcode, buf(0,1))
        else
            t:add_le(f_qbd_opcode, buf(0,1))
        end
        t:add_le(f_qbd_flags, buf(1,1))
        t:add_le(f_qbd_command_id, buf(2,2))
        t:add_le(f_qbd_snap_seq, buf(4,4))
        t:add_le(f_qbd_vol_id, buf(8,8))
        t:add_le(f_qbd_metadata, buf(16,8))
        t:add_le(f_qbd_buf_addr, buf(24,8))
        t:add_le(f_qbd_rkey, buf(32,4))
        t:add_le(f_qbd_buf_len, buf(36,4))
        t:add_le(f_qbd_slba, buf(40,8))
        t:add_le(f_qbd_nlba, buf(48,2))
        t:add_le(f_qbd_control, buf(50,2))
        t:add_le(f_qbd_dsmgmt, buf(52,4))
        t:add_le(f_qbd_reftag, buf(56,4))
        t:add_le(f_qbd_apptag, buf(60,2))
        t:add_le(f_qbd_appmask, buf(62,2))


        --[[
        packet list columns
        --]]
        pkt.cols.protocol = "QBD"
        local colstr = "qbd_rw_command"
        colstr = colstr.." cid["..buf(2,2):le_uint().."]"
        if buf(0,1):uint() == 1
        then
            colstr = colstr.." write"
        else
            colstr = colstr.." read"
        end
        colstr = colstr.." slba="..buf(40,8):le_uint64()
        colstr = colstr.." nlba="..buf(48,2):le_uint()
        pkt.cols.info = colstr

        return true
    end

    --[[
    qbd_completion dissector Function
    --]]
    local function qbd_completion_dissector(buf, pkt, root)
         -- check buffer length
        local buf_len = buf:len()
        -- qbd_completion size:16
        if buf_len ~= 32
        then
            return false
        end

        --[[
        dissection tree in packet details
        --]]
        -- tree root
        local t = root:add(PROTO_QBD, buf(0,32))
        -- child items
        t:add_le(b_qbd_result, buf(0,4))
        t:add_le(b_qbd_rsvd, buf(4,4))
        t:add_le(b_qbd_sq_head, buf(8,2))
        t:add_le(b_qbd_sq_id, buf(10,2))
        t:add_le(b_qbd_command_id, buf(12,2))
        t:add_le(b_qbd_status, buf(14,2))
        t:add_le(b_qbd_client_to_server_trans, buf(16,8))
        t:add_le(b_qbd_server_send_time, buf(24,8))

        --[[
        packet list columns
        --]]
        pkt.cols.protocol = "QBD"
        colstr = "qbd_completion"
        colstr = colstr.." cid["..buf(12,2):le_uint().."]"
        pkt.cols.info = colstr

        return true
    end
    --[[
    Dissect Process
    --]]
    function PROTO_QBD.dissector(buf, pkt, root)
        if qbd_rw_command_dissector(buf, pkt, root)
        then
            -- valid qbd_rw_command
        elseif qbd_completion_dissector(buf, pkt, root)
        then
            -- valid qbd_completion
        else
            data_dis:call(buf, pkt, root)
        end
    end

    --[[
    Specify Protocol Port
    --]]
    local tcp_encap_table = DissectorTable.get("tcp.port")
    tcp_encap_table:add(7800, PROTO_QBD)
end
