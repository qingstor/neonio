/* qbd.c - qbd extension for crash
 *
 * Copyright (C) 2019 Beijing QingCloud, Inc. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

#include "defs.h"      /* From the crash source top-level directory */

enum transport_type {
	RDMA = 0,
	TCP = 1,
};

void qbd_init(void);
void qbd_fini(void);

void cmd_qbd(void);

char *help_qbd[] = {
        "qbd",
        "debug command for QBD volume of QingCloud NeonSAN",
        "arg ...",
 
        "This command will help for debug QBD related issues.",
	"-l: list qbd volumes like qbd util",
	"-i: list qbd detailed informations",
	"",
        "\nEXAMPLE",
        "    crash> qbd -l",
	"    qbd_device              dev_id  vol_id          device  volume  config  read_bps        write_bps       read_iops       write_iops",
	"    ffff881e8db7a400        0       0x1000000       qbd0    pool/vol  /etc/neonsan/iscsi.conf",
	"",
        "    crash> qbd -i",
	"    device  qbd_device              qbd_volume              qbd_client              iodepth max_block_size",
	"    qbd0    ffff881e8db7a400        ffff881038482000        ffff881e8db79800        32      65536",
        NULL
};

static struct command_table_entry command_table[] = {
        { "qbd", cmd_qbd, help_qbd, 0},
        { NULL },
};


void __attribute__((constructor)) qbd_init(void)
{ 
        register_extension(command_table);
}
 
void __attribute__((destructor)) qbd_fini(void) { }

static unsigned long get_next_from_list_head(unsigned long addr)
{
	unsigned long ret;

	readmem(addr + OFFSET(list_head_next), KVADDR, &ret, sizeof(void *),
			"get_next_from_list_head:list_head.next",
			FAULT_ON_ERROR);

	return ret;
}

#define list_for_each(next, head, last) \
	for (next = get_next_from_list_head(head), last = 0UL; \
			next && next != head && next != last; \
			last = next, next = get_next_from_list_head(next))

static void qbd_device_show(unsigned long qbd)
{
	int dev_id; 
	char dev_name[32];
	uint64_t vol_id;
	unsigned long qbd_volume;
	int legacy_protocol;
	int type;
	char vol_name[128];
	char cfg_file[PATH_MAX + 1];

	readmem(qbd + MEMBER_OFFSET("struct qbd_device", "vol"), KVADDR, &qbd_volume, sizeof(void *), "qbd_device->vol", FAULT_ON_ERROR);

	readmem(qbd + MEMBER_OFFSET("struct qbd_device", "id"), KVADDR, &dev_id, sizeof(int), "qbd_device->id", FAULT_ON_ERROR);
	readmem(qbd_volume + MEMBER_OFFSET("struct qbd_volume", "id"), KVADDR, &vol_id, sizeof(uint64_t), "qbd_volume->id", FAULT_ON_ERROR);
	readmem(qbd + MEMBER_OFFSET("struct qbd_device", "devname"), KVADDR, dev_name, sizeof(char) * 32, "qbd_device->devname", FAULT_ON_ERROR);
	readmem(qbd_volume + MEMBER_OFFSET("struct qbd_volume", "legacy_protocol"), KVADDR, &legacy_protocol, sizeof(int), "qbd_volume->legacy_protocol", FAULT_ON_ERROR);
	readmem(qbd_volume + MEMBER_OFFSET("struct qbd_volume", "type"), KVADDR, &type, sizeof(int), "qbd_volume->type", FAULT_ON_ERROR);
	readmem(qbd_volume + MEMBER_OFFSET("struct qbd_volume", "name"), KVADDR, &vol_name, sizeof(char) * 128, "qbd_volume->name", FAULT_ON_ERROR);
	readmem(qbd_volume + MEMBER_OFFSET("struct qbd_volume", "cfg_file"), KVADDR, &cfg_file, sizeof(char) * (PATH_MAX + 1), "qbd_volume->cfg_file", FAULT_ON_ERROR);

	fprintf(fp, "%d\t%#lx\t%s\t%s%s\t%s\n",
			dev_id,
			vol_id,
			dev_name,
			legacy_protocol ? "" : (type == TCP ? "tcp://" : "rdma://"), vol_name,
			cfg_file
			);
}

static void qbd_list()
{
	unsigned long qbd_head;
	unsigned long qbd_next, qbd_last;
	unsigned long offset;
	int dev_id;

	if (symbol_exists("qbd_volume_list"))
		qbd_head = symbol_value("qbd_volume_list");
	else
		qbd_head = symbol_value("qbd_device_list");

	fprintf(fp, "dev_id\tvol_id\t\tdevice\tvolume\tconfig\tread_bps\twrite_bps\tread_iops\twrite_iops\n");
	list_for_each(qbd_next, qbd_head, qbd_last) {
		offset = MEMBER_OFFSET("struct qbd_device", "node");
		qbd_device_show(qbd_next - offset);
	}
}

static void qbd_info_show(unsigned long qbd)
{
	char dev_name[32];
	unsigned long qbd_volume;
	unsigned long qbd_client;
	int max_io_depth;
	int max_blocksize;

	readmem(qbd + MEMBER_OFFSET("struct qbd_device", "vol"), KVADDR, &qbd_volume, sizeof(void *), "qbd_device->vol", FAULT_ON_ERROR);

	readmem(qbd + MEMBER_OFFSET("struct qbd_device", "devname"), KVADDR, dev_name, sizeof(char) * 32, "qbd_device->devname", FAULT_ON_ERROR);
	readmem(qbd_volume + MEMBER_OFFSET("struct qbd_volume", "client"), KVADDR, &qbd_client, sizeof(void *), "qbd_volume->client", FAULT_ON_ERROR);
	readmem(qbd_volume + MEMBER_OFFSET("struct qbd_volume", "max_io_depth"), KVADDR, &max_io_depth, sizeof(int), "qbd_volume->max_io_depth", FAULT_ON_ERROR);
	readmem(qbd_volume + MEMBER_OFFSET("struct qbd_volume", "max_blocksize"), KVADDR, &max_blocksize, sizeof(int), "qbd_volume->max_blocksize", FAULT_ON_ERROR);

	fprintf(fp, "%s\t%lx\t%lx\t%lx\t%d\t%d\n",
			dev_name,
			qbd,
			qbd_volume,
			qbd_client,
			max_io_depth,
			max_blocksize
	       );
	//dump_struct("qbd_device", qbd, 16);
}

static void qbd_info()
{
	unsigned long qbd_head;
	unsigned long qbd_next, qbd_last;
	unsigned long offset;
	int dev_id;

	if (symbol_exists("qbd_volume_list"))
		qbd_head = symbol_value("qbd_volume_list");
	else
		qbd_head = symbol_value("qbd_device_list");

	fprintf(fp, "device\tqbd_device\t\tqbd_volume\t\tqbd_client\t\tiodepth\tmax_block_size\n");
	list_for_each(qbd_next, qbd_head, qbd_last) {
		offset = MEMBER_OFFSET("struct qbd_device", "node");
		qbd_info_show(qbd_next - offset);
	}
}

void cmd_qbd(void)
{
        int c;

	if (!is_module_name("qbd", NULL, NULL)) {
		fprintf(fp, "qbd module is not loaded\n");
		argerrs++;
		goto out;
	}
	if (argcnt == 1) {
		argerrs++;
		goto out;
	}

        while ((c = getopt(argcnt, args, "li")) != EOF) {
                switch(c)
                {
		case 'l':
			qbd_list();
			break;
		case 'i':
			qbd_info();
			break;
                default:
                        argerrs++;
                        break;
                }
        }

out:
        if (argerrs)
                cmd_usage(pc->curcmd, SYNOPSIS);

        fprintf(fp, "\n");
}
