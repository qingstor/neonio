#ifndef _QBD_CMD_H
#define _QBD_CMD_H

#include "neonsan/neon_client.h"
#include "neonsan/neon_client_priv.h"
#include "neonsan/neon_utils.h"
#include "neonsan/neon_version.h"
#include "neonsan/neon_qos.h"

#include "qbd_config.h"
#include "qbd_volume.h"

/*
 * QBD use syslog for recording logs when called by kernel,
 * undefine LOG_* in neonsan dev package
 */
#ifdef LOG_INFO
#undef LOG_INFO
#endif
#ifdef LOG_DEBUG
#undef LOG_DEBUG
#endif
#include <syslog.h>

#define DEFAULT_CONFIG_FILE     "/etc/neonsan/qbd.conf"
#define DEFAULT_MAP_FILE        "/etc/neonsan/map.conf"
#define DEV_QBDCTL		"/dev/qbdctl"
#define PROC_QBDSTAT		"/proc/qbdstat"
#define QBD_DEVNAME_MAXLEN	(16) /* qbd device name max length */
#define FILE_LINE_MAXLEN	(1024) /* qbd sysfs file line max length */
#define QBD_SYSFS_BASE_PATH	"/sys/block"

#define infosysmsg(format, ...) \
	do { \
		syslog(LOG_INFO, format, ##__VA_ARGS__);	\
	} while(0);

#define infomsg(format, ...) \
	do { \
		fprintf(stdout, format, ##__VA_ARGS__);	\
		syslog(LOG_INFO, format, ##__VA_ARGS__);	\
	} while(0);
#define errmsg(format, ...) \
	do { \
		fprintf(stderr, format, ##__VA_ARGS__);	\
		syslog(LOG_ERR, format, ##__VA_ARGS__);	\
	} while(0);

/* copyright: linux kernel */
#define BUILD_BUG_ON(condition) ((void)sizeof(char[1 - 2*!!(condition)]))

int get_version(int show);
int get_device_name_by_id(uint64_t vid, char *devname);
int get_device_name_by_vol(const struct qfa_client_volume_priv *qcv, char *devname);
int modprobe(char *module);
int set_vol_name_type(struct qfa_client_volume_priv *qcv, const char *uri);
char *get_neonsan_error_string(int error);

extern int legacy_protocol; /* compat with legacy dispaly and action when tcp:// is not specified */

#endif
