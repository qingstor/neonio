#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif
/*
 * QBD util for volume operations
 */
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <ctype.h>
#include <dirent.h>
#include <inttypes.h>
#include <unistd.h>
#include <string.h>
#include <getopt.h>
#include <fcntl.h>
#include <errno.h>
#include <limits.h>
#include <linux/ioctl.h>
#include <linux/types.h>
#include <sys/socket.h>
#include <sys/mount.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/sysmacros.h>

#include "qbd_comm.h"

#define QBD_IOC_MAP_VOLUME		_IO(0xfa, 0)
#define QBD_IOC_UNMAP_VOLUME		_IO(0xfa, 1)
#define QBD_IOC_REMAP_VOLUME		_IO(0xfa, 2)
#define QBD_IOC_SETTHROTTLE_VOLUME	_IO(0xfa, 3)
#define QBD_IOC_SUSPEND_VOLUME		_IO(0xfa, 4)
#define QBD_IOC_RESUME_NORMAL_VOLUME	_IO(0xfa, 5)
#define QBD_IOC_RESUME_ERROR_VOLUME	_IO(0xfa, 6)
#define QBD_IOC_RESUME_DISCARD_VOLUME	_IO(0xfa, 7)

char *const throttle_opts[] = {
	[THROTTLE_SET_READ_BPS] = "read_bps",
	[THROTTLE_SET_WRITE_BPS] = "write_bps",
	[THROTTLE_SET_READ_IOPS] = "read_iops",
	[THROTTLE_SET_WRITE_IOPS] = "write_iops",
	NULL
};
char *const throttle_files[] = {
	[THROTTLE_SET_READ_BPS] = "/sys/fs/cgroup/blkio/blkio.throttle.read_bps_device",
	[THROTTLE_SET_WRITE_BPS] = "/sys/fs/cgroup/blkio/blkio.throttle.write_bps_device",
	[THROTTLE_SET_READ_IOPS] = "/sys/fs/cgroup/blkio/blkio.throttle.read_iops_device",
	[THROTTLE_SET_WRITE_IOPS] = "/sys/fs/cgroup/blkio/blkio.throttle.write_iops_device",
	NULL
};

enum {
	RESUME_SET_NONE = -1,
	RESUME_SET_NORMAL = 0,
	RESUME_SET_ERROR,
	RESUME_SET_DISCARD,
	RESUME_SET_MAX_NUM,
};
char *const resume_opts[] = {
	[RESUME_SET_NORMAL]	= "normal",
	[RESUME_SET_ERROR]	= "error",
	[RESUME_SET_DISCARD]	= "discard",
	NULL
};
int qbd_ioc_resume[] = {
	QBD_IOC_RESUME_NORMAL_VOLUME,
	QBD_IOC_RESUME_ERROR_VOLUME,
	QBD_IOC_RESUME_DISCARD_VOLUME,
};

/*
 * neonsan for qemu not support read keyid and passphrass from commandline,
 * we have to handle without qcv member.
 */
char keyid[QBD_CRYPT_MAX + 1];
char passphrass[QBD_CRYPT_MAX + 1];

static struct option qbd_opts[] = {
	{"map",          required_argument, 0, 'm'},
	{"unmap",        required_argument, 0, 'u'},
	{"remap",        required_argument, 0, 'r'},
	{"list",         no_argument,       0, 'l'},
	{"config",       required_argument, 0, 'c'},
	{"mapall",       no_argument,       0, 'M'},
	{"unmapall",     no_argument,       0, 'U'},
	{"file",         required_argument, 0, 'f'},
	{"setthrottle",  required_argument, 0, 's'},
	{"type",         required_argument, 0, 't'},
	{"suspend",      required_argument, 0, 'S'},
	{"resume",       required_argument, 0, 'R'},
	{"info",         required_argument, 0, 'i'},
	{"keyid",        required_argument, 0, 'K'},
	{"passphrass",   optional_argument, 0, 'P'},
	{"verbose",      no_argument,       0, 'V'},
	{"version",      no_argument,       0, 'v'},
	{"help",         no_argument,       0, 'h'},
	{0, 0, 0, 0}
};

enum {
	ACTION_INVALID = -1,
	ACTION_MAP_VOLUME = 0,
	ACTION_UNMAP_VOLUME,
	ACTION_REMAP_VOLUME,
	ACTION_LIST_VOLUME,
	ACTION_MAPALL_VOLUME,
	ACTION_UNMAPALL_VOLUME,
	ACTION_SETTHROTTLE_VOLUME,
	ACTION_SUSPEND_VOLUME,
	ACTION_RESUME_VOLUME,
	ACTION_INFO_VOLUME,
};

int qbd_map_volume(struct qfa_client_volume_priv *qcv, void *arg);
int qbd_unmap_volume(struct qfa_client_volume_priv *qcv, void *arg);
int qbd_remap_volume(struct qfa_client_volume_priv *qcv, void *arg);
int qbd_list_volume(struct qfa_client_volume_priv *qcv, void *arg);
int qbd_mapall_volume(struct qfa_client_volume_priv *qcv, void *arg);
int qbd_unmapall_volume(struct qfa_client_volume_priv *qcv, void *arg);
int qbd_setthrottle_volume(struct qfa_client_volume_priv *qcv, void *arg);
int qbd_suspend_volume(struct qfa_client_volume_priv *qcv, void *arg);
int qbd_resume_volume(struct qfa_client_volume_priv *qcv, void *arg);
int qbd_info_volume(struct qfa_client_volume_priv *qcv, void *arg);

struct qbd_cmd_t {
	const char *name;
	int (*func) (struct qfa_client_volume_priv *, void *);
};
struct qbd_cmd_t cmd_table[] = {
	{"map",			qbd_map_volume		},
	{"unmap",		qbd_unmap_volume	},
	{"remap",		qbd_remap_volume	},
	{"list",		qbd_list_volume		},
	{"mapall",		qbd_mapall_volume	},
	{"unmapall",		qbd_unmapall_volume	},
	{"setthrottle",		qbd_setthrottle_volume	},
	{"suspend",		qbd_suspend_volume	},
	{"resume",		qbd_resume_volume	},
	{"info",		qbd_info_volume		},
	{NULL, NULL}
};

int verbose = 0;

void show_help(void)
{
	get_version(1);
	printf("Usage: qbd -m [<tcp|rdma>://]<pool/volume>[@snapshot] [-c <config>] [-K <keyid> -P[passphrass]]\n"
	       "       qbd -u [<tcp|rdma>://]<pool/volume>[@snapshot] [-c <config>]\n"
	       "       qbd -r [<tcp|rdma>://]<pool/volume>[@snapshot] [-c <config>] [-K <keyid> -P[passphrass]]\n"
	       "       qbd -l\n"
	       "       qbd -M [-f <file>]\n"
	       "       qbd -U [-f <file>]\n"
	       "       qbd -s [<tcp|rdma>://]<pool/volume>[@snapshot] [-c <config>] -t <read_bps|write_bps|read_iops|write_iops=num>\n"
	       "       qbd -S [<tcp|rdma>://]<pool/volume>[@snapshot] [-c <config>]\n"
	       "       qbd -R [<tcp|rdma>://]<pool/volume>[@snapshot] [-c <config>] -t <normal|error|discard>\n"
	       "       qbd -i [<tcp|rdma>://]<pool/volume>[@snapshot] [-c <config>]\n"
	       "       qbd -v\n"
	       "       qbd -h\n\n"
	       "For detailed Usage: man qbd\n");
}

void show_shard_ips(struct qfa_client_volume_priv *qcv)
{
	int shard_i, ip_i;
	infosysmsg("shard info for volume[%s:%s]\n", qcv->name, qcv->cfg_file->cfg_file);
	for (shard_i = 0; shard_i < qcv->shard_count; shard_i++) {
		struct qfa_client_shard *shard = &qcv->shards[shard_i];
		for (ip_i = 0; ip_i < 16; ip_i++) {
			struct sockaddr_in *addr = &shard->ips[ip_i];
			unsigned char *ip = (unsigned char *)&addr->sin_addr;
			if (addr->sin_port == 0)
				break;
			infosysmsg("shard[%d] IP[%d]:%d.%d.%d.%d:%d\n",
			           shard_i, ip_i, ip[0], ip[1], ip[2], ip[3], ntohs(addr->sin_port));
		}
	}
}

static void qbd_qos_init(struct qbd_volume *qv, const struct qfa_client_volume_priv *qcv)
{
	struct qbd_qos_info *dest = &qv->qos;
	const qos_info_t *src = &qcv->qos_info;

	dest->iops = src->base_iops_credit;
	dest->bps = src->base_bps_credit;
	dest->burst_iops = src->burst_iops_credit;
	dest->burst_bps = src->burst_bps_credit;

	if (dest->bps != 0 && dest->bps < qcv->max_blocksize)
		dest->bps = qcv->max_blocksize;
	if (dest->burst_bps != 0 && dest->burst_bps < qcv->max_blocksize)
		dest->burst_bps = qcv->max_blocksize;
}

/*
 * Map pool/volume to qbd device.
 */
int qbd_map_volume(struct qfa_client_volume_priv *qcv, void *arg)
{
	struct qbd_volume qv;
	char dev_name[16] = "";
	char dev_file[32] = "";
	int rc = 0;
	int retry;
	int cfd, dfd;

	/* open volume and get volume info */
	infosysmsg("%s open_volume_common [%s:%s] now\n", __func__, qcv->name, qcv->cfg_file->cfg_file);
	rc = open_volume_common((struct qfa_client_volume *)qcv, NEONSAN_LIB_VER, keyid, passphrass);
	if (rc != 0) {
		errmsg("%s failed to open_volume_common[%s:%s]:%d(%s)\n",
			__func__,
			qcv->name,
			qcv->cfg_file->cfg_file,
			rc,
			get_neonsan_error_string(rc));
		goto out;
	}
	infosysmsg("%s open_volume_common [%s:%s] success\n", __func__, qcv->name, qcv->cfg_file->cfg_file);

	/* only needed items being copied, in case of structure difference, copy one by one */
	memset(&qv, 0, sizeof(qv));
	qv.id = qcv->id;
	qv.meta_ver = qcv->meta_ver;
	strcpy(qv.name, qcv->name);
	strcpy(qv.snap_name, qcv->snap_name);
	strcpy(qv.cfg_file, qcv->cfg_file->cfg_file);
	qv.size = qcv->size;
	qv.objsize = qcv->objsize;
	qv.snap_seq = qcv->snap_seq;
	qv.max_blocksize = qcv->max_blocksize;
	qv.max_io_depth = qcv->max_io_depth;
	qv.tcp_no_delay = qcv->tcp_no_delay;
	qv.io_timeout = qcv->io_timeout;
	qv.conn_timeout = qcv->conn_timeout;
	qv.type = qcv->transport;
	qv.shard_count = qcv->shard_count;
	qv.shards = (struct qbd_client_shard *)qcv->shards;	/* use qfa_client_volume_priv shards pointer */
	qv.resume_type = QBD_IOC_RESUME_NORMAL_VOLUME;
	qv.legacy_protocol = legacy_protocol;
	qbd_qos_init(&qv, qcv);
	show_shard_ips(qcv);
	strcpy(qv.keyid, keyid);
	strcpy(qv.passphrass, passphrass);

	/* map qbd volume */
	cfd = open(DEV_QBDCTL, O_RDWR);
	if (cfd < 0) {
		errmsg("failed to open %s:%s\n", DEV_QBDCTL, strerror(errno));
		rc = errno;
		goto free_shards;
	}
	if (ioctl(cfd, QBD_IOC_MAP_VOLUME, &qv)) {
		errmsg("failed to ioctl with QBD_IOC_MAP_VOLUME:%s\n", strerror(errno));
		rc = errno;
		goto close_cfd;
	}
	if (get_device_name_by_id(qv.id, dev_name)) {
		errmsg("failed to get device name by id:%" PRIx64" , device should ready now\n", qv.id);
		rc = -ENOENT;
		goto close_cfd;
	}
	snprintf(dev_file, 32, "/dev/%s", dev_name);
	for (retry = 0; ; retry++) {
		dfd = open(dev_file, O_RDONLY);
		if (dfd > 0 || errno != ENOENT || retry > 9)
			break;
		sleep(1);
	}
	if (dfd < 0) {
		errmsg("failed to open %s:%s\n", dev_file, strerror(errno));
		rc = errno;
		goto close_cfd;
	}
	/* don't care about if BLKRRPART succeed */
	if (ioctl(dfd, BLKRRPART, NULL)) {
		errmsg("failed to ioctl %s with BLKRRPART:%s\n", dev_file, strerror(errno));
	}
	rc = 0;

	close(dfd);
close_cfd:
	close(cfd);
free_shards:
	free(qcv->shards);
out:
	return rc;
}

/*
 * Unmap pool/volume and qbd device will be released.
 */
int qbd_unmap_volume(struct qfa_client_volume_priv *qcv, void *arg)
{
	struct qbd_volume qv;
	int rc = 0;
	int cfd;

	/* only needed items being copied */
	strcpy(qv.name, qcv->name);
	strcpy(qv.snap_name, qcv->snap_name);
	strcpy(qv.cfg_file, qcv->cfg_file->cfg_file);
	qv.type = qcv->transport;

	/* unmap qbd volume */
	cfd = open(DEV_QBDCTL, O_RDWR);
	if (cfd < 0) {
		errmsg("failed to open %s:%s\n", DEV_QBDCTL, strerror(errno));
		return errno;
	}
	if (ioctl(cfd, QBD_IOC_UNMAP_VOLUME, &qv)) {
		errmsg("failed to ioctl %s with QBD_IOC_UNMAP_VOLUME:%s\n", DEV_QBDCTL, strerror(errno));
		rc = errno;
	}
	close(cfd);

	return rc;
}

/*
 * Force remap pool/volume.
 * Don't open /dev/qbdx, it may cause deadlock when io failed with retry.
 */
int qbd_remap_volume(struct qfa_client_volume_priv *qcv, void *arg)
{
	struct qbd_volume qv;
	int rc = 0;
	int cfd;

	/* open volume and get latest volume info */
	infosysmsg("%s open_volume_common [%s:%s] now\n", __func__, qcv->name, qcv->cfg_file->cfg_file);
	rc = open_volume_common((struct qfa_client_volume *)qcv, NEONSAN_LIB_VER, keyid, passphrass);
	if (rc != 0) {
		errmsg("%s failed to open_volume_common[%s:%s]:%d(%s)\n",
			__func__,
			qcv->name,
			qcv->cfg_file->cfg_file,
			rc,
			get_neonsan_error_string(rc));
		goto out;
	}
	infosysmsg("%s open_volume_common [%s:%s] success\n", __func__, qcv->name, qcv->cfg_file->cfg_file);
	/* only needed items being copied, in case of structure difference, copy one by one */
	memset(&qv, 0, sizeof(qv));
	qv.id = qcv->id;
	strcpy(qv.name, qcv->name);
	strcpy(qv.snap_name, qcv->snap_name);
	strcpy(qv.cfg_file, qcv->cfg_file->cfg_file);
	qv.size = qcv->size;
	qv.objsize = qcv->objsize;
	qv.snap_seq = qcv->snap_seq;
	qv.max_blocksize = qcv->max_blocksize;
	qv.max_io_depth = qcv->max_io_depth;
	qv.tcp_no_delay = qcv->tcp_no_delay;
	qv.io_timeout = qcv->io_timeout;
	qv.conn_timeout = qcv->conn_timeout;
	qv.type = qcv->transport;
	qv.shard_count = qcv->shard_count;
	qv.shards = (struct qbd_client_shard *)qcv->shards;	/* use qfa_client_volume_priv shards pointer */
	qv.meta_ver = qcv->meta_ver;	/* meta_ver will update when store upgrade */
	qv.legacy_protocol = legacy_protocol;
	qbd_qos_init(&qv, qcv);
	show_shard_ips(qcv);
	strcpy(qv.keyid, keyid);
	strcpy(qv.passphrass, passphrass);

	/* remap qbd volume */
	cfd = open(DEV_QBDCTL, O_RDWR);
	if (cfd < 0) {
		errmsg("failed to open %s:%s\n", DEV_QBDCTL, strerror(errno));
		rc = errno;
		goto free_shards;
	}
	if (ioctl(cfd, QBD_IOC_REMAP_VOLUME, &qv)) {
		errmsg("failed to ioctl %s with QBD_IOC_REMAP_VOLUME:%s\n", DEV_QBDCTL, strerror(errno));
		rc = errno;
		goto close_cfd;
	}
	rc = 0;

close_cfd:
	close(cfd);
free_shards:
	free(qcv->shards);
out:
	return rc;
}

/*
 * List all mapped volume information.
 */
int qbd_list_volume(struct qfa_client_volume_priv *qcv, void *arg)
{
	int fd;
	char buf[PATH_MAX * 2] = "";
	int rc;

	/* add qbd volume, volume can be used after map */
	fd = open(PROC_QBDSTAT, O_RDONLY);
	if (fd < 0) {
		errmsg("failed to open '%s':%s\n", PROC_QBDSTAT, strerror(errno));
		return errno;
	}
	while ((rc = read(fd, buf, PATH_MAX * 2)) > 0) {
		buf[rc] = '\0';
		printf("%s", buf);
	}
	close(fd);
	return rc == 0 ? 0 : -1;
}

/*
 * Map all qbd volumes in map file
 */
int qbd_mapall_volume(struct qfa_client_volume_priv *qcv, void *arg)
{
	FILE *fp;
	char *buf, *str;
	char name[QBD_VOLUME_MAX + QBD_SNAP_MAX + 10];
	int set_throttle;
	int loop, ret = 0;
	struct qfa_client_volume_priv qcvp;
	char *map_file = (arg == NULL ? DEFAULT_MAP_FILE : arg);
	struct qbd_throttle qbd_throttle;

	buf = malloc(QBD_VOLUME_MAX + QBD_SNAP_MAX + PATH_MAX);
	if (buf == NULL) {
		errmsg("failed to malloc buffer\n");
		return -ENOMEM;
	}
	fp = fopen(map_file, "r");
	if (fp == NULL) {
		errmsg("failed to open %s\n", map_file);
		ret = -ENOENT;
		goto out_free_buf;
	}

	while (fgets(buf, QBD_VOLUME_MAX + QBD_SNAP_MAX + PATH_MAX, fp) != NULL) {
		str = buf;
		while(isspace(*str))
			str++;
		if (*str == '\0' || *str == '#')
			continue;
		memset(&qcvp, 0, sizeof(qcvp));
		/* reuse qcv->cfg_file pointer as it will never used when mapall */
		qcvp.cfg_file = qcv->cfg_file;
		memset(qcvp.cfg_file, 0, sizeof(struct config_file));

		set_throttle = 0;
		for (loop = THROTTLE_SET_READ_BPS; loop < THROTTLE_SET_MAX_NUM; loop++) {
			qbd_throttle.value[loop] = UINT64_MAX;
		}

		memset(name, 0, sizeof(name));
		sscanf(str, "%s%s%" PRIu64 "%" PRIu64 "%" PRIu64 "%" PRIu64,
		       name, qcvp.cfg_file->cfg_file,
		       &qbd_throttle.value[THROTTLE_SET_READ_BPS], &qbd_throttle.value[THROTTLE_SET_WRITE_BPS],
		       &qbd_throttle.value[THROTTLE_SET_READ_IOPS], &qbd_throttle.value[THROTTLE_SET_WRITE_IOPS]);
		ret = set_vol_name_type(&qcvp, name);
		if (ret) {
			errmsg("failed to set_vol_name_type %s:%s ret: %d\n", qcvp.name, qcvp.cfg_file->cfg_file, ret);
			break;
		}

		if (qcvp.cfg_file->cfg_file[0] == '#' || qcvp.cfg_file->cfg_file[0] == '\0')
			strcpy(qcvp.cfg_file->cfg_file, DEFAULT_CONFIG_FILE);

		for (loop = THROTTLE_SET_READ_BPS; !set_throttle && loop < THROTTLE_SET_MAX_NUM; loop++)
			if (qbd_throttle.value[loop] != UINT64_MAX)
				set_throttle = 1;

		while (qbd_map_volume(&qcvp, NULL)) {
			errmsg("failed to map volume %s:%s, retry\n", name, qcvp.cfg_file->cfg_file);
			sleep(1);
		}
		while (set_throttle && qbd_setthrottle_volume(&qcvp, &qbd_throttle)) {
			errmsg("failed to set throttle for volume %s:%s, retry\n", name, qcvp.cfg_file->cfg_file);
			sleep(1);
		}
	}
	fclose(fp);
out_free_buf:
	free(buf);
	return ret;
}

/*
 * Unmap all qbd volumes in map file
 */
int qbd_unmapall_volume(struct qfa_client_volume_priv *qcv, void *arg)
{
	FILE *fp;
	char *buf, *str;
	int ret = 0;
	char name[QBD_VOLUME_MAX + QBD_SNAP_MAX + 10];
	struct qfa_client_volume_priv qcvp;
	char *map_file = (arg == NULL ? DEFAULT_MAP_FILE : arg);

	buf = malloc(QBD_VOLUME_MAX + QBD_SNAP_MAX + PATH_MAX);
	if (buf == NULL) {
		errmsg("failed to malloc buffer\n");
		return -ENOMEM;
	}
	fp = fopen(map_file, "r");
	if (fp == NULL) {
		errmsg("failed to open %s\n", map_file);
		ret = -ENOENT;
		goto out_free_buf;
	}

	while (fgets(buf, QBD_VOLUME_MAX + QBD_SNAP_MAX + PATH_MAX, fp) != NULL) {
		str = buf;
		while(isspace(*str))
			str++;
		if (*str == '\0' || *str == '#')
			continue;
		memset(&qcvp, 0, sizeof(qcvp));
		/* reuse qcv->cfg_file pointer as it will never used when unmapall */
		qcvp.cfg_file = qcv->cfg_file;
		memset(qcvp.cfg_file, 0, sizeof(struct config_file));
		memset(name, 0, sizeof(name));
		sscanf(str, "%s%s", name, qcvp.cfg_file->cfg_file);
		ret = set_vol_name_type(&qcvp, name);
		if (ret) {
			errmsg("failed to set_vol_name_type %s:%s ret:%d\n", qcvp.name, qcvp.cfg_file->cfg_file, ret);
			break;
		}
		if (qcvp.cfg_file->cfg_file[0] == '#' || qcvp.cfg_file->cfg_file[0] == '\0')
			strcpy(qcvp.cfg_file->cfg_file, DEFAULT_CONFIG_FILE);

		while (qbd_unmap_volume(&qcvp, NULL)) {
			errmsg("failed to unmap volume %s:%s, retry\n", name, qcvp.cfg_file->cfg_file);
			sleep(1);
		}
	}
	fclose(fp);
out_free_buf:
	free(buf);
	return ret;
}

/*
 * Set throttle of the pool/volume.
 * We take cgroup blkio for this io throttle.
 * Throttle information will be saved in kernel space in case of implemention in kernel space someday.
 */
int qbd_setthrottle_volume(struct qfa_client_volume_priv *qcv, void *arg)
{
	int tfd, cfd;
	int loop;
	int error = 0;
	char dev_name[16] = "";
	char dev_file[32] = "";
	char throttle_buf[64];
	struct stat fstat;
	struct qbd_volume qv;
	struct qbd_throttle *qbd_throttle = (struct qbd_throttle *)arg;

	if (!arg) {
		errmsg("not specify throttle value with -t <read_bps|write_bps|read_iops|write_iops=num>\n");
		return -EINVAL;
	}

        if (stat("/sys/fs/cgroup", &fstat) || !S_ISDIR(fstat.st_mode)) {
                errmsg("/sys/fs/cgroup is not correctly mounted\n");
                return -ENOENT;
        }
        if (stat("/sys/fs/cgroup/blkio", &fstat) && mkdir("/sys/fs/cgroup/blkio", 0755)) {
		errmsg("failed to mkdir /sys/fs/cgroup/blkio:%s\n", strerror(errno));
		return -ENOENT;
        }

        if (stat("/sys/fs/cgroup/blkio/blkio.throttle.read_bps_device", &fstat) &&
	    mount("blkio", "/sys/fs/cgroup/blkio", "cgroup", 0, "blkio")) {
		errmsg("failed to mount /sys/fs/cgroup/blkio:%s\n", strerror(errno));
		return -ENOENT;
	}

	if (get_device_name_by_vol(qcv, dev_name)) {
		errmsg("failed to get device name %s%s:%s, please check if has mapped\n",
		       legacy_protocol ? "" : (qcv->transport == RDMA ? "rdma://" : "tcp://"),
		       qcv->name,
		       qcv->cfg_file->cfg_file);
		return -ENOENT;
	}
	snprintf(dev_file, 32, "/dev/%s", dev_name);
        if (stat(dev_file, &fstat) || !S_ISBLK(fstat.st_mode)) {
                errmsg("%s not exist or not block device\n", dev_file);
		return -ENOENT;
	}

	for (loop = THROTTLE_SET_READ_BPS; loop < THROTTLE_SET_MAX_NUM; loop++) {
		if (qbd_throttle->value[loop] != UINT64_MAX) {
			tfd = open(throttle_files[loop], O_WRONLY);
			if (tfd < 0) {
				errmsg("failed to open '%s':%s\n", throttle_files[loop], strerror(errno));
				return errno;
			}
			sprintf(throttle_buf, "%u:%u %" PRIu64 "\n",
					major(fstat.st_rdev),
					minor(fstat.st_rdev),
					qbd_throttle->value[loop]);
			if (write(tfd, throttle_buf, strlen(throttle_buf)) != strlen(throttle_buf)) {
				errmsg("failed to write '%s' to %s:%s\n", throttle_buf, throttle_files[loop], strerror(errno));
				/* set UINT64_MAX to not notify change in kernel space */
				qv.throttle.value[loop] = UINT64_MAX;
				error = -EINVAL;
			}
			else {
				qv.throttle.value[loop] = qbd_throttle->value[loop];
			}
			close(tfd);
		}
		else
			qv.throttle.value[loop] = UINT64_MAX;
	}

	/* only needed items being copied */
	strcpy(qv.name, qcv->name);
	strcpy(qv.snap_name, qcv->snap_name);
	strcpy(qv.cfg_file, qcv->cfg_file->cfg_file);
	qv.type = qcv->transport;

	cfd = open(DEV_QBDCTL, O_RDWR);
	if (cfd < 0) {
		errmsg("failed to open %s:%s\n", DEV_QBDCTL, strerror(errno));
		return errno;
	}
	if (ioctl(cfd, QBD_IOC_SETTHROTTLE_VOLUME, &qv)) {
		errmsg("failed to ioctl %s with QBD_IOC_SETTHROTTLE_VOLUME:%s\n", DEV_QBDCTL, strerror(errno));
		error = errno;
	}
	close(cfd);

	return error ? : 0;
}

/*
 * Suspend pool/volume
 */
int qbd_suspend_volume(struct qfa_client_volume_priv *qcv, void *arg)
{
	struct qbd_volume qv;
	int rc = 0;
	int cfd;

	/* only needed items being copied */
	strcpy(qv.name, qcv->name);
	strcpy(qv.snap_name, qcv->snap_name);
	strcpy(qv.cfg_file, qcv->cfg_file->cfg_file);
	qv.type = qcv->transport;

	cfd = open(DEV_QBDCTL, O_RDWR);
	if (cfd < 0) {
		errmsg("failed to open %s:%s\n", DEV_QBDCTL, strerror(errno));
		return errno;
	}
	if (ioctl(cfd, QBD_IOC_SUSPEND_VOLUME, &qv)) {
		errmsg("failed to ioctl %s with QBD_IOC_SUSPEND_VOLUME:%s\n", DEV_QBDCTL, strerror(errno));
		rc = errno;
	}
	close(cfd);

	return rc;
}

/*
 * resume pool/volume
 */
int qbd_resume_volume(struct qfa_client_volume_priv *qcv, void *arg)
{
	struct qbd_volume qv;
	int rc = 0;
	int cfd;
	int resume_type = (arg == NULL ? RESUME_SET_NORMAL : *(int *)arg);

	/* only needed items being copied */
	strcpy(qv.name, qcv->name);
	strcpy(qv.snap_name, qcv->snap_name);
	strcpy(qv.cfg_file, qcv->cfg_file->cfg_file);
	qv.type = qcv->transport;

	cfd = open(DEV_QBDCTL, O_RDWR);
	if (cfd < 0) {
		errmsg("failed to open %s:%s\n", DEV_QBDCTL, strerror(errno));
		return errno;
	}
	if (ioctl(cfd, qbd_ioc_resume[resume_type], &qv)) {
		errmsg("failed to ioctl %s with QBD_IOC_RESUME_VOLUME(%d):%s\n", DEV_QBDCTL, resume_type, strerror(errno));
		rc = errno;
	}
	close(cfd);

	return rc;
}

int qbd_info_volume(struct qfa_client_volume_priv *qcv, void *arg)
{
	char buf[4096]		= "";
	char fname[PATH_MAX]	= "";
	char config[PATH_MAX]	= "";
	char dev_name[16]	= "";
	char vol_id[32]		= "";
	char encrypted[5]	= "";
	char vol_status[32]	= "";
	char dev_buf[16]	= "";
	char sysfs_path[20]	= "/sys/block/";
	FILE *file;
	bool skip_head;
	uint64_t iops, bps, burst_iops, burst_bps;
	unsigned int error_count;
	int rv = 0;

	if (get_device_name_by_vol(qcv, dev_name)) {
		errmsg("failed to get device name %s%s%s%s:%s, please check if has mapped\n",
		       legacy_protocol ? "" : (qcv->transport == RDMA ? "rdma://" : "tcp://"),
		       qcv->name,
		       qcv->snap_name[0] ? "" : "@",
		       qcv->snap_name[0] ? "" : qcv->snap_name,
		       qcv->cfg_file->cfg_file);
		return -ENOENT;
	}
	strcat(sysfs_path, dev_name);	/* /sys/block/qbdxx */

	/* get volume id and config */
	file = fopen(PROC_QBDSTAT, "r");
	if (!file) {
		errmsg("failed to open '%s':%s\n", PROC_QBDSTAT, strerror(errno));
		rv = errno;
		goto out;
	}
	skip_head = true;
	while(fgets(buf, sizeof(buf), file) != NULL) {
		if (skip_head) {
			skip_head = false;
			continue;
		}
		sscanf(buf, "%*s%s%s%*s%s", vol_id, dev_buf, config);
		if (!strcmp(dev_name, dev_buf))
			break;
	}
	fclose(file);

	/* get volume encryption status */
	snprintf(fname, PATH_MAX, "%s/%s", sysfs_path, "encrypted");
	file = fopen(fname, "r");
	if (!file) {
		errmsg("failed to open '%s':%s\n", fname, strerror(errno));
		rv = errno;
		goto out;
	}
	if (fgets(encrypted, sizeof(encrypted), file) == NULL) {
		fclose(file);
		goto out;
	}
	fclose(file);

	/* get volume status */
	snprintf(fname, PATH_MAX, "%s/%s", sysfs_path, "status");
	file = fopen(fname, "r");
	if (!file) {
		errmsg("failed to open '%s':%s\n", fname, strerror(errno));
		rv = errno;
		goto out;
	}
	if (fgets(vol_status, sizeof(vol_status), file) == NULL) {
		fclose(file);
		goto out;
	}
	fclose(file);

	/* get volume qos setting */
	snprintf(fname, PATH_MAX, "%s/%s", sysfs_path, "qos_setting");
	file = fopen(fname, "r");
	if (!file) {
		errmsg("failed to open '%s':%s\n", fname, strerror(errno));
		rv = errno;
		goto out;
	}
	if (fgets(buf, sizeof(buf), file) == NULL) {
		fclose(file);
		goto out;
	}
	sscanf(buf, "%" PRIu64 "%" PRIu64 "%" PRIu64 "%" PRIu64,
	       &iops, &bps, &burst_iops, &burst_bps);
	fclose(file);

	/* get volume error count */
	snprintf(fname, PATH_MAX, "%s/%s", sysfs_path, "error_count");
	file = fopen(fname, "r");
	if (!file) {
		errmsg("failed to open '%s':%s\n", fname, strerror(errno));
		rv = errno;
		goto out;
	}
	if (fgets(buf, sizeof(buf), file) == NULL) {
		fclose(file);
		goto out;
	}
	sscanf(buf, "%u", &error_count);
	fclose(file);

	printf("volume:         %s\n"
	       "snapshot:       %s\n"
	       "config:         %s\n"
	       "volume id:      %s\n"
	       "transport type: %s\n"
	       "encrypted:      %s"
	       "status:         %s"
	       "device:         /dev/%s\n"
	       "error count:    %u\n"
	       "qos setting:    iops:%" PRIu64 " bps:%" PRIu64 " burst_iops:%" PRIu64 " burst_bps:%" PRIu64 "\n",
	       qcv->name,
	       qcv->snap_name,
	       config,
	       vol_id,
	       qcv->transport == TCP ? "tcp" : "rdma",
	       encrypted,
	       vol_status,
	       dev_name,
	       error_count,
	       iops, bps, burst_iops, burst_bps);

out:
	return rv;
}

void set_action(struct qfa_client_volume_priv *qcv, int *action, int ACT)
{
	if (*action != ACTION_INVALID) {
		errmsg("multiple action is specified\n");
		show_help();
		free(qcv->cfg_file);
		exit(1);
	}
	*action = ACT;
}

int main(int argc, char **argv)
{
	int rc = 0;
	int action = ACTION_INVALID;
	char file_path_buf[PATH_MAX], *file_path;
	struct qfa_client_volume_priv qcv;
	int resume_type;
	void *arg = NULL;
	struct qbd_throttle qbd_throttle = {
	    {
		UINT64_MAX,
		UINT64_MAX,
		UINT64_MAX,
		UINT64_MAX,
	    }
	};

	/* build check */
	BUILD_BUG_ON(sizeof(struct qbd_client_shard) != sizeof(struct qfa_client_shard));

	signal(SIGPIPE, SIG_IGN);

	if (modprobe("qbd")) {
		errmsg("failed to probe qbd kernel driver\n");
		return -EINVAL;
	}
	if (get_version(0)) {
		errmsg("%s version and loaded module version mismatch, quit!\n", PACKAGE_NAME);
		get_version(1);
		return -EINVAL;
	}
	/* setup default volume properties */
	memset(&qcv, 0, sizeof(qcv));
	memset(keyid, 0, QBD_CRYPT_MAX + 1);
	memset(passphrass, 0, QBD_CRYPT_MAX + 1);
	qcv.cfg_file = (struct config_file *)malloc(sizeof(struct config_file));
	if (qcv.cfg_file == NULL) {
		errmsg("failed to malloc config_file, oom\n");
		return -ENOMEM;
	}
	strcpy(qcv.cfg_file->cfg_file, DEFAULT_CONFIG_FILE);
	qcv.cfg_file->root = NULL;

	while (1) {
		char *value;
		char *subopts;
		int opt_idx = 0;
		int c = getopt_long(argc, argv, "m:u:r:s:t:c:f:S:R:i:K:P::MUlvVh", qbd_opts, &opt_idx);
		if (c == -1)
			break;

		switch (c) {
		case 'm': /* map */
			set_action(&qcv, &action, ACTION_MAP_VOLUME);
			rc = set_vol_name_type(&qcv, optarg);
			if (rc)
				goto out_free_cfg_file;
			break;

		case 'u': /* unmap */
			set_action(&qcv, &action, ACTION_UNMAP_VOLUME);
			rc = set_vol_name_type(&qcv, optarg);
			if (rc)
				goto out_free_cfg_file;
			break;

		case 'r': /* remap */
			set_action(&qcv, &action, ACTION_REMAP_VOLUME);
			rc = set_vol_name_type(&qcv, optarg);
			if (rc)
				goto out_free_cfg_file;
			break;

		case 's': /* setthrottle */
			set_action(&qcv, &action, ACTION_SETTHROTTLE_VOLUME);
			rc = set_vol_name_type(&qcv, optarg);
			if (rc)
				goto out_free_cfg_file;
			break;

		case 'l': /* list */
			set_action(&qcv, &action, ACTION_LIST_VOLUME);
			break;

		case 'M': /* mapall */
			set_action(&qcv, &action, ACTION_MAPALL_VOLUME);
			break;

		case 'U': /* unmapall */
			set_action(&qcv, &action, ACTION_UNMAPALL_VOLUME);
			break;

		case 'c': /* config */
			file_path = realpath(optarg, file_path_buf);
			if (!file_path) {
				errmsg("config file: %s %s\n", optarg, strerror(errno));
				rc = errno;
				goto out_free_cfg_file;
			}
			strcpy(qcv.cfg_file->cfg_file, file_path);
			break;

		case 'f': /* file */
			if (strlen(optarg) >= PATH_MAX) {
				errmsg("map file: %s name is too long\n", optarg);
				rc = -EINVAL;
				goto out_free_cfg_file;
			}
			arg = optarg;
			break;

		case 't': /* type */
			subopts = optarg;
			/* for throttle set */
			if (action == ACTION_SETTHROTTLE_VOLUME) {
				while (*subopts != '\0') {
					switch (getsubopt(&subopts, throttle_opts, &value)) {
					case THROTTLE_SET_READ_BPS:
						if (value)
							qbd_throttle.value[THROTTLE_SET_READ_BPS] = strtoul(value, NULL, 0);
						else {
							errmsg("failed to set read_bps\n");
							goto out_show_help;
						}
						break;
					case THROTTLE_SET_WRITE_BPS:
						if (value)
							qbd_throttle.value[THROTTLE_SET_WRITE_BPS] = strtoul(value, NULL, 0);
						else {
							errmsg("failed to set write_bps\n");
							goto out_show_help;
						}
						break;
					case THROTTLE_SET_READ_IOPS:
						if (value)
							qbd_throttle.value[THROTTLE_SET_READ_IOPS] = strtoul(value, NULL, 0);
						else {
							errmsg("failed to set read_iops\n");
							goto out_show_help;
						}
						break;
					case THROTTLE_SET_WRITE_IOPS:
						if (value)
							qbd_throttle.value[THROTTLE_SET_WRITE_IOPS] = strtoul(value, NULL, 0);
						else {
							errmsg("failed to set write_iops\n");
							goto out_show_help;
						}
						break;
					default:
						errmsg("invalid throttle is set\n");
						goto out_show_help;
						break;
					}
				}
				arg = &qbd_throttle;
			}
			/* for resume set */
			if (action == ACTION_RESUME_VOLUME) {
				while (*subopts != '\0') {
					switch (getsubopt(&subopts, resume_opts, &value)) {
					case RESUME_SET_NORMAL:
						resume_type = RESUME_SET_NORMAL;
						break;
					case RESUME_SET_ERROR:
						resume_type = RESUME_SET_ERROR;
						break;
					case RESUME_SET_DISCARD:
						resume_type = RESUME_SET_DISCARD;
						break;
					default:
						errmsg("invalid resume option\n");
						goto out_show_help;
						break;
					}
				}
				arg = &resume_type;
			}
			break;

		case 'S': /* suspend */
			set_action(&qcv, &action, ACTION_SUSPEND_VOLUME);
			rc = set_vol_name_type(&qcv, optarg);
			if (rc)
				goto out_free_cfg_file;
			break;

		case 'R': /* resume */
			set_action(&qcv, &action, ACTION_RESUME_VOLUME);
			rc = set_vol_name_type(&qcv, optarg);
			if (rc)
				goto out_free_cfg_file;
			break;

		case 'i': /* info */
			set_action(&qcv, &action, ACTION_INFO_VOLUME);
			rc = set_vol_name_type(&qcv, optarg);
			if (rc)
				goto out_free_cfg_file;
			break;

		case 'K': /* keyid */
			strncpy(keyid, optarg, QBD_CRYPT_MAX);
			keyid[strlen(optarg)] = '\0';
			break;

		case 'P': /* passphrass */
			if (optarg) {
				strncpy(passphrass, optarg, QBD_CRYPT_MAX);
				passphrass[strlen(optarg)] = '\0';
			}
			else {
				char *pass = getpass("");
				if (strlen(pass) > QBD_CRYPT_MAX) {
					errmsg("passphrass length should be shorter than %d\n", QBD_CRYPT_MAX);
					rc = -EINVAL;
					goto out_free_cfg_file;
				}
				strcpy(passphrass, pass);
			}
			break;

		case 'V': /* verbose */
			verbose = 1;
			break;

		case 'h': /* help */
			show_help();
			rc = 0;
			goto out_free_cfg_file;
			break;

		case 'v': /* version */
			get_version(1);
			rc = 0;
			goto out_free_cfg_file;
			break;

		default:
			goto out_show_help;
		}
	}

	/* check if extra args exists */
	if (optind < argc || action == ACTION_INVALID) {
out_show_help:
		show_help();
		free(qcv.cfg_file);
		exit(1);
	}
	rc = cmd_table[action].func(&qcv, arg);
out_free_cfg_file:
	free(qcv.cfg_file);
	if (verbose || rc != 0) {
		errmsg("%s %s\n", cmd_table[action].name, rc ? "failed" : "succeed");
	}
	return rc;
}
