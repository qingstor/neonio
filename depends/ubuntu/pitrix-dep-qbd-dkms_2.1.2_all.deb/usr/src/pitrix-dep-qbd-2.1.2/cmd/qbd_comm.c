#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <ctype.h>
#include <dirent.h>
#include <string.h>
#include <getopt.h>
#include <fcntl.h>
#include <errno.h>
#include <limits.h>
#include <unistd.h>
#include <inttypes.h>

#include "qbd_comm.h"

int legacy_protocol = 0;	/* compat with legacy dispaly and action when tcp:// is not specified */

int get_version(int show)
{
	FILE *fp;
	char buf[65] = "";
	int ver_prefix_len;
	char *pfirst;
	int match;	/* 0: match, not 0: mismatch */

	fp = fopen("/sys/module/qbd/version", "r");
	if (fp == NULL) {
		errmsg("failed to open /sys/module/qbd/version\n");
		return 1;
	}
	if (!fgets(buf, 64, fp)) {
		errmsg("failed to get loaded qbd module version to buffer\n");
		fclose(fp);
		return -EINVAL;
	}
	fclose(fp);

	/*
	 * version defined with x.x.x-gitrev-builddate-host,
	 * dkms may change buildata,so compare x.x.x-gitrev as ver_prefix_len
	 */
	pfirst = strchr(buf, '-');
	ver_prefix_len = strchr(pfirst + 1, '-') - buf;
	match = strncmp(VERSION, buf, ver_prefix_len);
	if (show) {
		printf("Package Version:       %s\n", VERSION);
		printf("Loaded Module Version: %s", buf);
		if (match)
			errmsg("Version Mismatch! Don't forget to `rmmod qbd` after qbd package upgrade!\n");
		printf("NeonSAN Static Library Version: %s-%s\n", _MAJOR_VER_, _NEON_GIT_VER_);
		printf("NeonSAN Protocol Version: %d\n", PROTOCOL_VER);
	}
	return match;
}

/* Get devname with vol_id */
int get_device_name_by_id(uint64_t vid, char *devname)
{
	FILE *lfp;
	int dev_id;
	uint64_t vol_id;
	char buf[PATH_MAX * 2] = "";

	lfp = fopen(PROC_QBDSTAT, "r");
	if (lfp == NULL) {
		errmsg("failed to open '%s'\n", PROC_QBDSTAT);
		return -ENOENT;
	}
	if (fgets(buf, PATH_MAX * 2, lfp) == NULL)
		goto failed;
	while (fgets(buf, PATH_MAX * 2, lfp) != NULL) {
		sscanf(buf, "%d%" PRIx64 "%s", &dev_id, &vol_id, devname);
		if (vol_id == vid) {
			fclose(lfp);
			return 0;
		}
	}
failed:
	fclose(lfp);
	return -ENOENT;
}

/* Get devname with protocal://pool/volume:config */
int get_device_name_by_vol(const struct qfa_client_volume_priv *qcv, char *devname)
{
	FILE *lfp;
	int dev_id;
	uint64_t vol_id;
	char buf[PATH_MAX * 2] = "";
	char vol[QBD_VOLUME_MAX + QBD_SNAP_MAX + 10];
	char vol_i[QBD_VOLUME_MAX];
	char config_i[PATH_MAX];

	lfp = fopen(PROC_QBDSTAT, "r");
	if (lfp == NULL) {
		errmsg("failed to open '%s'\n", PROC_QBDSTAT);
		return -ENOENT;
	}
	if (fgets(buf, PATH_MAX * 2, lfp) == NULL)
		goto out;
	sprintf(vol, "%s%s%s%s",
		legacy_protocol ? "" : (qcv->transport == RDMA ? "rdma://" : "tcp://"),
		qcv->name,
		qcv->snap_name[0] == '\0' ? "" : "@",
		qcv->snap_name[0] == '\0' ? "" : qcv->snap_name);
	while (fgets(buf, PATH_MAX * 2, lfp) != NULL) {
		sscanf(buf, "%d%" PRIx64 "%s%s%s", &dev_id, &vol_id, devname, vol_i, config_i);
		if (!strcmp(vol, vol_i) && !strcmp(config_i, qcv->cfg_file->cfg_file)) {
			fclose(lfp);
			return 0;
		}
	}
out:
	fclose(lfp);
	return -ENOENT;
}

/*
 * Auto probe module.
 */
int modprobe(char *module)
{
	FILE *fp;
	char cmd[512] = "";
	char buf[512] = "";

	fp = fopen("/proc/modules", "r");
	if (fp == NULL) {
		errmsg("failed to open /proc/modules\n");
		return -EEXIST;
	}
	while (fgets(buf, 512, fp) != NULL) {
		if (!strncmp(buf, module, strlen(module))
		    && buf[strlen(module)] == ' ') {
			fclose(fp);
			return 0;
		}
	}
	fclose(fp);
	snprintf(cmd, sizeof(cmd), "/sbin/modprobe %s 2> /dev/null", module);
	if (!system(cmd))
		return 0;
	snprintf(cmd, sizeof(cmd),
		 "/sbin/insmod /lib/modules/$(uname -r)/updates/%s.ko 2> /dev/null", module);
	if (!system(cmd))
		return 0;
	errmsg("failed to probe %s.ko\n", module);
	return -EINVAL;
}

int set_vol_name_type(struct qfa_client_volume_priv *qcv, const char *uri)
{
	char *snap = NULL;
	char *module = NULL;
	int prefix_len = 0;
	legacy_protocol = 0;
	if (strlen(uri) > QBD_VOLUME_MAX + QBD_SNAP_MAX) {
		errmsg("volume name is too long\n");
		return -EINVAL;
	}
#ifndef QBD_ENABLE_RDMA
	if (!strncmp(uri, "rdma://", 7)) {
		errmsg("rdma protocol is not supported with current package\n");
		return -ENOTSUP;
	}
#endif
	if (!strncmp(uri, "rdma://", 7) || !strncmp(uri, "RDMA://", 7)) {
		qcv->transport = RDMA;
		module = "qbd_rdma";
		prefix_len = 7;
	}
	else if (!strncmp(uri, "tcp://", 6) || !strncmp(uri, "TCP://", 6)) {
		qcv->transport = TCP;
		module = "qbd_tcp";
		prefix_len = 6;
	}
	else {
		/* set default transport type TCP */
		qcv->transport = TCP;
		module = "qbd_tcp";
		prefix_len = 0;
		legacy_protocol = 1;
	}

	snap = strchr(uri, '@');
	if (snap != NULL)
	{
		if (snap[1] == '\0')
			return -EINVAL;
		strncpy(qcv->name, uri + prefix_len, snap - uri - prefix_len);
		qcv->name[snap - uri - prefix_len] = '\0';
		strcpy(qcv->snap_name, snap + 1);
	}
	else
		strcpy(qcv->name, uri + prefix_len);

	return modprobe(module);
}

char *get_neonsan_error_string(int error)
{
	char *msg = "";
	switch(error) {
	case -2:
		msg = "denied by ACL or invalid request";
		break;
	default:
		break;
	}
	return msg;
}
