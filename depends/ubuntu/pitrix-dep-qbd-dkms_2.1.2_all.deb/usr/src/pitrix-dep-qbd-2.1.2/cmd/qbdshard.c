#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <ctype.h>
#include <dirent.h>
#include <string.h>
#include <getopt.h>
#include <fcntl.h>
#include <errno.h>
#include <limits.h>
#include <unistd.h>

#include "qbd_comm.h"

/* default interval 1 second */
static long interval = 1;
static bool use_interval = false;
/* show shard iostat loop count */
static long count = 0;
static bool use_count = false;

/* qbd sysfs path, for example:/sys/block/qbd0 */
char sysfs_path[PATH_MAX];

static struct qfa_client_volume_priv qfa_client_volume;

struct cmd_struct {
	const char *name;
	int (*func)(int argc, char **argv);
};

struct io_stats {
	unsigned long rio, wio, rbytes, wbytes;
};
struct shard_stats {
	int shard;
	struct io_stats io_stats[2];
	struct shard_stats *next;
};

#define IO_STAT_VALUE(v1, v2, itv) (((double)((v1) - (v2)) / (itv)))

static struct shard_stats *shard_stats_list = NULL;

void show_usage(void)
{
	puts("Usage: qbdshard count [<tcp|rdma>://]<pool/volume>[@snapshot] [-c <config>]\n"
	     "       qbdshard connection [<tcp|rdma>://]<pool/volume>[@snapshot] [-c <config>] [-s <shards-list>]\n"
	     "       qbdshard iostat [<tcp|rdma>://]<pool/volume>[@snapshot] [-c <config>] [-s <shards-list>] [-i <interval>] [-C <count>]\n"
	     "       qbdshard [help|--help|-h]\n"
	     "\n"
	     "For detailed Usage: man qbdshard");
}

void free_shard_stats_list(void)
{
	struct shard_stats *next;
	while (shard_stats_list) {
		next = shard_stats_list->next;
		free(shard_stats_list);
		shard_stats_list = next;
	}
}

struct shard_stats *add_shard_stats_list(struct shard_stats **slist, int shard)
{
	struct shard_stats *stats = *slist;
	struct shard_stats *new_stats;
	char filepath[PATH_MAX * 2];

	/* check the shard file if exists */
	snprintf(filepath, sizeof(filepath), "%s/shards/%d", sysfs_path, shard);
	if (access(filepath, F_OK)) {
		errmsg("invalid shard in shards-list: shard '%d' does not exist.\n", shard);
		return NULL;
	}

	/* found shard if shard in slist */
	while (stats) {
		if (stats->shard == shard)
			return stats;
		if (stats->next && stats->next->shard > shard)
			break;
		if (stats->next == NULL)
			break;

		stats = stats->next;
	}

	new_stats = malloc(sizeof (struct shard_stats));
	if (new_stats == NULL) {
		errmsg("Out of memory.");
		exit(128);
	}
	memset(new_stats, 0, sizeof (struct shard_stats));

	new_stats->shard = shard;
	if (*slist == NULL) {
		*slist = new_stats;
	} else if ((*slist)->shard > shard){
		new_stats->next = *slist;
		*slist = new_stats;
	} else {
		new_stats->next = stats->next;
		stats->next = new_stats;
	}

	return new_stats;
}

int init_shard_stats_list_all(void)
{
	char dirpath[PATH_MAX * 2];
	DIR *shards_dir;
	struct dirent *dirent;
	struct shard_stats;

	snprintf(dirpath, sizeof(dirpath), "%s/shards", sysfs_path);
	shards_dir = opendir(dirpath);
	if (shards_dir == NULL) {
		errmsg("failed to open %s:%s\n", dirpath, strerror(errno));
		return -errno;
	}

	while((dirent = readdir(shards_dir)) != NULL) {
		if (!strcmp(dirent->d_name, ".") || !strcmp(dirent->d_name, ".."))
			continue;
		if(add_shard_stats_list(&shard_stats_list, atoi(dirent->d_name)) == NULL)
			goto out_err_free_list;
	}

	closedir(shards_dir);
	return shard_stats_list != NULL ? 0 : -EINVAL;

out_err_free_list:
	free_shard_stats_list();
	closedir(shards_dir);
	return -EINVAL;
}

/* init shard_stats_list with @str, if @str is NULL, init shard_stats_list with all shards */
int init_shard_stats_list(const char *str)
{
	char *list_str, *free_str;
	char *tok_saveptr = NULL;
	const char *c;

	if (str == NULL)
		return init_shard_stats_list_all();

	c = str;
	while (*c != '\0') {
		if (*c != ',' && *c != '-' && !isdigit(*c)) {
			errmsg("invalid shards-list: '%s'\n", str);
			return -EINVAL;
		}
		c++;
	}

	list_str = free_str = strdup(str);
	while (true) {
		char *range = strtok_r(list_str, ",", &tok_saveptr);
		char *s, *e;
		int p, q;

		if (range == NULL)
			break;
		s = strtok(range, "-");
		e = strtok(NULL, "-");
		if (s == NULL)
			break;
		if (e == NULL)
			e = s;
		p = atoi(s);
		q = atoi(e);

		for (; p <= q; p++) {
			if (add_shard_stats_list(&shard_stats_list, p) == NULL)
				goto out_err_free_str;
		}
		list_str = tok_saveptr;
	}

	free(free_str);
	return shard_stats_list != NULL ? 0 : -EINVAL;

out_err_free_str:
	free_shard_stats_list();
	free(free_str);
	return -EINVAL;
}

int show_shard_iostat_loop(void)
{
	int curr = 0;
	struct shard_stats *stats;

iostat_loop:
	for (stats = shard_stats_list; stats; stats = stats->next) {
		struct io_stats *iostats = stats->io_stats;
		FILE *file;
		char linebuf[FILE_LINE_MAXLEN];
		char filepath[PATH_MAX * 2];

		snprintf(filepath, sizeof(filepath), "%s/shards/%d", sysfs_path, stats->shard);
		file = fopen(filepath, "r");
		if (file == NULL) {
			errmsg("failed to open %s: %s", filepath, strerror(errno));
			return -errno;
		}

		while (fgets(linebuf, sizeof(linebuf), file) != NULL) {
			char *s = linebuf;
			char *iostat_line = "IO stat:";
			while(isspace(*s))
				s++;
			if (!strncmp(iostat_line, s, strlen(iostat_line)))
				break;
		}
		if (fgets(linebuf, sizeof(linebuf), file) != NULL) {
			sscanf(linebuf, "%lu %lu %lu %lu\n",
				&iostats[curr].rbytes, &iostats[curr].rio,
				&iostats[curr].wbytes, &iostats[curr].wio);

		}
		fclose(file);
	}

	printf("%-15s %10s %10s %10s %10s\n", "Shards iostat", "KB_read/s", "IO_read/s", "KB_write/s", "IO_write/s");
	for (stats = shard_stats_list; stats; stats = stats->next) {
		struct io_stats *iostats = stats->io_stats;
		char str[16];

		snprintf(str, 16, "Shard[%d]:", stats->shard);

		printf("%-15s %10.2f %10.2f %10.2f %10.2f\n", str,
			IO_STAT_VALUE(iostats[curr].rbytes / 1024, iostats[!curr].rbytes / 1024, interval),
			IO_STAT_VALUE(iostats[curr].rio, iostats[!curr].rio, interval),
			IO_STAT_VALUE(iostats[curr].wbytes / 1024, iostats[!curr].wbytes / 1024, interval),
			IO_STAT_VALUE(iostats[curr].wio, iostats[!curr].wio, interval));
	}

	if ((use_interval && !use_count) ||
	    (use_count && --count > 0)) {
		curr = !curr;
		sleep(interval);
		printf("\n");
		goto iostat_loop;
	}

	return 0;
}

int show_shard_conn_info(void)
{
	struct shard_stats *stats;

	printf("Shards connection information([+]:connected [-]:closed [@]:closing [x]:failed [?]:unknown)\n");
	for (stats = shard_stats_list; stats; stats = stats->next) {
		FILE *file;
		char linebuf[FILE_LINE_MAXLEN];
		char filepath[PATH_MAX * 2];
		bool skip_head = true;

		snprintf(filepath, sizeof(filepath), "%s/shards/%d", sysfs_path, stats->shard);
		file = fopen(filepath, "r");
		if (file == NULL) {
			errmsg("failed to open %s: %s", filepath, strerror(errno));
			return -errno;
		}

		while (fgets(linebuf, sizeof(linebuf), file) != NULL) {
			char *s = linebuf;
			char *iostat_line = "IO stat:";
			while(isspace(*s))
				s++;
			if (*s == '\0')
				break;
			if (!strncmp(iostat_line, s, strlen(iostat_line)))
				break;
			if (skip_head) {
				skip_head = false;
				continue;
			}

			printf("Shard[%d] %s", stats->shard, linebuf);
		}

		if (stats->next)
			printf("\n");
		fclose(file);
	}

	return 0;
}

int cmd_iostat(int argc, char **argv)
{
	const char *list_str = NULL;
	int rv = -EINVAL;

	while (argc > 1) {
		const char *opt = argv[1];
		bool has_arg = false;

		if (!strcmp(opt, "-s")) {
			if (argv[2] == NULL) {
				errmsg("-s option need argument.\n");
				return rv;
			}
			list_str = argv[2];
			has_arg = true;
		} else if (!strcmp(opt, "-i")) {
			if (argv[2] == NULL) {
				errmsg("-i option need argument.\n");
				return rv;
			}
			interval = atol(argv[2]);
			if (interval <= 0) {
				errmsg("invalid '%s' with -i option.\n", argv[2]);
				return rv;
			}
			use_interval = true;
			has_arg = true;
		} else if (!strcmp(opt, "-C")) {
			if (argv[2] == NULL) {
				errmsg("-C option need argument.\n");
				return rv;
			}
			count = atol(argv[2]);
			if (count <= 0) {
				errmsg("invalid '%s' with -C option.\n", argv[2]);
				return rv;
			}
			use_count = true;
			has_arg = true;
		} else {
			errmsg("Unexpected option: '%s', use help|--help|-h for usage.\n", argv[1]);
			return rv;
		}

		if (has_arg) {
			argc -= 2;
			argv += 2;
		} else {
			argc--;
			argv++;
		}
	}

	rv = init_shard_stats_list(list_str);
	if (rv)
		return rv;

	rv = show_shard_iostat_loop();
	free_shard_stats_list();

	return rv;
}

int cmd_connection(int argc, char **argv)
{
	const char *list_str = NULL;
	int rv = -EINVAL;

	while (argc > 1) {
		const char *opt = argv[1];
		bool has_arg = false;

		if (!strcmp(opt, "-s")) {
			if (argv[2] == NULL) {
				errmsg("-s option need argument.\n");
				return rv;
			}
			list_str = argv[2];
			has_arg = true;
		} else {
			errmsg("Unexpected option: '%s', use help|--help|-h for usage.\n", argv[1]);
			return rv;
		}

		if (has_arg) {
			argc -= 2;
			argv += 2;
		} else {
			argc--;
			argv++;
		}
	}

	rv = init_shard_stats_list(list_str);
	if (rv)
		return rv;

	rv = show_shard_conn_info();
	free_shard_stats_list();

	return rv;
}

int cmd_count(int argc, char **argv)
{
	char dirpath[PATH_MAX * 2];
	DIR *shards_dir;
	struct dirent *dirent;
	int max = 0;
	int shard;

	if (argc > 1) {
		errmsg("Unexpected option: '%s', use help|--help|-h for usage.\n", argv[1]);
		return -EINVAL;
	}

	snprintf(dirpath, sizeof(dirpath), "%s/shards", sysfs_path);
	shards_dir = opendir(dirpath);
	if (shards_dir == NULL) {
		errmsg("failed to open %s:%s\n", dirpath, strerror(errno));
		return -errno;
	}

	while((dirent = readdir(shards_dir)) != NULL) {
		if (!strcmp(dirent->d_name, ".") || !strcmp(dirent->d_name, ".."))
			continue;
		shard = atoi(dirent->d_name);
		if (shard > max)
			max = shard;
	}
	closedir(shards_dir);
	printf("shard count: %d\n", max);

	return 0;
}

static const struct cmd_struct cmds[] = {
	{"iostat", cmd_iostat},
	{"connection", cmd_connection},
	{"count", cmd_count},
	{NULL, NULL}
};

int main(int argc, char **argv)
{
	const struct cmd_struct *cmd;
	char filepath_buf[PATH_MAX], *filepath_ptr;
	char devname[QBD_DEVNAME_MAXLEN];
	int rv = 0;

	signal(SIGPIPE, SIG_IGN);

	if (argc < 2 ||
	    !strcmp(argv[1], "help") || !strcmp(argv[1], "--help") || !strcmp(argv[1], "-h")) {
		show_usage();
		return 0;
	}

	/* parse command name */
	for (cmd = cmds; cmd->name != NULL; cmd++) {
		if (!strcmp(cmd->name, argv[1])) {
			break;
		}
	}

	if (cmd->name == NULL) {
		printf("Unknown '%s' command.\n", argv[1]);
		show_usage();
		return -EINVAL;
	}

	/* set qfa_client_volume default properties */
	memset(&qfa_client_volume, 0, sizeof(struct qfa_client_volume_priv));
	qfa_client_volume.cfg_file = (struct config_file *)malloc(sizeof(struct config_file));
	if (qfa_client_volume.cfg_file == NULL) {
		errmsg("failed to malloc config_file, out of memory.\n");
		return -ENOMEM;
	}
	strcpy(qfa_client_volume.cfg_file->cfg_file, DEFAULT_CONFIG_FILE);
	qfa_client_volume.cfg_file->root = NULL;

	argc--;
	argv++;
	rv = -EINVAL;
	/* parse volume name */
	if (argc > 1) {
		rv = set_vol_name_type(&qfa_client_volume, argv[1]);
		argc--;
		argv++;
	} else {
		errmsg("please specify [<tcp|rdma>://]<pool/volume>[@snapshot].\n");
		goto out_free;
	}

	/* parse config file */
	if (argc > 1 && !strcmp("-c", argv[1])) {
		if (argv[2] == NULL) {
			errmsg("-c option need argument.\n");
			goto out_free;
		}
		filepath_ptr = realpath(argv[2], filepath_buf);
		if (!filepath_ptr) {
			errmsg("config file with -c: '%s' %s\n", argv[2], strerror(errno));
			goto out_free;
		}
		strcpy(qfa_client_volume.cfg_file->cfg_file, filepath_buf);
		argc -= 2;
		argv += 2;
	}

	/* set qbd sysfs path, example: /sys/block/qbd0 */
	rv = get_device_name_by_vol(&qfa_client_volume, devname);
	if (rv) {
		errmsg("failed to get device name %s%s%s%s:%s, please check if has mapped\n",
		       legacy_protocol ? "" : (qfa_client_volume.transport == RDMA ? "rdma://" : "tcp://"),
		       qfa_client_volume.name,
		       qfa_client_volume.snap_name[0] ? "" : "@",
		       qfa_client_volume.snap_name[0] ? "" : qfa_client_volume.snap_name,
		       qfa_client_volume.cfg_file->cfg_file);
		goto out_free;
	}
	snprintf(sysfs_path, sizeof(sysfs_path), "%s/%s", QBD_SYSFS_BASE_PATH, devname);

	rv = cmd->func(argc, argv);

out_free:
	free(qfa_client_volume.cfg_file);
	return rv;
}
