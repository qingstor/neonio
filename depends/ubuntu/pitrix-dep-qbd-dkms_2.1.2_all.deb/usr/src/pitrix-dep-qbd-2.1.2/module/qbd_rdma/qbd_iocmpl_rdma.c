#include <linux/slab.h>
#include "qbd_queue.h"
#include "qbd_message.h"
#include "qbd_iocmpl_rdma.h"
#include "qbd_client_rdma.h"

int qbd_init_iocmpl_pool_rdma(struct qbd_iocmpl_pool_rdma *pool, int pool_size, int block_size)
{
	int rc = 0;
	int i;
	if (pool_size >= 65535)
		return -EINVAL;

	pool->size = pool_size;
	pool->nr_alloced = 0;

	rc = init_queue(&pool->free_list, pool_size);
	if (rc)
		return rc;

	pool->iocmpls = kzalloc(pool_size * sizeof(struct iocmpl_rdma), GFP_KERNEL);
	if (pool->iocmpls == NULL) {
		rc = -ENOMEM;
		goto err_destroy_queue;
	}

	/* init iocmpl member */
	for (i = 0; i < pool_size; i++) {
		pool->iocmpls[i].type = DESC_IOCMPL;
		pool->iocmpls[i].id = i;
		pool->iocmpls[i].cmpl.status = cpu_to_le16(0);
	}

	for (i = 0; i < pool_size; i++)
		enqueue(&pool->free_list, &pool->iocmpls[i]);

	return 0;

err_destroy_queue:
	destroy_queue(&pool->free_list);
	return rc;
}

void qbd_release_iocmpl_pool_rdma(struct qbd_iocmpl_pool_rdma *pool, int block_size)
{
	kfree(pool->iocmpls);
	destroy_queue(&pool->free_list);
}

/*
 * replace client->iocmpl_pool with new and destroy the old.
 */
void qbd_replace_iocmpl_pool_rdma(struct qbd_client_rdma *client, struct qbd_iocmpl_pool_rdma *new)
{
	struct qbd_iocmpl_pool_rdma old = client->iocmpl_pool;
	struct qbd_iocmpl_pool_rdma *pool = &client->iocmpl_pool;
	unsigned long flags;

	spin_lock_irqsave(&pool->free_list.lock, flags);
	BUG_ON(pool->nr_alloced != 0);
	pool->nr_alloced	  = new->nr_alloced;
	pool->size	  = new->size;
	pool->iocmpls = new->iocmpls;
	swap_queue(&pool->free_list, &new->free_list);
	spin_unlock_irqrestore(&pool->free_list.lock, flags);

	qbd_release_iocmpl_pool_rdma(&old, client->vol->max_blocksize);
}
