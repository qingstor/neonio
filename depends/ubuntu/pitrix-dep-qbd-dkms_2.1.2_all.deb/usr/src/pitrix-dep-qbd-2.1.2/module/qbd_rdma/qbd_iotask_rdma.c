#include <linux/slab.h>
#include "qbd_queue.h"
#include "qbd_message.h"
#include "qbd_iotask_rdma.h"
#include "qbd_client_rdma.h"

int qbd_init_iotask_pool_rdma(struct qbd_iotask_pool_rdma *pool, int pool_size, int block_size)
{
	int rc = 0;
	int i;
	if (pool_size >= 65535)
		return -EINVAL;

	pool->size = pool_size;
	pool->nr_alloced = 0;

	rc = init_queue(&pool->free_list, pool_size);
	if (rc)
		return rc;

	pool->iotasks = kzalloc(pool_size * sizeof(struct iotask_rdma), GFP_KERNEL);
	if (pool->iotasks == NULL) {
		rc = -ENOMEM;
		goto err_destroy_queue;
	}

	/* alloc rdma memory region for transfer, will map when setup connection */
	pool->cmd_buf = kmalloc(pool_size * sizeof(struct qbd_command), GFP_KERNEL);
	if (pool->cmd_buf == NULL) {
		rc = -ENOMEM;
		goto err_free_iotasks;
	}
	pool->block_buf = kmalloc(pool_size * sizeof(void *), GFP_KERNEL);
	if (pool->block_buf == NULL) {
		rc = -ENOMEM;
		goto err_free_cmd_buf;
	}

	/* init iotask member */
	for (i = 0; i < pool_size; i++) {
		pool->iotasks[i].type = DESC_IOTASK;
		pool->iotasks[i].cmd = &pool->cmd_buf[i];
		pool->iotasks[i].cmd->opcode = QBD_OP_UNKNOWN;
		pool->iotasks[i].cmd->command_id = cpu_to_le16(i);
		pool->iotasks[i].cmd->flags = 0x80;
		pool->iotasks[i].snd_processing = false;
		pool->block_buf[i] = (void *)__get_free_pages(GFP_KERNEL, fls(block_size) - PAGE_SHIFT - 1);
		if (pool->block_buf[i] == NULL) {
			rc = -ENOMEM;
			goto err_free_block_buf;
		}
		pool->iotasks[i].block = (char *)pool->block_buf[i];
	}

	for (i = 0; i < pool_size; i++)
		enqueue(&pool->free_list, &pool->iotasks[i]);

	rwlock_init(&pool->walk_lock);

	return 0;

err_free_block_buf:
	for (i--; i >= 0; i--) {
		free_pages((unsigned long)pool->block_buf[i], fls(block_size) - PAGE_SHIFT - 1);
	}
	kfree(pool->block_buf);
err_free_cmd_buf:
	kfree(pool->cmd_buf);
err_free_iotasks:
	kfree(pool->iotasks);
err_destroy_queue:
	destroy_queue(&pool->free_list);
	return rc;
}

/*
 * alloc iotask_rdma struct.
 * alloc successed return iotask_rdma pointer and NOMEM or qbd->flags was setted
 * QBD_DEV_FLAG_IODEPTH_RESIZING return NULL.
 */
struct iotask_rdma *qbd_alloc_iotask_rdma(struct qbd_iotask_pool_rdma *pool)
{
	struct qbd_client_rdma *client = container_of(pool, struct qbd_client_rdma, iotask_pool);
	struct qbd_device *qbd = client->vol->qbd;
	struct iotask_rdma *iotask;
	unsigned long flags;

	spin_lock_irqsave(&pool->free_list.lock, flags);

	if (unlikely(pool->nr_alloced >= client->vol->max_io_depth ||
		     test_bit(QBD_DEV_FLAG_IODEPTH_RESIZING, &qbd->flags))) {
		spin_unlock_irqrestore(&pool->free_list.lock, flags);
		return NULL;
	}

	iotask = __dequeue(&pool->free_list);
	if (iotask != NULL) {
		BUG_ON(iotask->type != DESC_IOTASK);
		BUG_ON(iotask->conn != NULL);
		BUG_ON(iotask->status != 0);
		BUG_ON(iotask->snd_processing != false);
		BUG_ON(iotask->io_processing != false);
		BUG_ON(iotask->ts_post != 0);
		BUG_ON(iotask->cmd->opcode != QBD_OP_UNKNOWN);
		BUG_ON(le16_to_cpu(iotask->cmd->command_id) > pool->size);
		++pool->nr_alloced;
	}

	spin_unlock_irqrestore(&pool->free_list.lock, flags);

	return iotask;
}

void qbd_free_iotask_rdma(struct qbd_iotask_pool_rdma *pool, struct iotask_rdma *iotask)
{
	unsigned long flags;

	iotask->conn = NULL;
	iotask->status = 0;
	iotask->snd_processing = false;
	iotask->io_processing = false;
	iotask->ts_post = 0;
	iotask->cmd->opcode = QBD_OP_UNKNOWN;

	spin_lock_irqsave(&pool->free_list.lock, flags);
	BUG_ON(__enqueue(&pool->free_list, iotask));
	--pool->nr_alloced;
	spin_unlock_irqrestore(&pool->free_list.lock, flags);
}

void qbd_release_iotask_pool_rdma(struct qbd_iotask_pool_rdma *pool, int block_size)
{
	int i;
	for (i = 0; i < pool->size; i++) {
		free_pages((unsigned long)pool->block_buf[i], fls(block_size) - PAGE_SHIFT - 1);
	}
	kfree(pool->block_buf);
	kfree(pool->cmd_buf);
	kfree(pool->iotasks);
	destroy_queue(&pool->free_list);
}

/*
 * qbd_client_rdma replace functions:
 * replace client->snd_queue/rty_queue/cmpl_queue/iotask_pool with
 * new and destroy the old.
 */
void qbd_replace_snd_queue_rdma(struct qbd_client_rdma *client, struct queue *new)
{
	unsigned long flags;

	spin_lock_irqsave(&client->snd_queue.lock, flags);
	BUG_ON(!queue_is_empty(&client->snd_queue));
	swap_queue(&client->snd_queue, new);
	spin_unlock_irqrestore(&client->snd_queue.lock, flags);
	destroy_queue(new);
}

void qbd_replace_rty_queue_rdma(struct qbd_client_rdma *client, struct queue *new)
{
	unsigned long flags;

	spin_lock_irqsave(&client->snd_queue.lock, flags);
	BUG_ON(!queue_is_empty(&client->snd_queue));
	swap_queue(&client->snd_queue, new);
	spin_unlock_irqrestore(&client->snd_queue.lock, flags);
	destroy_queue(new);
}

void qbd_replace_cmpl_queue_rdma(struct qbd_client_rdma *client, struct queue *new)
{
	unsigned long flags;

	spin_lock_irqsave(&client->cmpl_queue.lock, flags);
	BUG_ON(!queue_is_empty(&client->cmpl_queue));
	swap_queue(&client->cmpl_queue, new);
	spin_unlock_irqrestore(&client->cmpl_queue.lock, flags);
	destroy_queue(new);
}

void qbd_replace_iotask_pool_rdma(struct qbd_client_rdma *client, struct qbd_iotask_pool_rdma *new)
{
	struct qbd_iotask_pool_rdma old = client->iotask_pool;
	struct qbd_iotask_pool_rdma *pool = &client->iotask_pool;
	unsigned long flags;

	write_lock(&pool->walk_lock);
	spin_lock_irqsave(&pool->free_list.lock, flags);
	BUG_ON(pool->nr_alloced != 0);
	pool->nr_alloced = new->nr_alloced;
	pool->size       = new->size;
	pool->iotasks    = new->iotasks;
	pool->cmd_buf    = new->cmd_buf;
	pool->block_buf  = new->block_buf;
	swap_queue(&pool->free_list, &new->free_list);
	spin_unlock_irqrestore(&pool->free_list.lock, flags);
	write_unlock(&pool->walk_lock);

	qbd_release_iotask_pool_rdma(&old, client->vol->max_blocksize);
}
