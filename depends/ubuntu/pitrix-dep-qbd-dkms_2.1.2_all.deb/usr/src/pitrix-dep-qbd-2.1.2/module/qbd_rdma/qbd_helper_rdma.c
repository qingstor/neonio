#include <linux/mm.h>
#include <linux/sched.h>
#include "qbd.h"
#include "qbd_message.h"
#include "qbd_helper_rdma.h"
#include "qbd_client_rdma.h"
#include "linux/mm_compat.h"
#include "linux/rdma_compat.h"

int rdma_post_recv_completion(struct qbd_conn *conn, struct iocmpl_rdma *iocmpl)
{
	struct qbd_rdma *rdma = conn->rdma;
	struct ib_recv_wr rwr;
	struct ib_sge sge;

	ib_dma_sync_single_for_device(conn->rdma->cm_id->device,
				      conn->cmpl_dbuf[iocmpl->id],
				      sizeof(struct qbd_completion),
				      DMA_FROM_DEVICE);
	sge.addr = conn->cmpl_dbuf[iocmpl->id];
	sge.length = sizeof(struct qbd_completion);
	sge.lkey = rdma->pd->local_dma_lkey;

	rwr.next = NULL;
	rwr.wr_id = (unsigned long)iocmpl;
	rwr.sg_list = &sge;
	rwr.num_sge = 1;
	return ib_post_recv(rdma->qp, &rwr, NULL);
}

int rdma_post_send_command(struct qbd_conn *conn, struct iotask_rdma *iotask)
{
	struct qbd_rdma *rdma = conn->rdma;
	struct ib_send_wr swr;
	struct ib_sge sge;

	switch (iotask->cmd->opcode) {
	case QBD_OP_WRITE:
		memcpy(iotask->block, iotask->buf_addr, le32_to_cpu(iotask->cmd->buf_len));
		ib_dma_sync_single_for_device(conn->rdma->cm_id->device,
					      conn->block_dbuf[le16_to_cpu(iotask->cmd->command_id)],
					      conn->vol->max_blocksize,
					      DMA_TO_DEVICE);
		break;
	case QBD_OP_READ:
		ib_dma_sync_single_for_device(conn->rdma->cm_id->device,
					      conn->block_dbuf[le16_to_cpu(iotask->cmd->command_id)],
					      conn->vol->max_blocksize,
					      DMA_FROM_DEVICE);
		break;
	case QBD_OP_HEARTBEAT:
		break;
	default:
		qbd_err("[%s] %s invalid opcode: %d with io:%px cid:%d",
			conn->vol->qbd->devname,
			__func__,
			iotask->cmd->opcode,
			iotask,
			le16_to_cpu(iotask->cmd->command_id));
		return -EINVAL;
	}

	iotask->cmd->rkey = cpu_to_le32(conn->mr->rkey);
	iotask->cmd->buf_addr = cpu_to_le64(conn->block_dbuf[le16_to_cpu(iotask->cmd->command_id)]);
	sge.addr = conn->cmd_dbuf[le16_to_cpu(iotask->cmd->command_id)],
	sge.length = sizeof(struct qbd_command);
	sge.lkey = conn->mr->lkey;
	ib_dma_sync_single_for_device(conn->rdma->cm_id->device,
				      conn->cmd_dbuf[le16_to_cpu(iotask->cmd->command_id)],
				      sizeof(struct qbd_command),
				      DMA_TO_DEVICE);

	swr.next = NULL;
	swr.wr_id = (unsigned long)iotask;
	swr.sg_list = &sge;
	swr.num_sge = 1;
	swr.opcode = IB_WR_SEND;
	swr.send_flags = IB_SEND_SIGNALED;
	return ib_post_send(rdma->qp, &swr, NULL);
}

/*
 * assume that all work requests will be polled from cq no matter success or failed,
 * btw:handler may be called in interrupt
 */
static void qbd_cq_comp_handler(struct ib_cq *cq, void *cq_context)
{
	struct qbd_conn *conn = cq_context;
	struct qbd_volume *vol = conn->vol;
	struct qbd_rdma *rdma = conn->rdma;
	struct qbd_client_rdma *client = conn->vol->client;
	union qbd_reply {
		DESC_TYPE type;
		struct iotask_rdma iotask;
		struct iocmpl_rdma iocmpl;
	} *reply;
	struct iotask_rdma *iotask;
	struct ib_wc wc[QBD_RDMA_MAX_WC];
	int n, i;
	unsigned long flags = 0;
	bool conn_failed;

	ib_req_notify_cq(rdma->cq, IB_CQ_NEXT_COMP);
	while ((n = ib_poll_cq(cq, QBD_RDMA_MAX_WC, wc)) > 0) {
		for (i = 0; i < n; i++) {
			reply = (union qbd_reply *)wc[i].wr_id;
			qbd_detailed_debug(vol->qbd, "[%s] conn:%px get wc from cq, wr_id:%px, type:%d, wc.status:%d(%s)",
					   vol->qbd->devname,
					   conn,
					   reply,
					   reply->type,
					   wc[i].status,
					   ib_wc_status_msg(wc[i].status));
			if (wc[i].status != IB_WC_SUCCESS) {
				/* cannot use wc.opcode, it is invalid when error happened */
				qbd_dev_err_ratelimited(vol->qbd, "[%s] conn:%px get failed wc from cq, wr_id:%px, type:%d, wc.status:%d(%s)",
							vol->qbd->devname,
							conn,
							reply,
							reply->type,
							wc[i].status,
							ib_wc_status_msg(wc[i].status));
				switch (reply->type) {
				case DESC_IOCMPL:
					ib_dma_sync_single_for_cpu(conn->rdma->cm_id->device,
								   conn->cmpl_dbuf[reply->iocmpl.id],
								   sizeof(struct qbd_completion),
								   DMA_FROM_DEVICE);
					qbd_free_iocmpl_rdma(&client->iocmpl_pool, &reply->iocmpl);
					client->status |= CLIENT_STATUS_RESET_CONN;
					rdma->cmpl_recv_count++;
					break;
				case DESC_IOTASK:
					/*
					 * In failed case, we cannot decide which iotasks should be retried send with iocmpl, but iotask.
					 * 1. In case of network down, iotask(s) flush with IB_WC_RETRY_EXC_ERR or IB_WC_WR_FLUSH_ERR,
					 *    iocmpl(s) flush with IB_WC_WR_FLUSH_ERR.
					 * 2. In case of neonstore crashed, usually iotask(s) poll with IB_WC_SUCCESS,
					 *    after rdma_disconnect called, iocmpl(s) flush with IB_WC_WR_FLUSH_ERR.
					 */
					client->status |= CLIENT_STATUS_RESET_CONN;
					conn->status = CONN_STATUS_FAILED;
					reply->iotask.status = -EAGAIN;
					spin_lock_irqsave(&client->cmpl_lock, flags);
					BUG_ON(enqueue(&client->cmpl_queue, &reply->iotask));
					rdma->cmpl_send_count++;
					spin_unlock_irqrestore(&client->cmpl_lock, flags);
					break;
				default:
					qbd_fatal("[%s] conn:%px get failed wc from cq, wr_id:%px, type:%d, wc.status:%d(%s)",
						  vol->qbd->devname,
						  conn,
						  reply,
						  reply->type,
						  wc[i].status,
						  ib_wc_status_msg(wc[i].status));
					break;
				}
				continue;
			}

			/* handling the success operations */
			switch (wc[i].opcode) {
			case IB_WC_SEND:
				BUG_ON(reply->type != DESC_IOTASK);
				/* do not set iotask snd_processing status, it may return later than iocmpl and freed */
				rdma->cmpl_send_count++;
				break;
			case IB_WC_RECV:
				BUG_ON(reply->type != DESC_IOCMPL);
				ib_dma_sync_single_for_cpu(conn->rdma->cm_id->device,
							   conn->cmpl_dbuf[reply->iocmpl.id],
							   sizeof(struct qbd_completion),
							   DMA_FROM_DEVICE);
				iotask = qbd_pick_iotask_rdma(&client->iotask_pool, le16_to_cpu(reply->iocmpl.cmpl.command_id));
				/* we will recv proccessing iotask here, otherwise neonsan may have trouble */
				BUG_ON(!iotask->io_processing);
				/*
				 * TODO:
				 * iotask may get NULL if neonstore returned invalid command_id,
				 * for tcp, it will retry with known iotask 'qsr->iotask' on this connection,
				 * but rdma cannot get iotask on this connection,
				 * currently, I have no idea how to deal with it,
				 * so driver will panic the kernel with iotask 'NULL pointer' with neonstore's faulty.
				 */
				switch (le16_to_cpu(reply->iocmpl.cmpl.status)) {
				case QBD_SC_SUCCESS:
					iotask->status = 0;
					break;
				case QBD_SC_REOPEN | QBD_SC_RETRY:
					qbd_dev_info_ratelimited(vol->qbd, "[%s] received completion status: QBD_SC_REOPEN|QBD_SC_RETRY with cid:%d",
								 vol->qbd->devname,
								 le16_to_cpu(reply->iocmpl.cmpl.command_id));
					client->status |= CLIENT_STATUS_REOPEN_VOL;
					vol->open_ts = 0; /* force reopen */
					conn->status = CONN_STATUS_FAILED;
					iotask->status = -EAGAIN;
					break;
				default:
					qbd_dev_err_ratelimited(vol->qbd, "[%s] get failed completion status:%#x",
								vol->qbd->devname,
								le16_to_cpu(reply->iocmpl.cmpl.status));
					iotask->status = -EIO;
					break;
				}
				qbd_free_iocmpl_rdma(&client->iocmpl_pool, &reply->iocmpl);
				conn_failed = (conn->status != CONN_STATUS_CONNECTED);
				if (unlikely(conn_failed))
					spin_lock_irqsave(&client->cmpl_lock, flags);
				BUG_ON(enqueue(&client->cmpl_queue, iotask));
				rdma->cmpl_recv_count++;
				if (unlikely(conn_failed))
					spin_unlock_irqrestore(&client->cmpl_lock, flags);
				wake_up_process(client->cmpl_thread);
				break;
			default:
				qbd_fatal("[%s] %s unhandled wc.opcode:%d", vol->qbd->devname, __func__, wc[i].opcode);
				break;
			}
		}
	}
}

static int qbd_cm_event_handler(struct rdma_cm_id *id, struct rdma_cm_event *event)
{
	struct qbd_conn *conn = id->context;
	struct qbd_rdma *rdma = conn->rdma;

	switch (event->event) {
	case RDMA_CM_EVENT_ADDR_RESOLVED:
		BUG_ON(rdma->state != QBD_RDMA_STATE_INIT);
		rdma->state = QBD_RDMA_STATE_ADDR_RESOLVED;
		break;

	case RDMA_CM_EVENT_ROUTE_RESOLVED:
		BUG_ON(rdma->state != QBD_RDMA_STATE_ADDR_RESOLVED);
		rdma->state = QBD_RDMA_STATE_ROUTE_RESOLVED;
		break;

	case RDMA_CM_EVENT_ESTABLISHED:
		BUG_ON(rdma->state != QBD_RDMA_STATE_ROUTE_RESOLVED);
		rdma->state = QBD_RDMA_STATE_CONNECTED;
		break;

	case RDMA_CM_EVENT_DISCONNECTED:
		rdma->state = QBD_RDMA_STATE_FLUSHING;
		qbd_info("[%s] rdma conn:%px disconnected with %d(%s), status:%d, conn->status:%d",
			 conn->vol->qbd->devname,
			 conn,
			 event->event,
			 rdma_event_msg(event->event),
			 event->status,
			 conn->status);

		if (conn->status == CONN_STATUS_CONNECTED)
			rdma_disconnect(rdma->cm_id);
		rdma->state = QBD_RDMA_STATE_CLOSING;
		conn->status = CONN_STATUS_FAILED;
		break;

	case RDMA_CM_EVENT_TIMEWAIT_EXIT:
		qbd_info("[%s] rdma conn:%px event with %d(%s), status:%d",
			conn->vol->qbd->devname,
			conn,
			event->event,
			rdma_event_msg(event->event),
			event->status);
		/* all wr has flushed */
		rdma->state = QBD_RDMA_STATE_CLOSED;
		break;

	case RDMA_CM_EVENT_ADDR_CHANGE:
	case RDMA_CM_EVENT_ROUTE_ERROR:
	case RDMA_CM_EVENT_DEVICE_REMOVAL:
	case RDMA_CM_EVENT_MULTICAST_JOIN:
	case RDMA_CM_EVENT_MULTICAST_ERROR:
	case RDMA_CM_EVENT_REJECTED: /*
				      * neonstore may reject with self defined message,
				      * we don't show the result, just return reject error,
				      * if want detail, please check neonsan log.
				      */
	case RDMA_CM_EVENT_CONNECT_REQUEST:
	case RDMA_CM_EVENT_CONNECT_RESPONSE:
	case RDMA_CM_EVENT_CONNECT_ERROR:
	case RDMA_CM_EVENT_ADDR_ERROR:
	case RDMA_CM_EVENT_UNREACHABLE:
		qbd_err("[%s] rdma conn:%px error with %d(%s), status:%d(%s)",
			conn->vol->qbd->devname,
			conn,
			event->event,
			rdma_event_msg(event->event),
			event->status,
			ibcm_reject_msg(event->status));
		if (event->event == RDMA_CM_EVENT_REJECTED && event->status == IB_CM_REJ_STALE_CONN) {
			/* need retry with rdma */
			rdma->state = QBD_RDMA_STATE_RETRY;
		}
		else if (conn->status > CONN_STATUS_UNKNOWN) {
			conn->status = CONN_STATUS_FAILED;
			rdma_disconnect(rdma->cm_id);
		}
		break;

	default:
		qbd_fatal("unhandled rdma cm event:%d", event->event);
	}
	complete(&rdma->cm_done);
	return 0;
}

static void qbd_cq_event_handler(struct ib_event *event, void *context)
{
	qbd_info("CQ event %d context %px\n", event->event, context);
}

static void qbd_qp_event_handler(struct ib_event *event, void *context)
{
	qbd_info("QP event %d context %px\n", event->event, context);
}
#ifdef HAVE_KERNEL_TIMER_FUNCTION_TIMER_LIST
static void rdma_connect_timeout(struct timer_list *tl)
{
	struct qbd_rdma *rdma = from_timer(rdma, tl, rdma_connect_timer);
#else
static void rdma_connect_timeout(unsigned long data)
{
	struct qbd_rdma *rdma = (struct qbd_rdma *)data;
#endif
	qbd_err("[%s] rdma_connect timeout!", rdma->conn->vol->qbd->devname);
	rdma->state = QBD_RDMA_STATE_CONNECT_FAILED;
	complete(&rdma->cm_done);
}

int rdma_open(struct qbd_conn *conn, struct sockaddr_in *addr, int conn_timeout)
{
	int i;
	int err;
	int timeout;
	struct qbd_rdma *rdma;
	struct handshake hs;
	struct rdma_conn_param conn_param;
	struct ib_qp_init_attr qp_init_attr;
	struct ib_cq_init_attr cq_init_attr = {};
	struct ib_qp_attr qp_attr;
	struct ib_device_attr dev_attr;
	struct qbd_volume *vol = conn->vol;
	struct qbd_client_rdma *client = vol->client;

	rdma = conn->rdma = kzalloc(sizeof(struct qbd_rdma), GFP_KERNEL);
	if (!rdma) {
		qbd_err("[%s] kzalloc qbd_rdma oom", vol->qbd->devname);
		return -ENOMEM;
	}

	rdma->conn = conn;
	init_completion(&rdma->cm_done);

	rdma->post_send_count = 0;
	rdma->post_recv_count = 0;
	rdma->cmpl_send_count = 0;
	rdma->cmpl_recv_count = 0;

	/* we must keep iotask and dbuf_* are same size */
	rdma->max_io_depth = get_iodepth_by_pool_size_rdma(client->iotask_pool.size);

retry_rdma_connect:
	rdma->state = QBD_RDMA_STATE_INIT;
	rdma->cm_id = rdma_create_id(&init_net, qbd_cm_event_handler, conn, RDMA_PS_TCP, IB_QPT_RC);
	if (IS_ERR(rdma->cm_id)) {
		qbd_err("[%s] rdma_create_id failed", vol->qbd->devname);
		goto err_free_rdma;
	}

	err = rdma_resolve_addr(rdma->cm_id, NULL, (struct sockaddr *)addr, conn_timeout * 1000L);
	if (err) {
		qbd_err("[%s] rdma_resovle_addr failed:%d", vol->qbd->devname, err);
		goto err_destroy_id;
	}

	err = wait_for_completion_interruptible(&rdma->cm_done);
	if (err || rdma->state != QBD_RDMA_STATE_ADDR_RESOLVED) {
		qbd_err("[%s] wait for rdma_resovle_addr failed:%d, state:%d", vol->qbd->devname, err, rdma->state);
		goto err_destroy_id;
	}

	err = rdma_resolve_route(rdma->cm_id, conn_timeout * 1000L);
	if (err) {
		qbd_err("[%s] rdma_resovle_route failed:%d", vol->qbd->devname, err);
		goto err_destroy_id;
	}

	err = wait_for_completion_interruptible(&rdma->cm_done);
	if (err || rdma->state != QBD_RDMA_STATE_ROUTE_RESOLVED) {
		qbd_err("[%s] wait for rdma_resovle_route failed:%d, state:%d", vol->qbd->devname, err, rdma->state);
		goto err_destroy_id;
	}

	rdma->pd = ib_alloc_pd(rdma->cm_id->device, 0);
	if (IS_ERR(rdma->pd)) {
		qbd_err("[%s] ib_alloc_pd failed:%ld", vol->qbd->devname, PTR_ERR(rdma->pd));
		goto err_destroy_id;
	}

	cq_init_attr.cqe = vol->max_io_depth * 2;
	rdma->cq = ib_create_cq(rdma->cm_id->device, qbd_cq_comp_handler, qbd_cq_event_handler, conn, &cq_init_attr);
	if (IS_ERR(rdma->cq)) {
		qbd_err("[%s] ib_create_cq failed:%ld", vol->qbd->devname, PTR_ERR(rdma->cq));
		goto err_dealloc_pd;
	}
	ib_req_notify_cq(rdma->cq, IB_CQ_NEXT_COMP);

	memset(&qp_init_attr, 0, sizeof(qp_init_attr));
	qp_init_attr.event_handler = qbd_qp_event_handler;
	qp_init_attr.qp_context = conn;
	qp_init_attr.cap.max_send_wr = vol->max_io_depth * 2;	/* for cmd and data request */
	qp_init_attr.cap.max_recv_wr = vol->max_io_depth * 2;	/* for cmd and data request */
	qp_init_attr.cap.max_send_sge = 1;
	qp_init_attr.cap.max_recv_sge = 1;
	qp_init_attr.sq_sig_type = IB_SIGNAL_REQ_WR;
	qp_init_attr.qp_type = IB_QPT_RC;
	qp_init_attr.send_cq = rdma->cq;
	qp_init_attr.recv_cq = rdma->cq;
	err = rdma_create_qp(rdma->cm_id, rdma->pd, &qp_init_attr);
	if (err) {
		qbd_err("[%s] rdma_create_qp failed:%d", vol->qbd->devname, err);
		goto err_destroy_cq;
	}
	rdma->qp = rdma->cm_id->qp;

	err = ib_query_device(rdma->cm_id->device, &dev_attr);
	if (err) {
		err = -10;
		goto err_destroy_qp;
	}

	/* handshake with rdma_connect */
	memset(&hs, 0, sizeof(hs));
	hs.hsqsize = vol->max_io_depth * 2;
	hs.vol_id = conn->vol->id;
	hs.snap_seq = conn->vol->snap_seq;
	hs.protocol_ver = PROTOCOL_VER;
	hs.io_timeout = vol->io_timeout;
	memset(&conn_param, 0, sizeof(conn_param));
	conn_param.private_data = &hs;
	conn_param.private_data_len = sizeof(hs);
	conn_param.responder_resources = min(dev_attr.max_qp_rd_atom, vol->max_io_depth * 2);
	conn_param.initiator_depth = min(dev_attr.max_qp_rd_atom, vol->max_io_depth * 2);
	/*
	 * qp timeout cannot be setup with rdma_create_qp, so we have to set inaccurate timeout value.
	 * qp_attr.timeout is set to 19(2147484usec, 2.14 sec) at most time by default,
	 * we have to adjust retry_count(max 7) to set timeout value.
	 * refer to https://www.rdmamojo.com/2013/01/12/ibv_modify_qp/
	 * btw: ib_modify_qp not work after rdma_connect.
	 */
	timeout = vol->io_timeout * 1000000L / 2147484 / 2;
	conn_param.retry_count = timeout > 7 ? 7 : timeout;
	conn_param.rnr_retry_count = 7;
	/*
	 * rdma_connect timeout depends on packet lifetime which is difficult to be tuned,
	 * setup timer to force quit when rdma_connect timeout.
	 */
	setup_timer(&rdma->rdma_connect_timer, rdma_connect_timeout, (unsigned long)rdma);
	mod_timer(&rdma->rdma_connect_timer, jiffies + msecs_to_jiffies(conn_timeout * 1000L));
	err = rdma_connect(rdma->cm_id, &conn_param);
	if (err) {
		qbd_err("[%s] rdma_connect failed:%d", vol->qbd->devname, err);
		del_timer_sync(&rdma->rdma_connect_timer);
		goto err_destroy_qp;
	}
	err = wait_for_completion_interruptible(&rdma->cm_done);
	del_timer_sync(&rdma->rdma_connect_timer);
	if (rdma->state == QBD_RDMA_STATE_RETRY) {
		rdma_destroy_qp(rdma->cm_id);
		ib_destroy_cq(rdma->cq);
		ib_dealloc_pd(rdma->pd);
		rdma_destroy_id(rdma->cm_id);
		qbd_err("[%s] rdma_connect failed, retry rdma_connect", vol->qbd->devname);
		goto retry_rdma_connect;
	}
	if (err || rdma->state != QBD_RDMA_STATE_CONNECTED) {
		qbd_err("[%s] wait for rdma_connect failed:%d, state:%d", vol->qbd->devname, err, rdma->state);
		goto err_rdma_disconnect;
	}

	/* show timeout value, adjust if not */
	err = ib_query_qp(rdma->qp, &qp_attr, IB_QP_TIMEOUT, &qp_init_attr);
	if (err) {
		qbd_err("[%s] ib_query_qp timeout failed:%d", vol->qbd->devname, err);
		goto err_rdma_disconnect;
	}
	qbd_info("[%s] qp timeout set to *about* (4.096*2^%dus)*%d*2=%lldus",
		 vol->qbd->devname,
		 qp_attr.timeout,
		 conn_param.retry_count + 1,
		 4096LL * (1 << qp_attr.timeout) * (conn_param.retry_count + 1) * 2 / 1000);

	/* alloc dbuf arrary to store dma addresses */
	conn->cmd_dbuf = kmalloc(sizeof(u64) * rdma->max_io_depth, GFP_KERNEL);
	if (conn->cmd_dbuf == NULL) {
		qbd_err("[%s] kmalloc cmd_dbuf failed", vol->qbd->devname);
		goto err_rdma_disconnect;
	}
	conn->cmpl_dbuf = kmalloc(sizeof(u64) * rdma->max_io_depth, GFP_KERNEL);
	if (conn->cmpl_dbuf == NULL) {
		qbd_err("[%s] kmalloc cmpl_dbuf failed", vol->qbd->devname);
		goto err_kfree_cmd_dbuf;
	}
	conn->block_dbuf = kmalloc(sizeof(u64) * rdma->max_io_depth, GFP_KERNEL);
	if (conn->block_dbuf == NULL) {
		qbd_err("[%s] kmalloc block_dbuf failed", vol->qbd->devname);
		goto err_kfree_cmpl_dbuf;
	}

	/* register memory region */
	conn->mr = ib_get_dma_mr(rdma->pd, IB_ACCESS_LOCAL_WRITE | IB_ACCESS_REMOTE_WRITE | IB_ACCESS_REMOTE_READ);
	if (IS_ERR(conn->mr)) {
		qbd_err("[%s] ib_get_dma_mr failed:%ld", vol->qbd->devname, PTR_ERR(conn->mr));
		goto err_kfree_block_dbuf;
	}
	/* map dma buffers */
	for (i = 0; i < rdma->max_io_depth; i++) {
		conn->cmd_dbuf[i] = ib_dma_map_single(rdma->cm_id->device,
						      &client->iotask_pool.cmd_buf[i],
						      sizeof(struct qbd_command),
						      DMA_TO_DEVICE);
		if (ib_dma_mapping_error(rdma->cm_id->device, conn->cmd_dbuf[i])) {
			qbd_err("[%s] ib_dma_map_single cmd_dbuf[%d] failed", vol->qbd->devname, i);
			goto err_unmap_cmd_dbuf;
		}
	}
	for (i = 0; i < rdma->max_io_depth; i++) {
		conn->block_dbuf[i] = ib_dma_map_single(rdma->cm_id->device,
							(char *)client->iotask_pool.block_buf[i],
							vol->max_blocksize,
							DMA_BIDIRECTIONAL);
		if (ib_dma_mapping_error(rdma->cm_id->device, conn->block_dbuf[i])) {
			qbd_err("[%s] ib_dma_map_single block_dbuf[%d] failed", vol->qbd->devname, i);
			goto err_unmap_block_dbuf;
		}
	}
	for (i = 0; i < rdma->max_io_depth; i++) {
		conn->cmpl_dbuf[i] = ib_dma_map_single(rdma->cm_id->device,
						       &client->iocmpl_pool.iocmpls[i].cmpl,
						       sizeof(struct qbd_completion),
						       DMA_FROM_DEVICE);
		if (ib_dma_mapping_error(rdma->cm_id->device, conn->cmpl_dbuf[i])) {
			qbd_err("[%s] ib_dma_map_single cmpl_dbuf[%d] failed", vol->qbd->devname, i);
			goto err_unmap_cmpl_dbuf;
		}
	}
	return 0;

err_unmap_cmpl_dbuf:
	for (i--; i >=0 ; i--)
		ib_dma_unmap_single(rdma->cm_id->device,
				    conn->cmpl_dbuf[i],
				    sizeof(struct qbd_completion),
				    DMA_FROM_DEVICE);
	i = rdma->max_io_depth;
err_unmap_block_dbuf:
	for (i--; i >=0 ; i--)
		ib_dma_unmap_single(rdma->cm_id->device,
				    conn->block_dbuf[i],
				    vol->max_blocksize,
				    DMA_FROM_DEVICE);
	i = rdma->max_io_depth;
err_unmap_cmd_dbuf:
	for (i--; i >=0 ; i--)
		ib_dma_unmap_single(rdma->cm_id->device,
				    conn->cmd_dbuf[i],
				    sizeof(struct qbd_command),
				    DMA_BIDIRECTIONAL);
	ib_dereg_mr(conn->mr);
err_kfree_block_dbuf:
	kfree(conn->block_dbuf);
err_kfree_cmpl_dbuf:
	kfree(conn->cmpl_dbuf);
err_kfree_cmd_dbuf:
	kfree(conn->cmd_dbuf);
err_rdma_disconnect:
	rdma_disconnect(rdma->cm_id);
err_destroy_qp:
	rdma_destroy_qp(rdma->cm_id);
err_destroy_cq:
	ib_destroy_cq(rdma->cq);
err_dealloc_pd:
	ib_dealloc_pd(rdma->pd);
err_destroy_id:
	rdma_destroy_id(rdma->cm_id);
err_free_rdma:
	kfree(rdma);
	return -EINVAL;
}

int rdma_close(struct qbd_conn *conn)
{
	struct qbd_rdma *rdma = conn->rdma;
	struct qbd_volume *vol = conn->vol;
	int i;

	rdma_disconnect(rdma->cm_id);
	/* wait until all qp and cq flushed */
	while (rdma->post_send_count != rdma->cmpl_send_count ||
	       rdma->post_recv_count != rdma->cmpl_recv_count) {
		qbd_info("[%s] %s conn:%px waiting for cq finish flushing, post_send_count:%llu, cmpl_send_count:%llu, "
			 "post_recv_count:%llu, cmpl_recv_count:%llu",
			 vol->qbd->devname, __func__, conn,
			 rdma->post_send_count, rdma->cmpl_send_count,
			 rdma->post_recv_count, rdma->cmpl_recv_count);
		schedule_timeout_interruptible(msecs_to_jiffies(1000));
	}
	qbd_info("[%s] %s conn:%px cq finished flushing", vol->qbd->devname, __func__, conn);
	for (i = 0; i < rdma->max_io_depth; i++)
		ib_dma_unmap_single(rdma->cm_id->device,
				    conn->cmpl_dbuf[i],
				    sizeof(struct qbd_completion),
				    DMA_FROM_DEVICE);
	for (i = 0; i < rdma->max_io_depth; i++)
		ib_dma_unmap_single(rdma->cm_id->device,
				    conn->block_dbuf[i],
				    vol->max_blocksize,
				    DMA_FROM_DEVICE);
	for (i = 0; i < rdma->max_io_depth; i++)
		ib_dma_unmap_single(rdma->cm_id->device,
				    conn->cmd_dbuf[i],
				    sizeof(struct qbd_command),
				    DMA_BIDIRECTIONAL);
	kfree(conn->block_dbuf);
	kfree(conn->cmpl_dbuf);
	kfree(conn->cmd_dbuf);
	rdma_destroy_qp(rdma->cm_id);
	ib_destroy_cq(rdma->cq);
	ib_dereg_mr(conn->mr);
	ib_dealloc_pd(rdma->pd);
	rdma_destroy_id(rdma->cm_id);
	kfree(rdma);
	return 0;
}
