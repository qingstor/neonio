#include "qbd.h"
#include "qbd_client.h"
#include "qbd_message.h"
#include "qbd_hashtable.h"
#include "qbd_client_rdma.h"
#include "qbd_conn_rdma.h"
#include "qbd_helper_rdma.h"

/*
 * Timer function for sending heartbeat io to store.
 * We will send heartbeat io each qbd->heartbeat_timeout.
 * If client is busy in io handing, all qbd_alloc_iotask and iotask enqueue failed,
 * then store will close the connection for more resources.
 * We never promise HEARTBEAT IO can be send to store when client is busy.
 */
#ifdef HAVE_KERNEL_TIMER_FUNCTION_TIMER_LIST
static void rdma_send_heartbeat(struct timer_list *tl)
{
	struct qbd_conn *conn = from_timer(conn, tl, hb_timer);
#else
static void rdma_send_heartbeat(unsigned long data)
{
	struct qbd_conn *conn = (struct qbd_conn *)data;
#endif
	struct qbd_volume *vol = conn->vol;
	struct qbd_client_rdma *client = conn->vol->client;
	struct iotask_rdma *iotask = NULL;
	struct qbd_command *cmd;

	if (test_bit(QBD_DEV_FLAG_REMOVING, &vol->qbd->flags))
		return;
	if (conn->status != CONN_STATUS_CONNECTED)
		return;
	if (get_now_nsec() - conn->last_send_time < 1000000000LL * vol->qbd->heartbeat_timeout)
		goto out_mod_timer;
	if ((iotask = qbd_alloc_iotask_rdma(&client->iotask_pool)) == NULL)
		goto out_mod_timer;
	qbd_detailed_debug(vol->qbd, "[%s] alloc cid:%d io:%px",
			   vol->qbd->devname,
			   le16_to_cpu(iotask->cmd->command_id),
			   iotask);
	iotask->status = 0;
	iotask->ulp_handler = NULL;
	iotask->ulp_arg = NULL;
	iotask->vol = conn->vol;
	iotask->conn = NULL;

	cmd = iotask->cmd;
	cmd->opcode = QBD_OP_HEARTBEAT;
	cmd->vol_id	= cpu_to_le64(conn->vol->id);
	cmd->buf_addr	= cpu_to_le64(0);
	cmd->rkey	= cpu_to_le64(0);
	cmd->buf_len	= cpu_to_le64(0);
	cmd->slba	= cpu_to_le64((uint64_t)conn->shard << QBD_SECTORS_PER_SHARD_BITS);
	cmd->nlba	= cpu_to_le64(0);
	cmd->snap_seq	= cpu_to_le32(conn->vol->snap_seq);
	cmd->meta_ver	= cpu_to_le16(vol->meta_ver);

	if (enqueue(&client->snd_queue, iotask) != 0)
		qbd_free_iotask_rdma(&client->iotask_pool, iotask);
	else
		qbd_detailed_debug(vol->qbd, "[%s] %s succeed", vol->qbd->devname, __func__);

out_mod_timer:
	mod_timer(&conn->hb_timer, jiffies + msecs_to_jiffies(1000LL * vol->qbd->heartbeat_timeout));
}

int qbd_rdma_init_conn(struct qbd_conn *conn, struct qbd_volume *vol, struct sockaddr_in *addr)
{
	int rc;
	conn->vol = vol;
	memcpy(&conn->addr, addr, sizeof(struct sockaddr_in));
	conn->status = CONN_STATUS_UNKNOWN;
	rc = rdma_open(conn, addr, vol->conn_timeout);
	if (rc) {
		qbd_err("[%s] rdma_open failed:%d", vol->qbd->devname, rc);
		goto err_out;
	}
	/* hanshake is done with rdma_connect */
	qbd_info("[%s] rdma handshake succeed", vol->qbd->devname);

	conn->status = CONN_STATUS_CONNECTED;
	conn->last_send_time = get_now_nsec();
	setup_timer(&conn->hb_timer, rdma_send_heartbeat, (unsigned long)conn);
	mod_timer(&conn->hb_timer, jiffies + msecs_to_jiffies(1000LL * vol->qbd->heartbeat_timeout));

	return 0;

err_out:
	conn->status = CONN_STATUS_FAILED;
	return -1;
}

void qbd_rdma_release_conn(struct qbd_conn *conn)
{
	struct qbd_client_rdma *client = conn->vol->client;
	sht_delete(client->conn_pool.conn_table, &conn->addr);
}

void _qbd_rdma_release_conn(struct qbd_conn *conn)
{
	qbd_info("[%s] release rdma connection %pI4:%hu",
		 conn->vol->qbd->devname,
		 &conn->addr.sin_addr,
		 ntohs(conn->addr.sin_port));
	del_timer_sync(&conn->hb_timer);
	conn->status = CONN_STATUS_CLOSING;
	rdma_close(conn);
	conn->status = CONN_STATUS_CLOSED;
	kfree(conn);
}
