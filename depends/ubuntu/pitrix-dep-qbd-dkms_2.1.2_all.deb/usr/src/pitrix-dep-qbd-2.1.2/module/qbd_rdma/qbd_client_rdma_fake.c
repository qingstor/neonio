#include <linux/net.h>
#include <linux/kmod.h>
#include <linux/kthread.h>
#include <linux/delay.h>
#include <linux/blkdev.h>
#include <linux/vmalloc.h>
#include "qbd.h"

static int __init qbd_rdma_init(void)
{
	printk("Module qbd_rdma is not installed correctly, if you want to use it, "
	       "please install ofed driver first and then reinstall qbd driver!");
	return -EINVAL;
}

static void __exit qbd_rdma_exit(void)
{
}

module_init(qbd_rdma_init);
module_exit(qbd_rdma_exit);

MODULE_VERSION(VERSION);
MODULE_AUTHOR("QingCloud Kernel Group <kernel_group@yunify.com>");

MODULE_DESCRIPTION(QBD_DESCRIPTION " for rdma(this is fake module for dkms installation)");
MODULE_LICENSE("GPL");
