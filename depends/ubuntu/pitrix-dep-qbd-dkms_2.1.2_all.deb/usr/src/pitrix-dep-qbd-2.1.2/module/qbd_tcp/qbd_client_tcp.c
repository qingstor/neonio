#include <linux/net.h>
#include <linux/kmod.h>
#include <linux/kthread.h>
#include <linux/delay.h>
#include <linux/blkdev.h>
#include <linux/vmalloc.h>

#include "qbd.h"
#include "qbd_helper_tcp.h"
#include "qbd_client.h"
#include "qbd_message.h"
#include "qbd_conn_tcp.h"
#include "qbd_client_tcp.h"
#include "qbd_crypt.h"
#include "linux/sched_compat.h"

struct kmem_cache *qs_request_cache;	/* qbd session cache */

/*
 * We will proceed all io requests with snd_thread and rcv_thread.
 * when io requests proceed with store and issue happened,
 * conn->status or vol->status will be set, then snd_thread will be suspended,
 * rcv_thread will take actions after all send out io requests returned.
 *
 * qsr->status stands for the io status during proceed, not iotask->status.
 */
static int qbd_tcp_snd_thread(void *data)
{
	struct qbd_volume *vol = data;
	struct qbd_device *qbd = vol->qbd;
	struct qbd_client_tcp *client = vol->client;
	struct qs_request *qsr = NULL;
	struct iotask_tcp *iotask;
	struct qbd_command cmd;
	int shard;
	int ret;

	set_user_nice(current, MIN_NICE);
	while (true) {
		if (client->status != CLIENT_STATUS_OK) {
			/* tell rcv_thread we are ready to take actions */
			qbd_info("[%s] complete snd_completion", qbd->devname);
			complete(&client->snd_completion);
			/* wait for actions done */
			qbd_info("[%s] waiting for qbd_tcp_issue_helper done", qbd->devname);
			wait_for_completion(&client->rty_completion);
		}
		if ((iotask = dequeue(&client->rty_queue)) == NULL &&
		    (iotask = dequeue(&client->snd_queue)) == NULL) {
			if (kthread_should_stop())
				break;
			schedule_timeout_interruptible(msecs_to_jiffies(100));
			continue;
		}

		if (!mutex_trylock(&client->snd_lock)) {
			BUG_ON(enqueue(&client->rty_queue, iotask) != 0);
			schedule_timeout_interruptible(msecs_to_jiffies(100));
			continue;
		}

		if (qbd_should_tc(&client->tc, &vol->qos, le32_to_cpu(iotask->io_cmd.buf_len))) {
			BUG_ON(enqueue(&client->rty_queue, iotask) != 0);
			mutex_unlock(&client->snd_lock);
			schedule_timeout_interruptible(msecs_to_jiffies(100));
			continue;
		}

		if (atomic_read(&client->sending_iotask_count) >= vol->max_io_depth) {
			BUG_ON(enqueue(&client->rty_queue, iotask) != 0);
			mutex_unlock(&client->snd_lock);
			schedule_timeout_interruptible(msecs_to_jiffies(100));
			continue;
		}

		/*
		 * when device reopened, meta_ver may updated because of store upgrade,
		 * and retry iotask will take old meta_ver, update cmd->meta_ver before send
		 */
		iotask->io_cmd.meta_ver = cpu_to_le16(vol->meta_ver);
		qsr = kmem_cache_alloc(qs_request_cache, GFP_NOIO);
		if (qsr == NULL) {
			qbd_dev_err_ratelimited(qbd, "[%s] failed to kmalloc_cache_alloc qs_request_cache, retry",
						qbd->devname);
			BUG_ON(enqueue(&client->rty_queue, iotask) != 0);
			mutex_unlock(&client->snd_lock);
			schedule_timeout_interruptible(msecs_to_jiffies(100));
			continue;
		}

		atomic_inc(&client->sending_iotask_count);

		qbd_detailed_debug(qbd, "[%s] send qbd io cid:%d op:%d %llu:%d status:%d",
				   qbd->devname,
				   le16_to_cpu(iotask->io_cmd.command_id),
				   iotask->io_cmd.opcode,
				   le64_to_cpu(iotask->io_cmd.slba),
				   le16_to_cpu(iotask->io_cmd.nlba),
				   iotask->status);
		/* iotask->status may get -INVALID */
		qsr->status = iotask->status;
		qsr->iotask = iotask;
		iotask->processing = true;
		/*
		 * After iotask send out, it is unsafe to use it again,
		 * take a copy of io_cmd for later use
		 */
		memcpy(&cmd, &iotask->io_cmd, sizeof(struct qbd_command));
		/* Mark send to store time and check if timeout from ts_start */
		if (likely(iotask->io_cmd.opcode != QBD_OP_HEARTBEAT))
			qbd_check_send_timeout((struct qb_request *)iotask->ulp_arg);

		if (unlikely(qsr->status != 0)) {
			/*
			 * When get invalid iotask, deliver with iotask->conn = NULL,
			 * it will skip iotask send and receive
			 */
			qsr->conn = NULL;
		} else {
			shard = le64_to_cpu(iotask->io_cmd.slba) >> QBD_SECTORS_PER_SHARD_BITS;
			qsr->conn = iotask->conn = (vol->status == VOLUME_STATUS_ERROR ?
						    NULL : qbd_get_shard_conn(vol, &client->conn_pool, shard));
			if (unlikely(iotask->conn == NULL)) {
				/*
				 * If qbd open/reopen volume failed, it will be retired for qbd_retire_seconds seconds,
				 * during this time, return io error directly
				 */
				if (vol->status == VOLUME_STATUS_ERROR &&
				    get_now_nsec() - vol->open_ts < 1000000000LL * qbd_retire_seconds) {
					qsr->status = -EIO;
				} else {
					client->status |= CLIENT_STATUS_REOPEN_VOL;
					qsr->status = -EAGAIN;
				}
			} else if (iotask->conn->status == CONN_STATUS_CONNECTED) {
				iotask->conn->last_send_time = get_now_nsec();
				BUG_ON(!iotask->processing);	/* iotask is freed somewhere */
				ret = socket_send_all(qsr->conn->skt, &iotask->io_cmd,
						      sizeof(struct qbd_command));
				/* io may have returned and freed, do not use it again */
				if (ret != sizeof(struct qbd_command)) {
					qbd_dev_err_ratelimited(qbd, "[%s] send command failed:%d",
								qbd->devname,
								ret);
					client->status |= CLIENT_STATUS_RESET_CONN;
					qsr->conn->status = CONN_STATUS_FAILED;
					qsr->status = -EAGAIN;
				} else if (cmd.opcode == QBD_OP_WRITE) {
					ret = socket_send_all(qsr->conn->skt, (void *)le64_to_cpu(cmd.buf_addr),
							      le32_to_cpu(cmd.buf_len));
					if (ret != le32_to_cpu(cmd.buf_len)) {
						qbd_dev_err_ratelimited(qbd, "[%s] send data failed:%d",
									qbd->devname,
									ret);
						client->status |= CLIENT_STATUS_RESET_CONN;
						qsr->conn->status = CONN_STATUS_FAILED;
						qsr->status = -EAGAIN;
					}
				}
			} else {
				client->status |= CLIENT_STATUS_RESET_CONN;
				qsr->status = -EAGAIN;
			}
		}
		/* Nothing should do with iotask member as io may have returned from store */
		while (enqueue(&client->qs_queue, qsr) != 0) {
			qbd_detailed_debug(vol->qbd, "[%s] %s enqueue qs_queue full",
					   vol->qbd->devname,
					   __func__);
			schedule_timeout_interruptible(usecs_to_jiffies(10));
		}

		qbd_detailed_debug(vol->qbd, "[%s] send qbd io cid:%d op:%d %llu:%d done with status:%d",
				   vol->qbd->devname,
				   le16_to_cpu(cmd.command_id),
				   cmd.opcode,
				   le64_to_cpu(cmd.slba),
				   le16_to_cpu(cmd.nlba),
				   qsr->status);
		mutex_unlock(&client->snd_lock);
		wake_up_process(client->rcv_thread);
	}
	return 0;
}

/*
 * Work for shard reconnection and volume reopen,
 * before enter this function, send thread must have been suspended
 */
static int qbd_tcp_issue_helper(void *data)
{
	struct qbd_volume *vol = data;
	struct qbd_client_tcp *client = vol->client;
	struct qbd_conn *conn;
	struct iotask_tcp *iotask;
	int cid, gcid;

	vol->status = VOLUME_STATUS_RESETTING;

	if (client->status & CLIENT_STATUS_KERNEL_IO_TIMEOUT) {
		qbd_err("[%s] return all kernel io timeout io(s) with error, %s%s%s%s",
			vol->qbd->devname,
			vol->legacy_protocol ? "" : "tcp://",
			vol->name,
			vol->snap_name[0] == '\0' ? "" : "@",
			vol->snap_name[0] == '\0' ? "" : vol->snap_name);

		cleanup_conn_pool(&client->conn_pool);

		read_lock(&client->iotask_pool.walk_lock);
		for (cid = 0; cid < client->iotask_pool.size; cid++) {
			iotask = qbd_pick_iotask_tcp(&client->iotask_pool, cid);
			if (iotask->processing) {
				if (iotask->io_cmd.opcode == QBD_OP_HEARTBEAT) {
					qbd_free_iotask_tcp(&client->iotask_pool, iotask);
					continue;
				}
				iotask->ulp_handler(-EIO, iotask->ulp_arg);
				qbd_detailed_debug(vol->qbd, "[%s] helper free timeout cid:%d io:%px",
						   vol->qbd->devname,
						   le16_to_cpu(iotask->io_cmd.command_id),
						   iotask);
				qbd_free_iotask_tcp(&client->iotask_pool, iotask);
			}
		}
		read_unlock(&client->iotask_pool.walk_lock);
		/*
		 * We hope that user can see some EIO(s) happend as soon as possible, so run into
		 * the qbd_retire_seconds.
		 */
		vol->open_ts = get_now_nsec();
		vol->status = VOLUME_STATUS_ERROR;
	} else if (client->status & CLIENT_STATUS_REOPEN_VOL) {
		qbd_info("[%s] reopen volume: %s%s%s%s now",
			 vol->qbd->devname,
			 vol->legacy_protocol ? "" : "tcp://",
			 vol->name,
			 vol->snap_name[0] == '\0' ? "" : "@",
			 vol->snap_name[0] == '\0' ? "" : vol->snap_name);

		cleanup_conn_pool(&client->conn_pool);
		/*
		 * volume status is set to VOLUEM_STATUS_OPENED when qbd_reopen_volume return zero, and
		 * set to VOLUME_STATUS_ERROR when qbd_reopen_volume return non-zero.
		 */
		if (qbd_reopen_volume(vol)) {
			/* Reopen volume failed, return all io with -EIO */
			qbd_err("[%s] reopen volume: %s%s%s%s failed",
				vol->qbd->devname,
				vol->legacy_protocol ? "" : "tcp://",
				vol->name,
				vol->snap_name[0] == '\0' ? "" : "@",
				vol->snap_name[0] == '\0' ? "" : vol->snap_name);
			read_lock(&client->iotask_pool.walk_lock);
			for (cid = 0; cid < client->iotask_pool.size; cid++) {
				iotask = qbd_pick_iotask_tcp(&client->iotask_pool, cid);
				if (iotask->processing) {
					if (iotask->io_cmd.opcode == QBD_OP_HEARTBEAT) {
						qbd_free_iotask_tcp(&client->iotask_pool, iotask);
						continue;
					}
					iotask->ulp_handler(-EIO, iotask->ulp_arg);
					qbd_detailed_debug(vol->qbd, "[%s] helper free cid:%d io:%px",
							   vol->qbd->devname,
							   le16_to_cpu(iotask->io_cmd.command_id),
							   iotask);
					qbd_free_iotask_tcp(&client->iotask_pool, iotask);
				}
			}
			read_unlock(&client->iotask_pool.walk_lock);
		} else {
			qbd_info("[%s] reopen volume: %s%s%s%s succeed",
				 vol->qbd->devname,
				 vol->legacy_protocol ? "" : "tcp://",
				 vol->name,
				 vol->snap_name[0] == '\0' ? "" : "@",
				 vol->snap_name[0] == '\0' ? "" : vol->snap_name);
			read_lock(&client->iotask_pool.walk_lock);
			for (cid = 0; cid < client->iotask_pool.size; cid++) {
				iotask = qbd_pick_iotask_tcp(&client->iotask_pool, cid);
				if (iotask->processing) {
					iotask->processing = false;
					iotask->conn = NULL;
					qbd_detailed_debug(vol->qbd, "[%s] resend io with cid[%d]",
							   vol->qbd->devname,
							   le16_to_cpu(iotask->io_cmd.command_id));
					BUG_ON(enqueue(&client->rty_queue, iotask) != 0);
				}
			}
			read_unlock(&client->iotask_pool.walk_lock);
		}
	} else if (client->status & CLIENT_STATUS_RESET_CONN) {
		qbd_info("[%s] reset connection of volume: %s%s%s%s",
			 vol->qbd->devname,
			 vol->legacy_protocol ? "" : "tcp://",
			 vol->name,
			 vol->snap_name[0] == '\0' ? "" : "@",
			 vol->snap_name[0] == '\0' ? "" : vol->snap_name);
		/*
		 * Find out all the proccessing io with invalid connection,
		 * enqueue rty_queue and release the connection.
		 */
		read_lock(&client->iotask_pool.walk_lock);
		for (gcid = 0; gcid < client->iotask_pool.size; gcid++) {
			iotask = qbd_pick_iotask_tcp(&client->iotask_pool, gcid);
			if (iotask->processing && iotask->conn != NULL
			    && iotask->conn->status != CONN_STATUS_CONNECTED) {
				/* Find out invalied io with same connection and reset */
				conn = iotask->conn;
				for (cid = gcid; cid < client->iotask_pool.size; cid++) {
					iotask = qbd_pick_iotask_tcp(&client->iotask_pool, cid);
					if (iotask->processing && conn == iotask->conn) {
						iotask->processing = false;
						iotask->conn = NULL;
						qbd_detailed_debug(vol->qbd, "[%s] resend io with cid[%d]",
								   vol->qbd->devname,
								   le16_to_cpu(iotask->io_cmd.command_id));
						BUG_ON(enqueue(&client->rty_queue, iotask) != 0);
					}
				}
				qbd_tcp_release_conn(conn);
			}
		}
		read_unlock(&client->iotask_pool.walk_lock);
		/* now vol->status is *RESETTING*, and set it to *OPENED* */
		vol->status = VOLUME_STATUS_OPENED;
	} else {
		qbd_fatal("[%s] unhandled client->status:%lx", vol->qbd->devname, client->status);
	}

	client->status = CLIENT_STATUS_OK;

	qbd_info("[%s] %s done", vol->qbd->devname, __func__);
	return 0;
}

/*
 * End all heartbeat ios of iotask_pool when qbd_tcp_rcv_thread exit.
 */
static void end_hb_io_all_tcp(struct qbd_iotask_pool_tcp *iotask_pool)
{
	int cid;
	struct iotask_tcp *iotask;

	read_lock(&iotask_pool->walk_lock);
	for (cid = 0; cid < iotask_pool->size; cid++) {
		iotask = qbd_pick_iotask_tcp(iotask_pool, cid);
		if (iotask->processing) {
			if (iotask->io_cmd.opcode == QBD_OP_HEARTBEAT) {
				qbd_free_iotask_tcp(iotask_pool, iotask);
				continue;
			}
		}
	}
	read_unlock(&iotask_pool->walk_lock);
}

/*
 * Receive io requests from store in disorder
 */
static int qbd_tcp_rcv_thread(void *data)
{
	struct qbd_volume *vol = data;
	struct qbd_client_tcp *client = vol->client;
	struct qbd_conn *conn = NULL;
	struct iotask_tcp *iotask = NULL;
	struct qs_request *qsr = NULL;
	struct qbd_completion cmpl;
	ulp_io_handler ulp_handler;
	void *ulp_arg;
	int ret;

	set_user_nice(current, MIN_NICE);
	while (true) {
		if ((qsr = dequeue(&client->qs_queue)) == NULL) {
			if (client->status != CLIENT_STATUS_OK) {
				if (mutex_trylock(&client->snd_lock)) {
					/* qs_queue may enqueue between dequeue and mutex_trylock */
					if (!queue_is_empty(&client->qs_queue)) {
						mutex_unlock(&client->snd_lock);
						continue;
					}
					qbd_info("[%s] wait for snd_completion", vol->qbd->devname);

					if (!wait_for_completion_timeout(&client->snd_completion, msecs_to_jiffies(1000))) {
						if (kthread_should_stop()) {
							mutex_unlock(&client->snd_lock);
							end_hb_io_all_tcp(&client->iotask_pool);
							break;
						} else {
							mutex_unlock(&client->snd_lock);
							continue;
						}
					}

					qbd_info("[%s] get snd_completion, time to issue helper", vol->qbd->devname);
					/*
					 * Before run into qbd_tcp_issue_helper,
					 * qs_queue must be empty.
					 */
					BUG_ON(dequeue(&client->qs_queue) != NULL);
					qbd_tcp_issue_helper(vol);
					mutex_unlock(&client->snd_lock);
					complete(&client->rty_completion);
					continue;
				}
			}

			if (kthread_should_stop()) {
				break;
			}
			schedule_timeout_interruptible(msecs_to_jiffies(100));
			continue;
		}
		/*
		 * IO task of qsr may have released as io with same connection may have received
		 * in disorder, so any member from qsr->iotask is inaccurate, we will get right io
		 * with received qbd_completion.
		 * But if qsr->conn is NULL, it cannot be proccessed before, it is right io.
		 */
		iotask = qsr->iotask;
		qbd_detailed_debug(vol->qbd, "[%s] dequeued io from qs_queue with cid:%d(inaccurate), receiving qbd io",
				   vol->qbd->devname,
				   le16_to_cpu(iotask->io_cmd.command_id));
		conn = qsr->conn;
		if (conn != NULL && conn->status == CONN_STATUS_CONNECTED) {
			ret = socket_recv_all(conn->skt, &cmpl, sizeof(struct qbd_completion));
			if (ret != sizeof(struct qbd_completion)) {
				/* Do not print this error message triggered by us call the qbd_tcp_disconnect_all()
				 * when qbd unmap, because it may make us puzzled.
				 */
				if (likely(!test_bit(QBD_DEV_FLAG_REMOVING, &vol->qbd->flags))) {
					qbd_dev_err_ratelimited(vol->qbd, "[%s] recv completion failed:%d",
								vol->qbd->devname,
								ret);
				}
				client->status |= CLIENT_STATUS_RESET_CONN;
				conn->status = CONN_STATUS_FAILED;
				qsr->status = -EAGAIN;
			} else {
				/* io return from store are not in sequence, pick the right iotask */
				iotask = qbd_pick_iotask_tcp(&client->iotask_pool, le16_to_cpu(cmpl.command_id));
				if (likely(iotask != NULL)) {
					if (iotask->io_cmd.opcode == QBD_OP_HEARTBEAT) {
						/* handle with heartbeat io completion status */
						switch (le16_to_cpu(cmpl.status)) {
						case QBD_SC_SUCCESS:
							qsr->status = 0;
							break;
						case QBD_SC_REOPEN | QBD_SC_RETRY:
							qbd_info("[%s] received hearbeat io completion status:"
								 "QBD_SC_REOPEN|QBD_SC_RETRY with cid:%d",
								 vol->qbd->devname, le16_to_cpu(cmpl.command_id));
							client->status |= CLIENT_STATUS_REOPEN_VOL;
							vol->open_ts = 0; /* force reopen */
							conn->status = CONN_STATUS_FAILED;
							qsr->status = -EAGAIN;
							break;
						default:
							qbd_dev_err_ratelimited(vol->qbd, "[%s] unhandled heartbeat io failed completion status:%#x",
										vol->qbd->devname,
										le16_to_cpu(cmpl.status));
							qsr->status = -EIO;
							break;
						}
						goto recv_done;
					}
					/* handle with the completion status */
					switch (le16_to_cpu(cmpl.status)) {
					case QBD_SC_SUCCESS:
						break;
					case QBD_SC_REOPEN | QBD_SC_RETRY:
						qbd_info("[%s] received completion status:"
							 "QBD_SC_REOPEN|QBD_SC_RETRY with cid:%d",
							 vol->qbd->devname, le16_to_cpu(cmpl.command_id));
						client->status |= CLIENT_STATUS_REOPEN_VOL;
						vol->open_ts = 0;	/* force reopen */
						conn->status = CONN_STATUS_FAILED;
						qsr->status = -EAGAIN;
						break;
					default:
						qbd_dev_err_ratelimited(vol->qbd, "[%s] get failed completion status:%#x",
									vol->qbd->devname,
									le16_to_cpu(cmpl.status));
						qsr->status = -EIO;
						break;
					}

					if (le16_to_cpu(cmpl.status) == QBD_SC_SUCCESS
					    && iotask->io_cmd.opcode == QBD_OP_READ) {
						ret = socket_recv_all(conn->skt, (void *)
								      le64_to_cpu(iotask->io_cmd.buf_addr),
								      le16_to_cpu(iotask->io_cmd.nlba)
								      << QBD_SECTOR_BITS);
						if (ret != (le16_to_cpu(iotask->io_cmd.nlba) << QBD_SECTOR_BITS)) {
							qbd_dev_err_ratelimited(vol->qbd, "[%s] recv data failed:%d",
										vol->qbd->devname,
										ret);
							client->status |= CLIENT_STATUS_RESET_CONN;
							conn->status = CONN_STATUS_FAILED;
							qsr->status = -EAGAIN;
						}
					}
				} else {
					qbd_dev_err_ratelimited(vol->qbd, "[%s] qbd_pick_iotask with NULL io",
								vol->qbd->devname);
					client->status |= CLIENT_STATUS_RESET_CONN;
					conn->status = CONN_STATUS_FAILED;
					qsr->status = -EAGAIN;
				}
			}
		} else if (qsr->status == 0) {
			/* send succeed and connection set failed with other io */
			qsr->status = -EAGAIN;
		}

recv_done:
		qbd_detailed_debug(vol->qbd, "[%s] received qbd io%s cid:%d %d %llu:%d status:%d",
				   vol->qbd->devname,
				   qsr->status ? "(inaccurate)" : "",
				   le16_to_cpu(iotask->io_cmd.command_id),
				   iotask->io_cmd.opcode,
				   le64_to_cpu(iotask->io_cmd.slba),
				   le16_to_cpu(iotask->io_cmd.nlba),
				   qsr->status);

		atomic_dec(&client->sending_iotask_count);

		switch (qsr->status) {
		case -EAGAIN:
			/*
			 * when store designed QBD_SC_REOPEN and QBD_SC_RETRY returned separately,
			 * this logic should change.
			 *
			 * there is a iotask(s) that is set to EAGAIN by only the CLIENT_STATUS_REOPEN_VOL
			 * or CLIENT_STATUS_RESET_CONN, so don't check other client status here.
			 */
			BUG_ON(!(client->status &
			       (CLIENT_STATUS_REOPEN_VOL | CLIENT_STATUS_RESET_CONN)));
			break;
		default:
			/* must be the right io */
			if (qsr->status != 0 && qsr->status != -EDISCARD)
				qbd_dev_err_ratelimited(vol->qbd, "[%s] %s [%llu:%d] op:%d failed:%d",
							vol->qbd->devname,
							iotask->io_cmd.opcode == QBD_OP_HEARTBEAT ? "hb" : "aio",
							le64_to_cpu(iotask->io_cmd.slba),
							le16_to_cpu(iotask->io_cmd.nlba),
							iotask->io_cmd.opcode,
							qsr->status);
			qbd_detailed_debug(vol->qbd, "[%s] free cid:%d io:%px",
					   vol->qbd->devname,
					   le16_to_cpu(iotask->io_cmd.command_id),
					   iotask);
			BUG_ON(!iotask->processing); /* io has already freed, double free */
			if (iotask->io_cmd.opcode == QBD_OP_HEARTBEAT) {
				qbd_free_iotask_tcp(&client->iotask_pool, iotask);
				wake_up_process(client->snd_thread);
				break;
			}
			ulp_handler = iotask->ulp_handler;
			ulp_arg = iotask->ulp_arg;
			qbd_free_iotask_tcp(&client->iotask_pool, iotask);
			wake_up_process(client->snd_thread);
			if (likely(qsr->status != -EDISCARD))
				ulp_handler(qsr->status, ulp_arg);
			else
				/* volume resumed to discard io */
				ulp_handler(0, ulp_arg);
			break;
		}
		kmem_cache_free(qs_request_cache, qsr);
	}
	return 0;
}

/*
 * For checking kernel io timeout
 */
static int qbd_tcp_watchdog_thread(void *data)
{
	struct qbd_volume *vol = data;
	struct qbd_client_tcp *client = vol->client;
	struct iotask_tcp *iotask = NULL;
	int cid;

	set_user_nice(current, MIN_NICE);
	while (!kthread_should_stop()) {
		if (client->status & CLIENT_STATUS_KERNEL_IO_TIMEOUT)
			goto sleep_and_continue;

		read_lock(&client->iotask_pool.walk_lock);
		for (cid = 0; cid < client->iotask_pool.size; cid++) {
			iotask = qbd_pick_iotask_tcp(&client->iotask_pool, cid);
			if (iotask->ts_iostart &&
			    qbd_check_kernel_io_timeout(iotask->ts_iostart)) {
				client->status |= CLIENT_STATUS_KERNEL_IO_TIMEOUT;
				/*
				 * we need to disconnect all connections for the rcv_thread can immediately return from
				 * socket_recv_all(), then runs into the issue_helper.
				 */
				qbd_tcp_disconnect_all(&client->conn_pool);
				qbd_info("[%s] disconnected all tcp connections, %s", vol->qbd->devname, __func__);
				break;
			}
		}
		read_unlock(&client->iotask_pool.walk_lock);
sleep_and_continue:
		schedule_timeout_interruptible(msecs_to_jiffies(1000));
	}
	return 0;
}

static int qbd_tcp_open(struct qbd_volume *vol)
{
	struct qbd_client_tcp *client;
	int rc = 0;
	int pool_size = get_pool_size_by_iodepth_tcp(vol->max_io_depth);

	client = vol->client = kmalloc(sizeof(struct qbd_client_tcp), GFP_KERNEL);
	if (vol->client == NULL) {
		qbd_err("[%s] kmalloc qbd_client_tcp failed", vol->qbd->devname);
		goto err_out;
	}
	client->vol = vol;
	client->status = CLIENT_STATUS_OK;
	qbd_info("[%s] init qbd client:%px", vol->qbd->devname, client);

	/* init iotask pool */
	rc = qbd_init_iotask_pool_tcp(&client->iotask_pool, pool_size);
	if (rc) {
		qbd_err("[%s] init iotask_pool failed:%d", vol->qbd->devname, rc);
		goto err_free_client;
	}

	/* init contentions */
	mutex_init(&client->snd_lock);
	init_completion(&client->snd_completion);
	init_completion(&client->rty_completion);
	atomic_set(&client->sending_iotask_count, 0);

	/* init iotask queue depth with pool_size */
	rc = init_queue(&client->snd_queue, pool_size);
	if (rc) {
		qbd_err("[%s] init_queue snd_queue failed", vol->qbd->devname);
		goto err_release_iotask_pool;
	}
	rc = init_queue(&client->qs_queue, pool_size);
	if (rc) {
		qbd_err("[%s] init_queue qs_queue failed", vol->qbd->devname);
		goto err_destroy_snd_queue;
	}
	rc = init_queue(&client->rty_queue, pool_size);
	if (rc) {
		qbd_err("[%s] init_queue rty_queue failed", vol->qbd->devname);
		goto err_destroy_qs_queue;
	}

	/* init traffic control */
	qbd_tc_init(&client->tc, &vol->qos);

	/* create snd/rcv thread before connection established */
	client->snd_thread = kthread_run(qbd_tcp_snd_thread, vol, "qbd_snd_%s", vol->qbd->devname);
	if (IS_ERR(client->snd_thread)) {
		qbd_err("[%s] create qbd_tcp_snd_thread failed", vol->qbd->devname);
		goto err_destroy_rty_queue;
	}
	client->rcv_thread = kthread_run(qbd_tcp_rcv_thread, vol, "qbd_rcv_%s", vol->qbd->devname);
	if (IS_ERR(client->rcv_thread)) {
		qbd_err("[%s] create qbd_tcp_rcv_thread failed", vol->qbd->devname);
		goto err_stop_snd_thread;
	}
	client->watchdog_thread = kthread_run(qbd_tcp_watchdog_thread, vol, "qbd_dog_%s", vol->qbd->devname);
	if (IS_ERR(client->watchdog_thread)) {
		qbd_err("[%s] create qbd_tcp_watchdog_thread failed", vol->qbd->devname);
		goto err_stop_watchdog_thread;
	}

	rc = init_conn_pool(&client->conn_pool, vol);
	if (rc) {
		qbd_err("[%s] init_conn_pool failed", vol->qbd->devname);
		goto err_stop_rcv_thread;
	}
	return 0;

err_stop_watchdog_thread:
	kthread_stop(client->watchdog_thread);
err_stop_rcv_thread:
	kthread_stop(client->rcv_thread);
err_stop_snd_thread:
	kthread_stop(client->snd_thread);
err_destroy_rty_queue:
	destroy_queue(&client->rty_queue);
err_destroy_qs_queue:
	destroy_queue(&client->qs_queue);
err_destroy_snd_queue:
	destroy_queue(&client->snd_queue);
err_release_iotask_pool:
	qbd_release_iotask_pool_tcp(&client->iotask_pool);
err_free_client:
	kfree(client);
err_out:
	return -1;
}

static int qbd_tcp_close(struct qbd_volume *vol)
{
	struct qbd_client_tcp *client = vol->client;
	kthread_stop(client->watchdog_thread);
	kthread_stop(client->snd_thread);
	qbd_tcp_disconnect_all(&client->conn_pool);
	kthread_stop(client->rcv_thread);
	release_conn_pool(&client->conn_pool);
	destroy_queue(&client->rty_queue);
	destroy_queue(&client->qs_queue);
	destroy_queue(&client->snd_queue);
	qbd_release_iotask_pool_tcp(&client->iotask_pool);
	kfree(client);
	return 0;
}

/*
 * besides of -EAGAIN status, all the io request will be send,
 * so, no more work needs to handle the immediate return error.
 * this is different with user space neonsan client.
 */
static int qbd_tcp_aio(struct qbd_volume *vol, bool is_write,
		void *buf, uint64_t slba, uint32_t nlba, void *callback, void *cb_arg)
{
	struct iotask_tcp *iotask;
	struct qbd_command *cmd;
	struct qbd_client_tcp *client = vol->client;

	iotask = qbd_alloc_iotask_tcp(&client->iotask_pool);
	if (iotask == NULL)
		return -EAGAIN;
	qbd_detailed_debug(vol->qbd, "[%s] alloc cid:%d io:%px",
			   vol->qbd->devname,
			   le16_to_cpu(iotask->io_cmd.command_id),
			   iotask);

	if (likely(vol->resume_type == QBD_IOC_RESUME_NORMAL_VOLUME))
		iotask->status = 0;
	else if (vol->resume_type == QBD_IOC_RESUME_ERROR_VOLUME)
		iotask->status = -EIO;
	else if (vol->resume_type == QBD_IOC_RESUME_DISCARD_VOLUME)
		iotask->status = -EDISCARD;

	if (unlikely(nlba * QBD_SECTOR_SIZE > vol->max_blocksize)) {
		qbd_err("[%s] nlba:%u invalid", vol->qbd->devname, nlba);
		iotask->status = -EINVAL;
	}
	if (unlikely(vol->size < ((slba + nlba) << QBD_SECTOR_BITS))) {
		qbd_err("[%s] slba[%llu] + nlba[%u] > volume size[%ld]",
			vol->qbd->devname, slba, nlba, vol->size);
		iotask->status = -EINVAL;
	}
	if (unlikely(QBD_SECTOR_OFFSET_IN_OBJ(slba, vol->objsize) + nlba > QBD_SECTORS_PER_OBJ(vol->objsize))) {
		qbd_err("[%s] slba[%lld] nlba[%d] exceed %lluM block boundary",
			vol->qbd->devname, slba, nlba, (vol->objsize >> 20));
		iotask->status = -EINVAL;
	}

	iotask->ulp_handler = callback;
	iotask->ulp_arg = cb_arg;
	iotask->vol = vol;
	iotask->conn = NULL;
	iotask->ts_iostart = ((struct qb_request *)cb_arg)->kbr->ts_start;

	cmd = &iotask->io_cmd;
	cmd->opcode	= is_write ? QBD_OP_WRITE : QBD_OP_READ;
	cmd->vol_id	= cpu_to_le64(vol->id);
	cmd->buf_addr	= cpu_to_le64(buf);
	cmd->rkey	= cpu_to_le32(0);
	cmd->buf_len	= cpu_to_le32(nlba * QBD_SECTOR_SIZE);
	cmd->slba	= cpu_to_le64(slba);
	cmd->nlba	= cpu_to_le16(nlba);
	cmd->meta_ver	= cpu_to_le16(vol->meta_ver);
	cmd->snap_seq	= cpu_to_le32(vol->snap_seq);

	while (enqueue(&client->snd_queue, iotask) != 0) {
		schedule_timeout_interruptible(usecs_to_jiffies(10));
	}
	wake_up_process(client->snd_thread);

	return 0;
}

static int qbd_tcp_aio_read(struct qbd_volume *vol, void *buf, uint64_t slba,
		     uint32_t nlba, void *callback, void *cb_arg)
{
	return qbd_tcp_aio(vol, false, buf, slba, nlba, callback, cb_arg);
}

static int qbd_tcp_aio_write(struct qbd_volume *vol, void *buf, uint64_t slba,
		      uint32_t nlba, void *callback, void *cb_arg)
{
	return qbd_tcp_aio(vol, true, buf, slba, nlba, callback, cb_arg);
}

struct io_status {
	struct completion io_completion;
	int io_complete_status;
};

static void qbd_io_handler(int complete_status, void *cbk_arg)
{
	struct io_status *isp = (struct io_status *)cbk_arg;
	isp->io_complete_status = complete_status;
	complete(&isp->io_completion);
}

static int qbd_tcp_io(struct qbd_volume *vol, bool is_write, void *buf, uint64_t slba, uint32_t nlba)
{
	struct io_status is;
	int ret;
	init_completion(&is.io_completion);
	ret = qbd_tcp_aio(vol, is_write, buf, slba, nlba, qbd_io_handler, &is);
	if (ret != 0) {
		qbd_err("[%s] failed to %s io: slba[%llu] nlba[%u]",
			vol->qbd->devname, is_write ? "write" : "read", slba, nlba);
		return ret;
	}
	wait_for_completion(&is.io_completion);
	return is.io_complete_status;
}

static int qbd_tcp_read(struct qbd_volume *vol, void *buf, uint64_t slba, uint32_t nlba)
{
	return qbd_tcp_io(vol, false, buf, slba, nlba);
}

static int qbd_tcp_write(struct qbd_volume *vol, void *buf, uint64_t slba, uint32_t nlba)
{
	return qbd_tcp_io(vol, true, buf, slba, nlba);
}

static int qbd_tcp_reopen(struct qbd_volume *vol)
{
	int i, ret = 0;
	char cmd_path[] = QBD_UTIL_PATH "qbd";
	char name[QBD_VOLUME_MAX + QBD_SNAP_MAX];
	char *cmd_argv[11];
	char *cmd_envp[] = { "HOME=/root", "PATH=" QBD_UTIL_PATH, NULL };
	struct qbd_client_tcp *client = (struct qbd_client_tcp *)vol->client;
	char *keyid = NULL;
	char *passphrass = NULL;

	sprintf(name, "%s%s%s%s",
		vol->legacy_protocol ? "" : "tcp://",
		vol->name,
		vol->snap_name[0] == '\0' ? "" : "@",
		vol->snap_name[0] == '\0' ? "" : vol->snap_name);

	cmd_argv[0] = cmd_path;
	cmd_argv[1] = "-r";
	cmd_argv[2] = name;
	cmd_argv[3] = "-c";
	cmd_argv[4] = vol->cfg_file;
	cmd_argv[5] = "-V";

	if (vol->keyid[0] != '\0') {
		keyid = vmalloc(QBD_CRYPT_MAX + 1);
		if (keyid == NULL) {
			ret = -ENOMEM;
			goto out;
		}
		passphrass = vmalloc(QBD_CRYPT_MAX + 1 + strlen("-P"));
		if (passphrass == NULL) {
			ret = -ENOMEM;
			goto out_vfree_keyid;
		}
		qbd_decrypt(vol->keyid, keyid, QBD_CRYPT_MAX);
		strcpy(passphrass, "-P");
		qbd_decrypt(vol->passphrass, passphrass + 2, QBD_CRYPT_MAX);

		cmd_argv[6] = "-K";
		cmd_argv[7] = keyid;
		cmd_argv[8] = passphrass;
		cmd_argv[9] = NULL;
	}
	else
		cmd_argv[6] = NULL;

	for (i = 0; i < (qbd_remap_max_retry == 0 ? UINT_MAX : qbd_remap_max_retry); i++) {
		ret = call_usermodehelper(cmd_path, cmd_argv, cmd_envp, UMH_WAIT_PROC);
		if (!ret)
			break;
		qbd_err("[%s] call_usermodehelper %s failed:%#x, retry count:%d",
			vol->qbd->devname,
			cmd_path,
			ret,
			i+1);
	}
	if (ret) {
		qbd_err("[%s] call_usermodehelper %s failed:%#x, please check syslog for open_volume_common failed reason",
			vol->qbd->devname,
			cmd_path,
			ret);
		goto out_vfree_passphrass;
	}
	qbd_tc_reset(&client->tc, &vol->qos);

out_vfree_passphrass:
	vfree(passphrass);
out_vfree_keyid:
	vfree(keyid);
out:
	return ret;
}

static void qbd_tcp_resize_iodepth(struct qbd_volume *vol)
{
	struct qbd_client_tcp *client = (struct qbd_client_tcp *)vol->client;
	struct qbd_iotask_pool_tcp *old_iotask_pool = &client->iotask_pool;
	struct qbd_device *qbd = vol->qbd;
	struct queue new_snd_queue, new_rty_queue, new_qs_queue;
	struct qbd_iotask_pool_tcp new_iotask_pool;
	int old_iodepth = get_iodepth_by_pool_size_tcp(old_iotask_pool->size);
	int new_size;
	unsigned long flags;
	int rc;
	int times = 0;

	if (old_iodepth == vol->max_io_depth || vol->max_io_depth <= 0)
		return;

	spin_lock_irqsave(&qbd->lock, flags);
	if (test_bit(QBD_DEV_FLAG_REMOVING, &qbd->flags) ||
	    test_bit(QBD_DEV_FLAG_IODEPTH_RESIZING, &qbd->flags)) {
		spin_unlock_irqrestore(&qbd->lock, flags);
		return;
	}
	set_bit(QBD_DEV_FLAG_IODEPTH_RESIZING, &qbd->flags);
	spin_unlock_irqrestore(&qbd->lock, flags);

	new_size = get_pool_size_by_iodepth_tcp(vol->max_io_depth);

	rc = init_queue(&new_snd_queue, new_size);
	if (rc) {
		qbd_err("[%s] %s: failed init new_snd_queue", qbd->devname, __func__);
		goto err;
	}
	rc = init_queue(&new_rty_queue, new_size);
	if (rc) {
		qbd_err("[%s] %s: failed init new_rty_queue", qbd->devname, __func__);
		goto err_free_new_snd_queue;
	}
	rc = init_queue(&new_qs_queue, new_size);
	if (rc) {
		qbd_err("[%s] %s: failed init new_qs_queue", qbd->devname, __func__);
		goto err_free_new_rty_queue;
	}
	rc = qbd_init_iotask_pool_tcp(&new_iotask_pool, new_size);
	if (rc) {
		qbd_err("[%s] %s: failed init new_iotask_pool", qbd->devname, __func__);
		goto err_free_new_qs_queue;
	}

	/* if wait time larger than the default qbd_warn_delay(3000ms), abort resizing iodepth */
	while (true) {
		int nr;
		spin_lock_irqsave(&old_iotask_pool->free_list.lock, flags);
		nr = old_iotask_pool->nr_alloced;
		spin_unlock_irqrestore(&old_iotask_pool->free_list.lock, flags);
		if (nr == 0) {
			goto ready;
		} else if (times++ < 30) {
			wake_up_process(client->snd_thread);
			schedule_timeout_interruptible(msecs_to_jiffies(100));
			continue;
		}
		qbd_err("[%s] %s: timeout(3000ms), iotask_pool.nr_alloced is %d now",
			qbd->devname,
			__func__,
			nr);
		goto err_free_new_iotask_pool;
	}

ready:
	qbd_replace_snd_queue_tcp(client, &new_snd_queue);
	qbd_replace_rty_queue_tcp(client, &new_rty_queue);
	qbd_replace_qs_queue_tcp(client, &new_qs_queue);
	qbd_replace_iotask_pool_tcp(client, &new_iotask_pool);

	blk_queue_max_segments(qbd->disk->queue, vol->max_io_depth);

	spin_lock_irqsave(&qbd->lock, flags);
	clear_bit(QBD_DEV_FLAG_IODEPTH_RESIZING, &qbd->flags);
	spin_unlock_irqrestore(&qbd->lock, flags);

	qbd_info("[%s] %s: succeeded resize io depth from %d to %d",
		qbd->devname,
		__func__,
		old_iodepth,
		vol->max_io_depth);
	return;

err_free_new_iotask_pool:
	qbd_release_iotask_pool_tcp(&new_iotask_pool);
err_free_new_qs_queue:
	destroy_queue(&new_qs_queue);
err_free_new_rty_queue:
	destroy_queue(&new_rty_queue);
err_free_new_snd_queue:
	destroy_queue(&new_snd_queue);
err:
	spin_lock_irqsave(&qbd->lock, flags);
	clear_bit(QBD_DEV_FLAG_IODEPTH_RESIZING, &qbd->flags);
	spin_unlock_irqrestore(&qbd->lock, flags);

	qbd_err("[%s] %s: failed resize io depth from %d to %d",
		qbd->devname,
		__func__,
		old_iodepth,
		vol->max_io_depth);
}

static struct qbd_client_operations qbd_client_tcp_ops = {
	.owner		= THIS_MODULE,
	.name		= "tcp",
	.type		= TCP,
	.open		= qbd_tcp_open,
	.close		= qbd_tcp_close,
	.aio_read	= qbd_tcp_aio_read,
	.aio_write	= qbd_tcp_aio_write,
	.read		= qbd_tcp_read,
	.write		= qbd_tcp_write,
	.reopen		= qbd_tcp_reopen,
	.resize_iodepth	= qbd_tcp_resize_iodepth,

	.init_conn	= qbd_tcp_init_conn,
	.release_conn	= qbd_tcp_release_conn,
	._release_conn	= _qbd_tcp_release_conn,

	.entry		= LIST_HEAD_INIT(qbd_client_tcp_ops.entry),
};

static int __init qbd_tcp_init(void)
{
	int ret;
	qs_request_cache = kmem_cache_create("qs_request_cache",
					     sizeof(struct qs_request),
					     __alignof(sizeof(struct qs_request)),
					     0,
					     NULL);
	if (!qs_request_cache)
		return -ENOMEM;

	ret = qbd_client_register(&qbd_client_tcp_ops);
	if (ret) {
		qbd_err("failed to register tcp client operations to qbd:%d", ret);
		goto err_kmem_cache_destroy;
	}
	qbd_info("Register NeonSAN TCP Client Succeed!");
	return 0;

err_kmem_cache_destroy:
	kmem_cache_destroy(qs_request_cache);
	return ret;
}

static void __exit qbd_tcp_exit(void)
{
	BUG_ON(qbd_client_unregister(&qbd_client_tcp_ops));
	kmem_cache_destroy(qs_request_cache);
	qbd_info("Unregister NeonSAN TCP Client Succeed!");
}

module_init(qbd_tcp_init);
module_exit(qbd_tcp_exit);

MODULE_VERSION(VERSION);
MODULE_AUTHOR("QingCloud Kernel Group <kernel_group@yunify.com>");

MODULE_DESCRIPTION(QBD_DESCRIPTION " for tcp");
MODULE_LICENSE("GPL");
