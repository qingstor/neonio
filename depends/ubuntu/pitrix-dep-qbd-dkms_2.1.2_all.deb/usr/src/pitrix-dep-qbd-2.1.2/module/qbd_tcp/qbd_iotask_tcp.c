#include <linux/slab.h>
#include "qbd_queue.h"
#include "qbd_message.h"
#include "qbd_iotask_tcp.h"
#include "qbd_client_tcp.h"

int qbd_init_iotask_pool_tcp(struct qbd_iotask_pool_tcp *pool, int size)
{
	int rc = 0;
	int i;
	if (size >= 65535)
		return -EINVAL;

	pool->size = size;
	pool->nr_alloced = 0;

	rc = init_queue(&pool->free_list, size);
	if (rc)
		return rc;

	pool->iotasks = kzalloc(size * sizeof(struct iotask_tcp), GFP_KERNEL);
	if (pool->iotasks == NULL) {
		rc = -ENOMEM;
		goto err_destroy_queue;
	}

	for (i = 0; i < size; i++) {
		pool->iotasks[i].io_cmd.opcode = QBD_OP_UNKNOWN;
		pool->iotasks[i].io_cmd.command_id = cpu_to_le16(i);
		pool->iotasks[i].io_cmd.flags = 0x80;
		pool->iotasks[i].processing = false;
		pool->iotasks[i].ts_iostart = 0;
	}

	for (i = 0; i < size; i++)
		enqueue(&pool->free_list, &pool->iotasks[i]);

	rwlock_init(&pool->walk_lock);

	return 0;

err_destroy_queue:
	destroy_queue(&pool->free_list);
	return rc;
}

/*
 * alloc iotask_tcp struct.
 * alloc successed return iotask_tcp pointer and NOMEM or qbd->flags was setted
 * QBD_DEV_FLAG_IODEPTH_RESIZING return NULL.
 */
struct iotask_tcp *qbd_alloc_iotask_tcp(struct qbd_iotask_pool_tcp *pool)
{
	struct qbd_client_tcp *client = container_of(pool, struct qbd_client_tcp, iotask_pool);
	struct qbd_device *qbd = client->vol->qbd;
	struct iotask_tcp *iotask;
	unsigned long flags;

	spin_lock_irqsave(&pool->free_list.lock, flags);

	if (unlikely(pool->nr_alloced >= client->vol->max_io_depth ||
		     test_bit(QBD_DEV_FLAG_IODEPTH_RESIZING, &qbd->flags))) {
		spin_unlock_irqrestore(&pool->free_list.lock, flags);
		return NULL;
	}

	iotask = __dequeue(&pool->free_list);
	if (iotask)
		++pool->nr_alloced;

	spin_unlock_irqrestore(&pool->free_list.lock, flags);

	return iotask;
}

void qbd_free_iotask_tcp(struct qbd_iotask_pool_tcp *pool, struct iotask_tcp *iotask)
{
	unsigned long flags;

	iotask->conn = NULL;
	iotask->status = 0;
	iotask->processing = false;
	iotask->io_cmd.opcode = QBD_OP_UNKNOWN;
	iotask->ts_iostart = 0;

	spin_lock_irqsave(&pool->free_list.lock, flags);
	BUG_ON(__enqueue(&pool->free_list, iotask) != 0);
	--pool->nr_alloced;
	spin_unlock_irqrestore(&pool->free_list.lock, flags);
}

void qbd_release_iotask_pool_tcp(struct qbd_iotask_pool_tcp *pool)
{
	kfree(pool->iotasks);
	destroy_queue(&pool->free_list);
}

/*
 * qbd_client_tcp replace functions:
 * replace client->snd_queue/rty_queue/qs_queue/iotask_pool with
 * new and destroy the old.
 */
void qbd_replace_snd_queue_tcp(struct qbd_client_tcp *client, struct queue *new)
{
	unsigned long flags;

	spin_lock_irqsave(&client->snd_queue.lock, flags);
	BUG_ON(!queue_is_empty(&client->snd_queue));
	swap_queue(&client->snd_queue, new);
	spin_unlock_irqrestore(&client->snd_queue.lock, flags);
	destroy_queue(new);
}

void qbd_replace_rty_queue_tcp(struct qbd_client_tcp *client, struct queue *new)
{
	unsigned long flags;

	spin_lock_irqsave(&client->rty_queue.lock, flags);
	BUG_ON(!queue_is_empty(&client->rty_queue));
	swap_queue(&client->rty_queue, new);
	spin_unlock_irqrestore(&client->rty_queue.lock, flags);
	destroy_queue(new);
}

void qbd_replace_qs_queue_tcp(struct qbd_client_tcp *client, struct queue *new)
{
	unsigned long flags;

	spin_lock_irqsave(&client->qs_queue.lock, flags);
	BUG_ON(!queue_is_empty(&client->qs_queue));
	swap_queue(&client->qs_queue, new);
	spin_unlock_irqrestore(&client->qs_queue.lock, flags);
	destroy_queue(new);
}

void qbd_replace_iotask_pool_tcp(struct qbd_client_tcp *client, struct qbd_iotask_pool_tcp *new)
{
	struct qbd_iotask_pool_tcp old = client->iotask_pool;
	struct qbd_iotask_pool_tcp *pool = &client->iotask_pool;
	unsigned long flags;

	write_lock(&pool->walk_lock);
	spin_lock_irqsave(&pool->free_list.lock, flags);
	BUG_ON(pool->nr_alloced != 0);
	pool->nr_alloced = new->nr_alloced;
	pool->size	 = new->size;
	pool->iotasks	 = new->iotasks;
	swap_queue(&pool->free_list, &new->free_list);
	spin_unlock_irqrestore(&pool->free_list.lock, flags);
	write_unlock(&pool->walk_lock);

	qbd_release_iotask_pool_tcp(&old);
}
