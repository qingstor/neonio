#include <linux/net.h>
#include <linux/mm.h>
#include <linux/sched.h>
#include <linux/signal.h>
#include <net/sock.h>
#include <net/tcp.h>
#include "qbd.h"
#include "qbd_client.h"
#include "qbd_helper_tcp.h"
#include "linux/mm_compat.h"
/*
 *  Send or receive packet.
 */
static int sock_xmit(struct socket *skt, bool send, void *buf, size_t size, unsigned int msg_flags)
{
	int result;
	struct msghdr msg;
	struct kvec iov;
	int sent = 0;
	sigset_t blocked, oldset;
#ifdef HAVE_TSK_RESTORE_FLAGS
	unsigned long pflags = current->flags;
#endif

	if (unlikely(!skt)) {
		return -EINVAL;
	}

	/* Only SIGKILL can interrupt the transmission */
	siginitsetinv(&blocked, sigmask(SIGKILL));
	sigprocmask(SIG_SETMASK, &blocked, &oldset);

	do {
		skt->sk->sk_allocation = GFP_NOIO | __GFP_MEMALLOC;
		iov.iov_base = buf;
		iov.iov_len = size;
		msg.msg_name = NULL;
		msg.msg_namelen = 0;
		msg.msg_control = NULL;
		msg.msg_controllen = 0;
		msg.msg_flags = msg_flags | MSG_NOSIGNAL;

		if (send)
			result = kernel_sendmsg(skt, &msg, &iov, 1, size);
		else
			result = kernel_recvmsg(skt, &msg, &iov, 1, size, msg.msg_flags);

		if (result <= 0) {
			sent = result;
			break;
		}
		size -= result;
		buf += result;
		sent += result;
	} while (size > 0);

	sigprocmask(SIG_SETMASK, &oldset, NULL);
#ifdef HAVE_TSK_RESTORE_FLAGS
	tsk_restore_flags(current, pflags, PF_MEMALLOC);
#endif

	return sent;
}

int socket_send_all(struct socket *skt, void *buf, size_t size)
{
	return sock_xmit(skt, true, buf, size, 0);
}

int socket_recv_all(struct socket *skt, void *buf, size_t size)
{
	return sock_xmit(skt, false, buf, size, MSG_WAITALL);
}

int socket_recv(struct socket *skt, void *buf, size_t size)
{
	struct msghdr msg = { NULL, };
	struct kvec iov = { buf, size };
	return kernel_recvmsg(skt, &msg, &iov, 1, size, MSG_DONTWAIT);
}

int socket_disconnect(struct socket *skt)
{
	kernel_sock_shutdown(skt, SHUT_RDWR);
	return 0;
}

int socket_open(struct socket **skt, struct sockaddr_in *addr, int tcp_no_delay, int conn_timeout, int *step)
{
	int ret = 0;
	struct __kernel_sock_timeval sndtimeout = { TCP_SEND_TIMEOUT, 0 };
	uint64_t expire, now;
	int timeout;

	ret = sock_create(AF_INET, SOCK_STREAM, IPPROTO_TCP, skt);
	if (ret) {
		*step = ERROR_SOCKET_CREATE;
		return ret;
	}

	/* set TCP_NODELAY */
	if (likely(tcp_no_delay))
		tcp_sock_set_nodelay((*skt)->sk);

	/* set SO_SNDTIMEO & SO_RCVTIMEO */
	ret = sock_setsockopt(*skt, SOL_SOCKET, SO_SNDTIMEO, (char *)&sndtimeout, sizeof(sndtimeout));
	if (ret) {
		*step = ERROR_SETSOCKOPT_SNDTIMEO;
		goto failed;
	}

	timeout = conn_timeout;
	expire = get_now_nsec() + ((conn_timeout + 1) * NSEC_PER_SEC);
	while (1) {
		struct __kernel_sock_timeval rcvtimeout = { timeout, 0 };
		ret = sock_setsockopt(*skt, SOL_SOCKET, SO_RCVTIMEO, (char *)&rcvtimeout, sizeof(rcvtimeout));
		if (ret) {
			*step = ERROR_SETSOCKOPT_RCVTIMEO;
			goto failed;
		}

		ret = kernel_connect(*skt, (struct sockaddr *)addr, sizeof(struct sockaddr_in), 0);
		if (ret == 0)
			break;

		now = get_now_nsec();
		if (now >= expire ) {
			*step = ERROR_KERNEL_CONNECT;
			ret = -ETIMEDOUT;
			goto failed;
		}

		timeout = (int)((expire - now) / NSEC_PER_SEC);
		if (timeout == 0) {
			*step = ERROR_KERNEL_CONNECT;
			ret = -ETIMEDOUT;
			goto failed;
		}
		schedule_timeout_interruptible(msecs_to_jiffies(100));
	}

	return 0;

failed:
	sock_release(*skt);
	return ret;
}

int socket_close(struct socket *skt)
{
	socket_disconnect(skt);
	sock_release(skt);
	return 0;
}
