#include "qbd_client.h"
#include "qbd_message.h"
#include "qbd_hashtable.h"
#include "qbd_client_tcp.h"
#include "qbd_conn_tcp.h"
#include "qbd_helper_tcp.h"
#include "linux/timer_compat.h"

static char *step_errstr[ERROR_MAX_COUNT]= {
	"ready",
	"socket_create",
	"sock_setsockopt SO_SNDTIMEO",
	"sock_setsockopt SO_RCVTIMEO",
	"kernel_connect"
};

static int tcp_handshake(struct socket *skt, struct qbd_volume *vol)
{
	int rc;
	struct handshake hs;
	memset(&hs, 0, sizeof(hs));

	hs.hsqsize = vol->max_io_depth;
	hs.vol_id = vol->id;
	hs.snap_seq = vol->snap_seq;
	hs.protocol_ver = PROTOCOL_VER;
	hs.io_timeout = vol->io_timeout;

	rc = socket_send_all(skt, &hs, sizeof(hs));
	if (rc != sizeof(hs))
		return -1;

	rc = socket_recv_all(skt, &hs, sizeof(hs));
	if (rc != sizeof(hs))
		return -2;

	return hs.hs_result;
}

/*
 * Timer function for sending heartbeat io to store.
 * We will send heartbeat io each qbd->heartbeat_timeout.
 * If client is busy in io handing, all qbd_alloc_iotask and iotask enqueue failed,
 * then store will close the connection for more resources.
 * We never promise HEARTBEAT IO can be send to store when client is busy.
 */
#ifdef HAVE_KERNEL_TIMER_FUNCTION_TIMER_LIST
static void tcp_send_heartbeat(struct timer_list *tl)
{
	struct qbd_conn *conn = from_timer(conn, tl, hb_timer);
#else
static void tcp_send_heartbeat(unsigned long data)
{
	struct qbd_conn *conn = (struct qbd_conn *)data;
#endif
	struct qbd_volume *vol = conn->vol;
	struct qbd_client_tcp *client = conn->vol->client;
	struct iotask_tcp *iotask = NULL;
	struct qbd_command *cmd;

	if (test_bit(QBD_DEV_FLAG_REMOVING, &vol->qbd->flags))
		return;
	if (conn->status != CONN_STATUS_CONNECTED)
		return;
	if (get_now_nsec() - conn->last_send_time < 1000000000LL * vol->qbd->heartbeat_timeout)
		goto out_mod_timer;
	if ((iotask = qbd_alloc_iotask_tcp(&client->iotask_pool)) == NULL)
		goto out_mod_timer;
	qbd_detailed_debug(vol->qbd, "[%s] alloc cid:%d io:%px", vol->qbd->devname, le16_to_cpu(iotask->io_cmd.command_id), iotask);
	iotask->status = 0;
	iotask->ulp_handler = NULL;
	iotask->ulp_arg = NULL;
	iotask->vol = conn->vol;
	iotask->conn = NULL;
	iotask->ts_iostart = get_now_nsec();

	cmd = &iotask->io_cmd;
	cmd->opcode	= QBD_OP_HEARTBEAT;
	cmd->vol_id	= cpu_to_le64(conn->vol->id);
	cmd->buf_addr	= cpu_to_le64(0);
	cmd->rkey	= cpu_to_le32(0);
	cmd->buf_len	= cpu_to_le32(0);
	cmd->slba	= cpu_to_le64((uint64_t)conn->shard << QBD_SECTORS_PER_SHARD_BITS);
	cmd->nlba	= cpu_to_le16(0);
	cmd->snap_seq	= cpu_to_le32(conn->vol->snap_seq);
	cmd->meta_ver	= cpu_to_le16(vol->meta_ver);

	if (enqueue(&client->snd_queue, iotask) != 0)
		qbd_free_iotask_tcp(&client->iotask_pool, iotask);
	else
		qbd_detailed_debug(vol->qbd, "[%s] %s succeed", vol->qbd->devname, __func__);

out_mod_timer:
	mod_timer(&conn->hb_timer, jiffies + msecs_to_jiffies(1000LL * vol->qbd->heartbeat_timeout));
}

void qbd_tcp_disconnect_all(struct qbd_conn_pool *pool)
{
	int i;
	struct hlist_node *phn, *phn_tmp;
	struct sockaddr_hashnode *shn;
	struct sockaddr_hashtable *sht = pool->conn_table;

	mutex_lock(&sht->lock);
	for (i = 0; i < sht->size; i++) {
		hlist_for_each_safe(phn, phn_tmp, &sht->hashtable[i]) {
			shn = hlist_entry(phn, struct sockaddr_hashnode, hashnode);
			socket_disconnect(shn->conn->skt);
		}
	}
	mutex_unlock(&sht->lock);
}

int qbd_tcp_init_conn(struct qbd_conn *conn, struct qbd_volume *vol, struct sockaddr_in *addr)
{
	int rc;
	int step = ERROR_READY;
	struct __kernel_sock_timeval io_timeout = { vol->io_timeout, 0 };

	conn->vol = vol;
	memcpy(&conn->addr, addr, sizeof(struct sockaddr_in));
	rc = socket_open(&conn->skt, addr, vol->tcp_no_delay, vol->conn_timeout, &step);
	if (rc) {
		qbd_err("[%s] socket_open %s failed:%d", vol->qbd->devname, step_errstr[step], rc);
		goto err_out;
	}
	/* set io rcv timeout(io_timeout) */
	rc = sock_setsockopt(conn->skt, SOL_SOCKET, SO_RCVTIMEO, (char *)&io_timeout, sizeof(io_timeout));
	if (rc) {
		goto err_close_socket;
	}
	rc = tcp_handshake(conn->skt, vol);
	if (rc) {
		qbd_err("[%s] handshake failed:%d", vol->qbd->devname, rc);
		goto err_close_socket;
	}
	qbd_info("[%s] tcp handshake succeed", vol->qbd->devname);
	conn->status = CONN_STATUS_CONNECTED;

	conn->last_send_time = get_now_nsec();
	setup_timer(&conn->hb_timer, tcp_send_heartbeat, (unsigned long)conn);
	mod_timer(&conn->hb_timer, jiffies + msecs_to_jiffies(1000LL * vol->qbd->heartbeat_timeout));

	return 0;

err_close_socket:
	socket_close(conn->skt);
err_out:
	conn->status = CONN_STATUS_FAILED;
	return -1;
}

void qbd_tcp_release_conn(struct qbd_conn *conn)
{
	struct qbd_client_tcp *client = conn->vol->client;
	sht_delete(client->conn_pool.conn_table, &conn->addr);
}

void _qbd_tcp_release_conn(struct qbd_conn *conn)
{
	qbd_info("[%s] release tcp connection %pI4:%hu",
		 conn->vol->qbd->devname,
		 &conn->addr.sin_addr,
		 ntohs(conn->addr.sin_port));
	del_timer_sync(&conn->hb_timer);
	socket_close(conn->skt);
	conn->status = CONN_STATUS_CLOSED;
	kfree(conn);
}
