#include "qbd_hashtable.h"
#include "qbd_client.h"

/*
 * Hash function, if ips get deployed rules, it can be optimized.
 */
static unsigned int hash_sockaddr_in(struct sockaddr_in *addr, unsigned int size)
{
	unsigned int index;
	index = addr->sin_addr.s_addr & (0xffffffffUL >> (33 - fls(size)));
	BUG_ON(index >= size);
	return index;
}

/*
 * Init sockaddr hashtable, size should be 2^n.
 */
struct sockaddr_hashtable *sht_init(uint32_t size)
{
	int i;
	struct sockaddr_hashtable *sht;

	BUG_ON(size == 0);
	sht = kmalloc(sizeof(struct sockaddr_hashtable), GFP_KERNEL);
	if (sht == NULL) {
		qbd_err("kmalloc sockaddr_hashtable failed");
		return NULL;
	}
	sht->size = size;
	sht->hashtable = kmalloc(sizeof(struct hlist_head) * size, GFP_KERNEL);
	if (sht->hashtable == NULL) {
		qbd_err("kmalloc hashtable[%d] failed", size);
		kfree(sht);
		return NULL;
	}
	for (i = 0; i < size; i++)
		INIT_HLIST_HEAD(&sht->hashtable[i]);
	mutex_init(&sht->lock);
	return sht;
}

/*
 * Find the qbd_conn of sockaddr_in.
 */
struct qbd_conn *sht_find(struct sockaddr_hashtable *sht, struct sockaddr_in *addr)
{
	struct hlist_head *pht;
	struct hlist_node *phn;
	struct sockaddr_hashnode *shn = NULL;

	mutex_lock(&sht->lock);
	pht = &sht->hashtable[hash_sockaddr_in(addr, sht->size)];
	if (!hlist_empty(pht)) {
		compat_hlist_for_each_entry(shn, phn, pht, hashnode) {
			if (shn->conn->addr.sin_addr.s_addr == addr->sin_addr.s_addr) {
				mutex_unlock(&sht->lock);
				return shn->conn;
			}
		}
	}
	mutex_unlock(&sht->lock);
	return NULL;
}

/*
 * Insert qbd_conn into sockaddr_hashtable.
 */
int sht_insert(struct sockaddr_hashtable *sht, struct qbd_conn *conn)
{
	struct hlist_head *pht;
	struct sockaddr_hashnode *shn;

	mutex_lock(&sht->lock);
	shn = kmalloc(sizeof(struct sockaddr_hashnode), GFP_NOIO);
	if (shn == NULL) {
		qbd_err("kmalloc sockaddr_hashnode failed");
		mutex_unlock(&sht->lock);
		return -ENOMEM;
	}
	shn->conn = conn;
	INIT_HLIST_NODE(&shn->hashnode);

	pht = &sht->hashtable[hash_sockaddr_in(&conn->addr, sht->size)];
	hlist_add_head(&shn->hashnode, pht);
	mutex_unlock(&sht->lock);
	return 0;
}

/*
 * Delete sockaddr_in node in sockaddr_hashtable.
 */
int sht_delete(struct sockaddr_hashtable *sht, struct sockaddr_in *addr)
{
	struct hlist_head *pht;
	struct sockaddr_hashnode *shn;
	struct hlist_node *phn, *phn_tmp;
	int find = -1;

	mutex_lock(&sht->lock);
	pht = &sht->hashtable[hash_sockaddr_in(addr, sht->size)];
	hlist_for_each_safe(phn, phn_tmp, pht) {
		shn = hlist_entry(phn, struct sockaddr_hashnode, hashnode);
		if (shn->conn->addr.sin_addr.s_addr == addr->sin_addr.s_addr) {
			_qbd_release_conn(shn->conn);
			hlist_del(&shn->hashnode);
			kfree(shn);
			find = 0;
			break;
		}
	}
	mutex_unlock(&sht->lock);
	return find;
}
EXPORT_SYMBOL(sht_delete);

/*
 * Cleanup sockaddr_hashtable nodes and release all connections,
 * and destroy sockaddr_hashtable.
 */
int sht_destroy(struct sockaddr_hashtable *sht)
{
	int i;
	struct hlist_node *phn, *phn_tmp;
	struct sockaddr_hashnode *shn;

	mutex_lock(&sht->lock);
	for (i = 0; i < sht->size; i++) {
		hlist_for_each_safe(phn, phn_tmp, &sht->hashtable[i]) {
			shn = hlist_entry(phn, struct sockaddr_hashnode, hashnode);
			_qbd_release_conn(shn->conn);
			hlist_del(&shn->hashnode);
			kfree(shn);
		}
	}
	kfree(sht->hashtable);
	mutex_unlock(&sht->lock);
	kfree(sht);
	return 0;
}

/*
 * Cleanup sockaddr_hashtable nodes and release all connections.
 */
int sht_cleanup(struct sockaddr_hashtable *sht)
{
	int i;
	struct hlist_node *phn, *phn_tmp;
	struct sockaddr_hashnode *shn;

	mutex_lock(&sht->lock);
	for (i = 0; i < sht->size; i++) {
		hlist_for_each_safe(phn, phn_tmp, &sht->hashtable[i]) {
			shn = hlist_entry(phn, struct sockaddr_hashnode, hashnode);
			_qbd_release_conn(shn->conn);
			hlist_del(&shn->hashnode);
			kfree(shn);
		}
	}
	mutex_unlock(&sht->lock);
	return 0;
}
