#include <linux/kernel.h>
#include <linux/device.h>
#include <linux/module.h>
#include <linux/miscdevice.h>
#include <linux/kthread.h>
#include <linux/net.h>
#include <linux/mm.h>
#include <linux/vmalloc.h>
#include <net/sock.h>
#include <linux/kobject.h>
#include <linux/sysfs.h>
#include "linux/blkdev_compat.h"
#include "linux/sched_compat.h"
#include "linux/mm_compat.h"

#include "qbd.h"
#include "qbd_ctl.h"
#include "qbd_device.h"
#include "qbd_client.h"
#include "qbd_procfs.h"
#include "qbd_sysfs.h"

/*
 * Check if the io in locked write io range.
 * Called with holding kernel_queue_lock.
 */
static bool in_wio_range(struct qbd_device *qbd, struct kb_request *kbr)
{
	struct kb_request *kbrt;
	list_for_each_entry(kbrt, &qbd->wio_range_queue, entry) {
		if ((kbrt->slba <= kbr->slba && kbr->slba <= kbrt->elba) ||
			(kbrt->slba <= kbr->elba && kbr->elba <= kbrt->elba) ||
			(kbr->slba <= kbrt->slba && kbrt->slba <= kbr->elba) ||
			(kbr->slba <= kbrt->elba && kbrt->elba <= kbr->elba)) {
			if (kbr->cmd == QBD_AIO_WRITE)
				qbd->wio_range_write_hits++;
			else
				qbd->wio_range_read_hits++;
			return true;
		}
	}
	return false;
}

static void qbd_aio_aligned_handler(int complete_status, void *opaque)
{
	struct qb_request *qbr = (struct qb_request *)opaque;
	struct kb_request *kbr = qbr->kbr;
	struct req_iterator iter;
	struct bio_vec bvec, *pbvec;
	struct qbd_device *qbd = kbr->qbd;
	uint64_t offset;
	size_t size;

	wake_up_process(qbd->qbd_queue_thread);
	qbd_check_recv_timeout(qbr, true);
	atomic_cmpxchg(&kbr->error, 0, complete_status);
	qbd_update_shard_stat(&qbd->shard_stats[shard_index(qbr->curr_sector)], qbr);
	kmem_cache_free(qb_request_cache, qbr);

	if (--kbr->io_count == 0) {
		if (atomic_read(&kbr->error) == 0) {
			if (kbr->cmd == QBD_AIO_READ) {
				/* Write buf into req bvec */
				offset = (kbr->sector_num << BDRV_SECTOR_BITS) % QBD_SECTOR_SIZE;
				rq_for_each_segment4(bvec, pbvec, kbr->req, iter) {
					void *kaddr = kmap(bvec.bv_page);
					BUG_ON(offset + bvec.bv_len >
					       ((kbr->sector_num << BDRV_SECTOR_BITS) % QBD_SECTOR_SIZE) +
					       (kbr->nb_sectors << BDRV_SECTOR_BITS));
					memcpy(kaddr + bvec.bv_offset, kbr->buf + offset, bvec.bv_len);
					kunmap(bvec.bv_page);
					offset += bvec.bv_len;
				}
			}
		} else {
			atomic_inc(&kbr->qbd->error_count);
		}
		if (kbr->cmd == QBD_AIO_WRITE) {
			spin_lock(&kbr->qbd->kernel_queue_lock);
			list_del(&kbr->entry);
			spin_unlock(&kbr->qbd->kernel_queue_lock);
		}
		qbd_check_finish_timeout(kbr);
		qbd_detailed_debug(kbr->qbd, "[%s] aio info: %s %llu %u %llu %llu",
				   kbr->qbd->devname,
				   QBDAIOStr[kbr->cmd],
				   kbr->sector_num,
				   kbr->nb_sectors,
				   kbr->ts_start,
				   kbr->ts_finish);
		qbd_blk_end_request(kbr->req, -atomic_read(&kbr->error));
		size = (kbr->elba - kbr->slba + 1) << QBD_SECTOR_BITS;
		kvfree(kbr->buf);
		atomic_dec(&kbr->qbd->kernel_request_count);
		wake_up(&kbr->qbd->kernel_request_wait);
		kmem_cache_free(kb_request_cache, kbr);
	}
}

static void qbd_aio_partial_handler(int complete_status, void *opaque)
{
	struct qb_request *qbr = (struct qb_request *)opaque;
	struct qb_request **qbrlist;
	struct kb_request *kbr = qbr->kbr;
	struct qbd_device *qbd = kbr->qbd;
	uint64_t llba;
	size_t size;
	struct req_iterator iter;
	struct bio_vec bvec, *pbvec;
	int offset;
	int curr;

	wake_up_process(qbd->qbd_queue_thread);
	qbd_check_recv_timeout(qbr, false);
	atomic_cmpxchg(&kbr->error, 0, complete_status);
	qbd_update_shard_stat(&qbd->shard_stats[shard_index(qbr->curr_sector)], qbr);
	kmem_cache_free(qb_request_cache, qbr);

	/* If last QBD_AIO_PARTIAL_WRITE, enqueue write requests into queue */
	if (--kbr->uio_count == 0) {
		offset = (kbr->sector_num << BDRV_SECTOR_BITS) % QBD_SECTOR_SIZE;
		rq_for_each_segment4(bvec, pbvec, kbr->req, iter) {
			void *kaddr = kmap(bvec.bv_page);
			BUG_ON(offset + bvec.bv_len >
			       ((kbr->sector_num << BDRV_SECTOR_BITS) % QBD_SECTOR_SIZE) +
			       (kbr->nb_sectors << BDRV_SECTOR_BITS));
			memcpy(kbr->buf + offset, kaddr + bvec.bv_offset, bvec.bv_len);
			kunmap(bvec.bv_page);
			offset += bvec.bv_len;
		}

		offset = 0;
		kbr->io_count = (kbr->elba / qbd->max_sectors) - (kbr->slba / qbd->max_sectors) + 1;
		/* Alloc all qbr at once in case of oom */
		qbrlist = kmalloc(kbr->io_count * sizeof(struct qb_request *), GFP_NOIO);
		if (qbrlist == NULL) {
			qbd_err("[%s] kmalloc qbrlist failed, requeue io request", qbd->devname);
			goto err_qbrlist;
		}

		for (llba = kbr->slba, curr = 0; curr < kbr->io_count; curr++) {
			qbrlist[curr] = kmem_cache_alloc(qb_request_cache, GFP_NOIO);
			if (qbrlist[curr] == NULL) {
				qbd_err("[%s] failed to kmalloc qbr, requeue io request", qbd->devname);
				goto err_qbr;
			}
			qbrlist[curr]->kbr = kbr;
			qbrlist[curr]->cmd = QBD_AIO_WRITE;
			qbrlist[curr]->curr_sector = llba;
			qbrlist[curr]->buf_offset = offset;
			qbrlist[curr]->nb_sectors = min(qbd->max_sectors,
							qbd->max_sectors -
							(llba % qbd->max_sectors));
			if (llba + qbrlist[curr]->nb_sectors > kbr->elba)
				qbrlist[curr]->nb_sectors = kbr->elba - llba + 1;
			offset += (qbrlist[curr]->nb_sectors << QBD_SECTOR_BITS);
			llba += qbrlist[curr]->nb_sectors;
		}
		spin_lock(&qbd->qbd_queue_lock);
		for (curr = 0; curr < kbr->io_count; curr++)
			list_add_tail(&qbrlist[curr]->list, &qbd->qbd_queue);
		spin_unlock(&qbd->qbd_queue_lock);
		wake_up_process(qbd->qbd_queue_thread);
		kfree(qbrlist);
	}
	return;

err_qbr:
	for (--curr; curr >= 0; curr--)
		kmem_cache_free(qb_request_cache, qbrlist[curr]);

err_qbrlist:
	kfree(qbrlist);
	size = (kbr->elba - kbr->slba + 1) << QBD_SECTOR_BITS;
	kvfree(kbr->buf);
	qbd_blk_requeue_request(kbr->req->q, kbr->req);
	atomic_dec(&qbd->kernel_request_count);
	kmem_cache_free(kb_request_cache, kbr);
	wake_up(&qbd->kernel_request_wait);
}

int kernel_queue_thread(void *opaque)
{
	struct qbd_device *qbd = opaque;
	struct kb_request *kbr;
	struct qb_request **qbrlist;

	struct qb_request *qbrh = NULL; /* unaligned head request */
	struct qb_request *qbrt = NULL; /* unaligned tail request */
	struct qb_request *qbrb = NULL; /* aligned body request */
	size_t offset, size;
	uint64_t llba;
	int curr;

	set_user_nice(current, MIN_NICE);
	while (!kthread_should_stop()) {
		spin_lock(&qbd->kernel_queue_lock);
		if (list_empty(&qbd->kernel_queue)) {
			spin_unlock(&qbd->kernel_queue_lock);
			schedule_timeout_interruptible(msecs_to_jiffies(1));
			continue;
		}
		kbr = list_first_entry(&qbd->kernel_queue, struct kb_request, entry);
		list_del_init(&kbr->entry);
		if (qbd_read_wait_write_done || kbr->cmd == QBD_AIO_WRITE) {
			if (in_wio_range(qbd, kbr)) {
				list_add_tail(&kbr->entry, &qbd->kernel_queue);
				spin_unlock(&qbd->kernel_queue_lock);
				/* FIXME: there is possibility run into busy loop while all io are write and in_wio_range */
				set_current_state(TASK_RUNNING);
				schedule();
				continue;
			}
			else if (kbr->cmd == QBD_AIO_WRITE) {
				list_add_tail(&kbr->entry, &qbd->wio_range_queue);
			}
		}
		spin_unlock(&qbd->kernel_queue_lock);

		qbrh = qbrt = qbrb = NULL;
		switch (kbr->cmd) {
		case QBD_AIO_READ:
			offset = 0;
			kbr->io_count = (kbr->elba / qbd->max_sectors) - (kbr->slba / qbd->max_sectors) + 1;
			kbr->uio_count = 0;
			qbrlist = kmalloc(kbr->io_count * sizeof(struct qb_request *), GFP_NOIO);
			if (qbrlist == NULL) {
				qbd_err("[%s] kmalloc qbrlist failed", qbd->devname);
				goto err_partial_write;
			}
			for (llba = kbr->slba, curr = 0; curr < kbr->io_count; curr++) {
				qbrlist[curr] = kmem_cache_alloc(qb_request_cache, GFP_NOIO);
				if (qbrlist[curr] == NULL) {
					qbd_err("[%s] kmalloc qbr failed", qbd->devname);
					goto err_qbr;
				}
				qbrlist[curr]->kbr = kbr;
				qbrlist[curr]->cmd = QBD_AIO_READ;
				qbrlist[curr]->curr_sector = llba;
				qbrlist[curr]->buf_offset = offset;
				qbrlist[curr]->nb_sectors = min(qbd->max_sectors,
								qbd->max_sectors -
								(llba % qbd->max_sectors));
				if (llba + qbrlist[curr]->nb_sectors > kbr->elba)
					qbrlist[curr]->nb_sectors = kbr->elba - llba + 1;
				offset += ((uint64_t)qbrlist[curr]->nb_sectors << QBD_SECTOR_BITS);
				llba += qbrlist[curr]->nb_sectors;
			}
			spin_lock(&qbd->qbd_queue_lock);
			for (curr = 0; curr < kbr->io_count; curr++)
				list_add_tail(&qbrlist[curr]->list, &qbd->qbd_queue);
			spin_unlock(&qbd->qbd_queue_lock);
			wake_up_process(qbd->qbd_queue_thread);
			kfree(qbrlist);
			break;

		case QBD_AIO_WRITE:
			/*
			 * When the request is not QBD_SECTOR_SIZE aligned,
			 * unaligned head and tail sector must be finished reading before write,
			 */
			kbr->io_count = (kbr->elba / qbd->max_sectors) - (kbr->slba / qbd->max_sectors) + 1;
			kbr->uio_count = 0;
			/* Head qbd sector is partial write */
			if ((kbr->sector_num << BDRV_SECTOR_BITS) % QBD_SECTOR_SIZE != 0
			    || (kbr->nb_sectors < QBD_PER_BDRV
				&& (kbr->sector_num << BDRV_SECTOR_BITS) % QBD_SECTOR_SIZE == 0)) {
				qbrh = kmem_cache_alloc(qb_request_cache, GFP_NOIO);
				if (qbrh == NULL) {
					qbd_err("[%s] kmem_cache_alloc qbrh failed", qbd->devname);
					goto err_partial_write;
				}
				qbrh->kbr = kbr;
				qbrh->cmd = QBD_AIO_PARTIAL_WRITE;
				qbrh->curr_sector = kbr->slba;
				qbrh->buf_offset = 0;
				qbrh->nb_sectors = 1;
				kbr->uio_count++;
			}
			/* Tail qbd sector is partial write */
			if (kbr->elba > kbr->slba
			    && ((kbr->sector_num + kbr->nb_sectors) <<
				BDRV_SECTOR_BITS) % QBD_SECTOR_SIZE != 0) {
				qbrt = kmem_cache_alloc(qb_request_cache, GFP_NOIO);
				if (qbrt == NULL) {
					qbd_err("[%s] kmem_cache_alloc qbrt failed", qbd->devname);
					kmem_cache_free(qb_request_cache, qbrh);
					goto err_partial_write;
				}
				qbrt->kbr = kbr;
				qbrt->cmd = QBD_AIO_PARTIAL_WRITE;
				qbrt->curr_sector = kbr->elba;
				qbrt->buf_offset = (kbr->elba - kbr->slba) << QBD_SECTOR_BITS;
				qbrt->nb_sectors = 1;
				kbr->uio_count++;
			}
			if (qbrh != NULL || qbrt != NULL) {
				spin_lock(&qbd->qbd_queue_lock);
				if (qbrh != NULL)
					list_add_tail(&qbrh->list, &qbd->qbd_queue);
				if (qbrt != NULL)
					list_add_tail(&qbrt->list, &qbd->qbd_queue);
				spin_unlock(&qbd->qbd_queue_lock);
			}
			else {
				qbrb = kmem_cache_alloc(qb_request_cache, GFP_NOIO);
				if (qbrb == NULL)
					goto err_partial_write;
				qbrb->kbr = kbr;
				qbrb->cmd = QBD_AIO_PARTIAL_WRITE;
				qbrb->curr_sector = 0;
				qbrb->buf_offset = 0;
				qbrb->nb_sectors = 0;
				kbr->uio_count = 1;
				/* Fake qbrb has enqueued qbd_queue and send out to store */
				qbd_check_ready_timeout(qbrb);
				qbd_check_send_timeout(qbrb);
				qbd_aio_partial_handler(0, qbrb);
			}
			wake_up_process(qbd->qbd_queue_thread);
			break;

		default:
			qbd_err("[%s] unknown request cmd:%d", qbd->devname, kbr->cmd);
			atomic_inc(&qbd->error_count);
			qbd_blk_end_request(kbr->req, EIO);
			size = (kbr->elba - kbr->slba + 1) << QBD_SECTOR_BITS;
			kvfree(kbr->buf);
			atomic_dec(&kbr->qbd->kernel_request_count);
			kmem_cache_free(kb_request_cache, kbr);
			wake_up(&qbd->kernel_request_wait);
			break;

err_qbr:
			for (--curr; curr >= 0; curr--)
				kmem_cache_free(qb_request_cache, qbrlist[curr]);
			kfree(qbrlist);
err_partial_write:
			/* remove from wio if QBD_AIO_WRITE and retry */
			spin_lock(&kbr->qbd->kernel_queue_lock);
			if (kbr->cmd == QBD_AIO_WRITE) {
				list_del_init(&kbr->entry);
			}
			list_add_tail(&kbr->entry, &qbd->kernel_queue);
			spin_unlock(&kbr->qbd->kernel_queue_lock);
			/* schedule for more memory back */
			schedule_timeout_interruptible(msecs_to_jiffies(100));
			break;
		}
	}
	WARN(!list_empty(&qbd->kernel_queue), "qbd_queue is not empty");
	return 0;
}

int qbd_queue_thread(void *opaque)
{
	struct qbd_device *qbd = opaque;
	struct qb_request *qbr;
	int ret = 0;

	set_user_nice(current, MIN_NICE);
	while (!kthread_should_stop()) {
		spin_lock(&qbd->qbd_queue_lock);
		if (list_empty(&qbd->qbd_queue)) {
			spin_unlock(&qbd->qbd_queue_lock);
			schedule_timeout_interruptible(msecs_to_jiffies(1));
			continue;
		}
		qbr = list_first_entry(&qbd->qbd_queue, struct qb_request, list);
		list_del_init(&qbr->list);
		spin_unlock(&qbd->qbd_queue_lock);
		/*
		 * Check if qbd sector requests can be finished handling in (warn_delay)ms,
		 * and ready send to store.
		 */
		qbd_check_ready_timeout(qbr);
		switch (qbr->cmd) {
		case QBD_AIO_READ:
			while ((ret = qbd_aio_read(qbd->vol,
						   qbr->kbr->buf + qbr->buf_offset,
						   qbr->curr_sector,
						   qbr->nb_sectors,
						   qbd_aio_aligned_handler,
						   qbr)) == -EAGAIN) {
				schedule_timeout_interruptible(usecs_to_jiffies(10));
			}
			break;
		case QBD_AIO_WRITE:
			while ((ret = qbd_aio_write(qbd->vol,
						    qbr->kbr->buf + qbr->buf_offset,
						    qbr->curr_sector,
						    qbr->nb_sectors,
						    qbd_aio_aligned_handler,
						    qbr)) == -EAGAIN) {
				schedule_timeout_interruptible(usecs_to_jiffies(10));
			}
			break;
		case QBD_AIO_PARTIAL_WRITE:
			while ((ret = qbd_aio_read(qbd->vol,
						   qbr->kbr->buf + qbr->buf_offset,
						   qbr->curr_sector,
						   qbr->nb_sectors,
						   qbd_aio_partial_handler,
						   qbr)) == -EAGAIN) {
				schedule_timeout_interruptible(usecs_to_jiffies(10));
			}
			break;
		default:
			/* Critical, queue has been corrupted */
			qbd_fatal("[%s] unhandled cmd operation %d", qbd->devname, qbr->cmd);
			break;
		}
		/* if error happened, we have to call the callback to keep io being handled correctly */
		if (unlikely(ret != 0)) {
			qbd_err("[%s] %s error aio[%llu:%u] with retcode:%d",
				qbr->kbr->qbd->devname,
				QBDAIOStr[qbr->kbr->cmd],
				qbr->kbr->sector_num,
				qbr->kbr->nb_sectors,
				ret);
			switch(qbr->cmd) {
			case QBD_AIO_READ:
			case QBD_AIO_WRITE:
				qbd_aio_aligned_handler(ret, qbr);
				break;
			case QBD_AIO_PARTIAL_WRITE:
				qbd_aio_partial_handler(ret, qbr);
				break;
			default:
				break;
			}
		}
	}
	WARN(!list_empty(&qbd->qbd_queue), "qbd_queue is not empty");
	return 0;
}

static int qbd_bd_open(struct block_device *bdev, fmode_t mode)
{
	struct qbd_device *qbd = bdev->bd_disk->private_data;
	return qbd_device_try_get(qbd);
}

#ifdef HAVE_KERNEL_BLOCK_DEVICE_OPERATIONS_RELEASE_VOID
static void qbd_bd_release(struct gendisk *disk, fmode_t mode)
#else
static int qbd_bd_release(struct gendisk *disk, fmode_t mode)
#endif
{
	struct qbd_device *qbd = disk->private_data;
	int ret = 0;

	if (!qbd) {
		ret = -ENOENT;
		goto out;
	}
	qbd_device_put(qbd);
out:
#ifdef HAVE_KERNEL_BLOCK_DEVICE_OPERATIONS_RELEASE_VOID
	return;
#else
	return ret;
#endif
}

static const struct block_device_operations qbd_bd_ops = {
	.owner		= THIS_MODULE,
	.open		= qbd_bd_open,
	.release	= qbd_bd_release,
};

int qbd_init_disk(struct qbd_device *qbd)
{
	struct gendisk *disk;
	struct request_queue *q;
	struct qbd_volume *vol = qbd->vol;
	int err;

	disk = alloc_disk(QBD_MINORS_PER_MAJOR);
	if (!disk)
		return -ENOMEM;

	strcpy(disk->disk_name, qbd->devname);
	disk->major = qbd_major;
	disk->first_minor = qbd->id << 4;
	disk->fops = &qbd_bd_ops;
	disk->private_data = qbd;
	/* if open snapshot, set device readonly */
	if (vol->snap_name[0] != '\0')
		set_disk_ro(disk, 1);

	q = qbd_blk_init_queue(qbd);
	if (!q) {
		put_disk(disk);
		return -ENOMEM;
	}

	disk->queue = q;
	q->queuedata = qbd;
	qbd->disk = disk;

	/* Set basic queue attr before volume setup */
	blk_queue_logical_block_size(disk->queue, 512);
	blk_queue_physical_block_size(disk->queue, 4096);

	/* Device will not work for read nor write until capacity set to !0 */
	set_capacity(disk, 0);

	/* Init qbd delay info */
	err = qbd_delay_info_init(qbd);
	if (err)
		goto err_cleanup_queue;

	/* Register udevd related attr before add_disk */
	disk_to_dev(disk)->groups = qbd_attr_groups;

	add_disk(disk);
	/* Register additional attrs */
	err = qbd_shards_group_create(qbd);
	if (err)
		goto err_delay_info_destroy;

	qbd_info("[%s] add volume %s%s%s%s, id:%#llx succeed, qbd:%px",
		 disk->disk_name,
		 vol->legacy_protocol ? "" : (vol->type == RDMA ? "rdma://" : "tcp://"),
		 vol->name,
		 vol->snap_name[0] == '\0' ? "" : "@",
		 vol->snap_name[0] == '\0' ? "" : vol->snap_name,
		 vol->id,
		 qbd);

	return 0;

err_delay_info_destroy:
	qbd_delay_info_destroy(qbd);
err_cleanup_queue:
	qbd_blk_cleanup_queue(q);
	put_disk(disk);
	return err;
}

void qbd_free_disk(struct qbd_device *qbd)
{
	struct gendisk *disk = qbd->disk;
	struct qbd_volume *vol = qbd->vol;

	if (!disk)
		return;

	/* clean qbd device's extra attrs on sysfs */
	qbd_shards_group_destroy(qbd);
	qbd_delay_info_destroy(qbd);

	if (disk->flags & GENHD_FL_UP)
		del_gendisk(disk);
	if (disk->queue)
		blk_cleanup_queue(disk->queue);
	qbd_info("[%s] volume %s%s%s%s released",
		 disk->disk_name,
		 vol->legacy_protocol ? "" : (vol->type == RDMA ? "rdma://" : "tcp://"),
		 vol->name,
		 vol->snap_name[0] == '\0' ? "" : "@",
		 vol->snap_name[0] == '\0' ? "" : vol->snap_name);
	put_disk(disk);
}
