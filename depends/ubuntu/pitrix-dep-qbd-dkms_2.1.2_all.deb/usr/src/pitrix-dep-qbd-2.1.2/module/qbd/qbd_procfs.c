#include <linux/proc_fs.h>
#include <linux/seq_file.h>

#include "qbd_client.h"
#include "qbd.h"

static struct proc_dir_entry *proc_qbdstat;	/* /proc/qbdstat */

static void *qbdstat_start(struct seq_file *m, loff_t *pos)
{
	mutex_lock(&ctl_mutex);
	return seq_list_start(&qbd_device_list, *pos);
}

static void *qbdstat_next(struct seq_file *m, void *p, loff_t *pos)
{
	return seq_list_next(p, &qbd_device_list, pos);
}

static void qbdstat_stop(struct seq_file *file, void *data)
{
	mutex_unlock(&ctl_mutex);
}

static int qbdstat_show(struct seq_file *m, void *p)
{
	struct qbd_device *qbd = list_entry(p, struct qbd_device, node);
	if (p == qbd_device_list.next)
		seq_printf(m, "dev_id\tvol_id\tdevice\tvolume\tconfig\tread_bps\twrite_bps\tread_iops\twrite_iops\n");
	seq_printf(m, "%d\t%#llx\t%s\t%s%s%s%s\t%s\t%llu\t%llu\t%llu\t%llu\n",
		   qbd->id,
		   qbd->vol->id,
		   qbd->devname,
		   qbd->vol->legacy_protocol ? "" : (qbd->vol->type == TCP ? "tcp://" : "rdma://"),
		   qbd->vol->name,
		   qbd->vol->snap_name[0] == '\0' ? "" : "@",
		   qbd->vol->snap_name[0] == '\0' ? "" : qbd->vol->snap_name,
		   qbd->vol->cfg_file,
		   qbd->vol->throttle.value[THROTTLE_SET_READ_BPS],
		   qbd->vol->throttle.value[THROTTLE_SET_WRITE_BPS],
		   qbd->vol->throttle.value[THROTTLE_SET_READ_IOPS],
		   qbd->vol->throttle.value[THROTTLE_SET_WRITE_IOPS]);
	return 0;
}

static const struct seq_operations qbdstat_sops = {
	.start	= qbdstat_start,
	.next	= qbdstat_next,
	.stop	= qbdstat_stop,
	.show	= qbdstat_show,
};

static int qbdstat_open(struct inode *inode, struct file *file)
{
	return seq_open(file, &qbdstat_sops);
}

#ifdef HAVE_KERNEL_PROC_OPS
static const struct proc_ops proc_qbdstat_ops = {
	.proc_open	= qbdstat_open,
	.proc_read	= seq_read,
	.proc_lseek	= seq_lseek,
	.proc_release	= seq_release,
};
#else
static const struct file_operations proc_qbdstat_ops = {
	.open		= qbdstat_open,
	.read		= seq_read,
	.llseek		= seq_lseek,
	.release	= seq_release,
};
#endif

int qbd_procfs_init(void)
{
	proc_qbdstat = proc_create("qbdstat", 0, NULL, &proc_qbdstat_ops);
	return 0;
}

void qbd_procfs_cleanup(void)
{
	remove_proc_entry("qbdstat", NULL);
}
