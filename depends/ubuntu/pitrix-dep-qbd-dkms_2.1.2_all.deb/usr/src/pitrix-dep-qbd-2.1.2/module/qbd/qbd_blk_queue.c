#include "qbd_device.h"
#include "qbd_client.h"
#include "linux/mm_compat.h"

/* qbd blk request function */
#ifdef HAVE_KERNEL_BLK_SINGLE_QUEUE
static void qbd_async_rq_fn(struct request_queue *q)
{
	struct request *req;
	struct qbd_device *qbd;
	struct kb_request *kbr;
	size_t size;
	unsigned int noreclaim_flag = 0;
	int kvmalloc_noreclaim = qbd_kvmalloc_noreclaim;

	while ((req = blk_fetch_request(q)) != NULL) {
		qbd = disk_to_qbd(req->rq_disk);
		BUG_ON(qbd->magic != QBD_MAGIC);

		/*
		 * kernel requests will split into qbd requests, when all qbd requests delayed for long time,
		 * it will increase delay for kernel request, so kernel requests count should not exceed iodepth too much.
		 * however, when update iodepth and blk_start_queue, kernel_request_count sometimes burst to max_io_depth.
		 */
		if (likely(qbd->vol->status == VOLUME_STATUS_OPENED) &&
		    atomic_read(&qbd->kernel_request_count) > qbd->vol->max_io_depth) {
			blk_requeue_request(q, req);
			spin_unlock_irq(q->queue_lock);
			wait_event_timeout(qbd->kernel_request_wait, atomic_read(&qbd->kernel_request_count) <= qbd->vol->max_io_depth, HZ);
			spin_lock_irq(q->queue_lock);
			continue;
		}

		spin_unlock_irq(q->queue_lock);

		kbr = kmem_cache_alloc(kb_request_cache, GFP_NOIO);
		if (kbr == NULL) {
			qbd_dev_err_ratelimited(qbd, "[%s] kmem_cache_alloc kb_request_cache failed, requeue io request",
						qbd->devname);
			schedule_timeout_interruptible(usecs_to_jiffies(100));
			spin_lock_irq(q->queue_lock);
			blk_requeue_request(q, req);
			continue;
		}

		kbr->ts_start = qbd->warn_delay ? get_now_nsec() : 0;
		kbr->ts_finish = 0;
		kbr->qbd = qbd;
		kbr->req = req;
		kbr->cmd = rq_data_dir(req) == WRITE ? QBD_AIO_WRITE : QBD_AIO_READ;
		kbr->sector_num = blk_rq_pos(req);
		BUG_ON(blk_rq_bytes(req) % BDRV_SECTOR_SIZE != 0);
		qbd_detailed_debug(qbd, "[%s] kernel io request bytes:%u", qbd->devname, blk_rq_bytes(req));
		kbr->nb_sectors = blk_rq_bytes(req) >> BDRV_SECTOR_BITS;
		BUG_ON(kbr->nb_sectors == 0);
		atomic_set(&kbr->error, 0);

		kbr->slba = kbr->sector_num / QBD_PER_BDRV;
		kbr->elba = (kbr->sector_num + kbr->nb_sectors - 1) / QBD_PER_BDRV;
		size = (kbr->elba - kbr->slba + 1) << QBD_SECTOR_BITS;
		if (kvmalloc_noreclaim)
			noreclaim_flag = memalloc_noreclaim_save();
		kbr->buf = kvmalloc(size, GFP_KERNEL);
		if (kvmalloc_noreclaim)
			memalloc_noreclaim_restore(noreclaim_flag);
		if (kbr->buf == NULL) {
			qbd_dev_err_ratelimited(qbd, "[%s] kvmalloc buffer size[%zu] failed, requeue io request",
						qbd->devname,
						size);
			kmem_cache_free(kb_request_cache, kbr);
			schedule_timeout_interruptible(usecs_to_jiffies(100));
			spin_lock_irq(q->queue_lock);
			blk_requeue_request(q, req);
			continue;
		}
		spin_lock(&qbd->kernel_queue_lock);
		atomic_inc(&qbd->kernel_request_count);
		list_add_tail(&kbr->entry, &qbd->kernel_queue);
		if (kbr->cmd == QBD_AIO_WRITE)
			qbd->write_total++;
		else
			qbd->read_total++;
		spin_unlock(&qbd->kernel_queue_lock);
		wake_up_process(qbd->kernel_queue_thread);
		spin_lock_irq(q->queue_lock);
	}
}

void qbd_blk_cleanup_queue(struct request_queue *q)
{
	blk_cleanup_queue(q);
}

struct request_queue *qbd_blk_init_queue(struct qbd_device *qbd)
{
	struct request_queue *q;

	spin_lock_init(&qbd->queue_lock);
	q = blk_init_queue(qbd_async_rq_fn, &qbd->queue_lock);

	return q;
}
#else
static blk_status_t qbd_queue_rq(struct blk_mq_hw_ctx *hctx, const struct blk_mq_queue_data *bd)
{
	struct request *req;
	struct qbd_device *qbd;
	struct kb_request *kbr;
	size_t size;
	unsigned int noreclaim_flag = 0;
	int kvmalloc_noreclaim = qbd_kvmalloc_noreclaim;
	int ret = BLK_STS_DEV_RESOURCE;

	req = bd->rq;
	qbd = disk_to_qbd(req->rq_disk);
	BUG_ON(qbd->magic != QBD_MAGIC);
	blk_mq_start_request(bd->rq);

	/*
	 * kernel requests will split into qbd requests, when all qbd requests delayed for long time,
	 * it will increase delay for kernel request, so kernel requests count should not exceed iodepth too much.
	 * however, when update iodepth and blk_start_queue, kernel_request_count sometimes burst to max_io_depth.
	 */
	if (likely(qbd->vol->status == VOLUME_STATUS_OPENED) &&
	    atomic_read(&qbd->kernel_request_count) > qbd->vol->max_io_depth) {
		goto out;
	}

	kbr = kmem_cache_alloc(kb_request_cache, GFP_NOIO);
	if (kbr == NULL) {
		qbd_dev_err_ratelimited(qbd, "[%s] kmem_cache_alloc kb_request_cache failed, requeue io request",
					qbd->devname);
		goto out;
	}

	kbr->ts_start = qbd->warn_delay ? get_now_nsec() : 0;
	kbr->ts_finish = 0;
	kbr->qbd = qbd;
	kbr->req = req;
	kbr->cmd = rq_data_dir(req) == WRITE ? QBD_AIO_WRITE : QBD_AIO_READ;
	kbr->sector_num = blk_rq_pos(req);
	BUG_ON(blk_rq_bytes(req) % BDRV_SECTOR_SIZE != 0);
	qbd_detailed_debug(qbd, "[%s] kernel io request bytes:%u", qbd->devname, blk_rq_bytes(req));
	kbr->nb_sectors = blk_rq_bytes(req) >> BDRV_SECTOR_BITS;
	BUG_ON(kbr->nb_sectors == 0);
	atomic_set(&kbr->error, 0);

	kbr->slba = kbr->sector_num / QBD_PER_BDRV;
	kbr->elba = (kbr->sector_num + kbr->nb_sectors - 1) / QBD_PER_BDRV;
	size = (kbr->elba - kbr->slba + 1) << QBD_SECTOR_BITS;
	if (kvmalloc_noreclaim)
		noreclaim_flag = memalloc_noreclaim_save();
	kbr->buf = kvmalloc(size, GFP_KERNEL);
	if (kvmalloc_noreclaim)
		memalloc_noreclaim_restore(noreclaim_flag);
	if (kbr->buf == NULL) {
		qbd_dev_err_ratelimited(qbd, "[%s] kvmalloc buffer size[%zu] failed, requeue io request",
					qbd->devname,
					size);
		kmem_cache_free(kb_request_cache, kbr);
		goto out;
	}

	spin_lock(&qbd->kernel_queue_lock);
	atomic_inc(&qbd->kernel_request_count);
	list_add_tail(&kbr->entry, &qbd->kernel_queue);
	if (kbr->cmd == QBD_AIO_WRITE)
		qbd->write_total++;
	else
		qbd->read_total++;
	spin_unlock(&qbd->kernel_queue_lock);
	wake_up_process(qbd->kernel_queue_thread);

	ret =  BLK_STS_OK;
out:
	return ret;
}

static const struct blk_mq_ops qbd_mq_ops = {
	.queue_rq = qbd_queue_rq,
};

void qbd_blk_cleanup_queue(struct request_queue *q)
{
	struct qbd_device *qbd = (struct qbd_device *)q->queuedata;
	blk_mq_free_tag_set(&qbd->tag_set);
}

struct request_queue *qbd_blk_init_queue(struct qbd_device *qbd)
{
	struct request_queue *q;

	q = blk_mq_init_sq_queue(&qbd->tag_set, &qbd_mq_ops, qbd->vol->max_io_depth,
				 BLK_MQ_F_SHOULD_MERGE | BLK_MQ_F_BLOCKING);
	if (IS_ERR(q))
		return NULL;

	return q;
}
#endif
