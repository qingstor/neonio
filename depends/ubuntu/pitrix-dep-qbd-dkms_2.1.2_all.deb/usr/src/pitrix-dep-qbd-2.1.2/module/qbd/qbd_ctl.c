#include <linux/kernel.h>
#include <linux/blkdev.h>
#include <linux/kthread.h>
#include <linux/miscdevice.h>

#include "linux/blkdev_compat.h"
#include "linux/sched_compat.h"
#include "linux/mm_compat.h"

#include "qbd.h"
#include "qbd_device.h"
#include "qbd_client.h"
#include "qbd_sysfs.h"
#include "qbd_ctl.h"
#include "qbd_crypt.h"
#include "qbd_client_tcp.h"
#include "qbd_client_rdma.h"

static void qbd_disk_resize_work(struct work_struct *work)
{
	struct qbd_device *qbd = container_of(work, struct qbd_device, disk_resize_work);
	sector_t old_sectnr = get_capacity(qbd->disk);

	if ((qbd->vol->size >> BDRV_SECTOR_BITS) > old_sectnr) {
		set_capacity(qbd->disk, qbd->vol->size >> BDRV_SECTOR_BITS);
		revalidate_disk(qbd->disk);
	}
}

static void qbd_iodepth_resize_work(struct work_struct *work)
{
	struct qbd_device *qbd = container_of(work, struct qbd_device, iodepth_resize_work);

	qbd_resize_iodepth(qbd->vol);
}

static void qbd_wq_queue_work(struct work_struct *work)
{
	queue_work(qbd_wq, work);
}

static int qbd_device_map(struct qbd_volume *vol)
{
	struct qbd_device *qbd, *q;
	struct module *module;
	int new_id = 0;
	int loop, rc;

	qbd = kzalloc(sizeof(struct qbd_device), GFP_KERNEL);
	if (!qbd) {
		qbd_err("kzalloc qbd_device failed");
		goto err_out;
	}
	qbd->vol = kzalloc(sizeof(struct qbd_volume), GFP_KERNEL);
	if (!qbd) {
		qbd_err("kzalloc qbd_volume failed");
		goto err_free_qbd;
	}

	qbd->magic = QBD_MAGIC;
	qbd->detailed = qbd_detailed;
	qbd->warn_delay = qbd_warn_delay;
	qbd->heartbeat_timeout = qbd_heartbeat_timeout;
	spin_lock_init(&qbd->lock);
	qbd->flags = 0;
	qbd->open_count = 0;
	INIT_LIST_HEAD(&qbd->node);
	qbd_ratelimit_init(&qbd->aio_err_rs);
	qbd_ratelimit_init(&qbd->aio_info_rs);
	INIT_WORK(&qbd->disk_resize_work, qbd_disk_resize_work);
	INIT_WORK(&qbd->iodepth_resize_work, qbd_iodepth_resize_work);
	atomic_set(&qbd->error_count, 0);
	rwlock_init(&qbd->sysfs_lock);
	qbd->read_total = 0;
	qbd->write_total = 0;
	qbd->wio_range_read_hits = 0;
	qbd->wio_range_write_hits = 0;

	memcpy(qbd->vol, vol, sizeof(struct qbd_volume));
	qbd->vol->cops = qbd_client_ops_get(qbd->vol->type);
	if (!qbd->vol->cops) {
		qbd_err("get client failed, type:%d", qbd->vol->type);
		goto err_free_vol;
	}

	module = qbd->vol->cops->owner;
	if (!try_module_get(module)) {
		qbd_err("get module failed, type:%d", qbd->vol->type);
		goto err_free_vol;
	}

	/* generate unique id */
	mutex_lock(&ctl_mutex);
	list_for_each_entry(q, &qbd_device_list, node) {
		if (new_id != q->id)
			break;
		new_id++;
	}
	qbd->id = new_id;
	list_add(&qbd->node, q->node.prev);
	mutex_unlock(&ctl_mutex);

	qbd->major = qbd_major;
	/* Set device name to qbdn */
	sprintf(qbd->devname, "%s%d", QBD_DRV_NAME, qbd->id);

	/* Set volume's attrs */
	if (vol->shard_count <= 0 || vol->size <= 0) {
		qbd_err("[%s] invalid shard_count:%d or size:%zu", qbd->devname, vol->shard_count, vol->size);
		goto err_put_module;
	}
	qbd->vol->shards = kmalloc(sizeof(struct qbd_client_shard) * vol->shard_count, GFP_KERNEL);
	if (qbd->vol->shards == NULL) {
		qbd_err("[%s] kmalloc shards failed:%d", qbd->devname, vol->shard_count);
		goto err_put_module;
	}
	if (copy_from_user(qbd->vol->shards,
			   vol->shards,
			   qbd->vol->shard_count * sizeof(struct qbd_client_shard))) {
		qbd_err("[%s] copy_from_user qbd_client_shard failed", qbd->devname);
		goto err_free_shards;
	}
	qbd->shard_stats = kzalloc(sizeof(struct qbd_shard_stat) * vol->shard_count, GFP_KERNEL);
	if (qbd->shard_stats == NULL) {
		qbd_err("[%s] kzalloc shard_stats failed:%d", qbd->devname, vol->shard_count);
		goto err_free_shards;
	}

	for (loop = THROTTLE_SET_READ_BPS; loop < THROTTLE_SET_MAX_NUM; loop++)
		qbd->vol->throttle.value[loop] = 0;
	qbd->max_sectors = qbd->vol->max_blocksize >> QBD_SECTOR_BITS;
	qbd_info("[%s] max_sectors: %d x 4k", qbd->devname, qbd->max_sectors);
	qbd->vol->qbd = qbd;
	qbd_info("[%s] transport type: %s", qbd->devname, qbd->vol->type == TCP ? "TCP" : "RDMA");
	if (qbd->vol->keyid[0] != '\0') {
		qbd_encrypt(vol->keyid, qbd->vol->keyid, QBD_CRYPT_MAX);
		qbd_encrypt(vol->passphrass, qbd->vol->passphrass, QBD_CRYPT_MAX);
	}
	qbd_info("[%s] encrypted: %s", qbd->devname, vol->keyid[0] != '\0' ? "yes" : "no");

	/* Init qbd disk */
	rc = qbd_init_disk(qbd);
	if (rc) {
		qbd_err("[%s] qbd_init_disk failed:%d", qbd->devname, rc);
		goto err_free_shard_stats;
	}

	if (qbd_open_volume(qbd->vol)) {
		qbd_err("[%s] open failed", qbd->devname);
		goto err_free_disk;
	}

	/* Set queue attr depends on volume attr */
	blk_queue_io_opt(qbd->disk->queue, QBD_SECTOR_SIZE);
	blk_queue_max_hw_sectors(qbd->disk->queue, qbd->vol->max_blocksize >> BDRV_SECTOR_BITS);
	blk_queue_max_segment_size(qbd->disk->queue, qbd->vol->max_blocksize);
	blk_queue_max_segments(qbd->disk->queue, qbd->vol->max_io_depth);

	spin_lock_init(&qbd->qbd_queue_lock);
	INIT_LIST_HEAD(&qbd->qbd_queue);
	spin_lock_init(&qbd->kernel_queue_lock);
	INIT_LIST_HEAD(&qbd->kernel_queue);

	INIT_LIST_HEAD(&qbd->wio_range_queue);

	/* Startup qbd queue handler task */
	qbd->qbd_queue_thread = kthread_run(qbd_queue_thread, qbd, "qbd_q_%s", qbd->devname);
	if (IS_ERR(qbd->qbd_queue_thread)) {
		qbd_err("[%s] create qbd_queue_thread failed", qbd->devname);
		goto err_close_volume;
	}
	/* Startup kernel queue handler task */
	atomic_set(&qbd->kernel_request_count, 0);
	qbd->kernel_queue_thread = kthread_run(kernel_queue_thread, qbd, "qbd_k_%s", qbd->devname);
	if (IS_ERR(qbd->kernel_queue_thread)) {
		qbd_err("[%s] create kernel_queue_thread failed", qbd->devname);
		goto err_stop_qbd_queue_thread;
	}
	init_waitqueue_head(&qbd->kernel_request_wait);

	/* Set disk capacity for full working */
	set_capacity(qbd->disk, qbd->vol->size >> BDRV_SECTOR_BITS);
	return 0;

err_stop_qbd_queue_thread:
	kthread_stop(qbd->qbd_queue_thread);
err_close_volume:
	qbd_close_volume(qbd->vol);
err_free_disk:
	qbd_free_disk(qbd);
err_free_shard_stats:
	kfree(qbd->shard_stats);
err_free_shards:
	kfree(qbd->vol->shards);
err_put_module:
	mutex_lock(&ctl_mutex);
	list_del_init(&qbd->node);
	mutex_unlock(&ctl_mutex);
	module_put(module);
err_free_vol:
	kfree(qbd->vol);
err_free_qbd:
	kfree(qbd);
err_out:
	return -EFAULT;
}

static int qbd_device_unmap(struct qbd_device *qbd)
{
	int ret = 0;
	struct module *module;

	ret = qbd_device_removing_test_and_set(qbd);
	if (ret != 0)
		return ret;

	flush_work(&qbd->disk_resize_work);
	flush_work(&qbd->iodepth_resize_work);

	module = qbd->vol->cops->owner;
	if (get_capacity(qbd->disk)) {
		kthread_stop(qbd->kernel_queue_thread);
		kthread_stop(qbd->qbd_queue_thread);
		qbd_close_volume(qbd->vol);
		qbd_free_disk(qbd);
		kfree(qbd->vol->shards);
		kfree(qbd->shard_stats);
	}

	mutex_lock(&ctl_mutex);
	list_del_init(&qbd->node);
	mutex_unlock(&ctl_mutex);
	kfree(qbd->vol);
	kfree(qbd);
	module_put(module);
	return 0;
}

static int qbd_device_remap(struct qbd_device *qbd, struct qbd_volume *vol)
{
	int ret = 0;
	bool cflag;
	void *client = qbd->vol->client;
	unsigned long *status_ptr = NULL;

	if (qbd_device_try_get(qbd)) {
		ret = -ENOENT;
		goto out;
	}

	/*
	 * If called by the user command line, and client status has not CLIENT_STATUS_REOPEN_VOL,
	 * set it and let qbd driver handle it.
	 */
	if (qbd->vol->type == TCP)
		status_ptr = &((struct qbd_client_tcp *)client)->status;
	else
		status_ptr = &((struct qbd_client_rdma *)client)->status;

	if (!(*status_ptr & CLIENT_STATUS_REOPEN_VOL)) {
		*status_ptr |= CLIENT_STATUS_REOPEN_VOL;
		qbd->vol->open_ts = 0;
		goto out_put_qbd;
	}

	if (vol->shard_count <= 0 || vol->size < qbd->vol->size) {
		qbd_err("[%s] invalid shard_count:%d or size:%zu less than the old size:%zu", qbd->devname,
			vol->shard_count, vol->size, qbd->vol->size);
		ret = -EINVAL;
		goto out_put_qbd;
	}

	qbd->vol->meta_ver = vol->meta_ver;
	qbd->vol->tcp_no_delay = vol->tcp_no_delay;
	qbd->vol->io_timeout = vol->io_timeout;
	qbd->vol->conn_timeout = vol->conn_timeout;
	memcpy(&qbd->vol->qos, &vol->qos, sizeof(struct qbd_qos_info));

	write_lock(&qbd->sysfs_lock);
	cflag = qbd->vol->shard_count != vol->shard_count;
	if (cflag) {
		struct qbd_client_shard *new_shards;
		struct qbd_shard_stat *new_stats;

		/* realloc qbd->vol->shards */
		new_shards = kmalloc(sizeof(struct qbd_client_shard) * vol->shard_count, GFP_KERNEL);
		if (new_shards == NULL) {
			qbd_err("[%s] kmalloc shards[%d] failed", qbd->devname, vol->shard_count);
			kfree(qbd->vol->shards);
			qbd->vol->shards = NULL;
			qbd->vol->shard_count = 0;
			write_unlock(&qbd->sysfs_lock);
			ret = -ENOMEM;
			goto out_put_qbd;
		}
		kfree(qbd->vol->shards);
		qbd->vol->shards = new_shards;

		/* realloc qbd->shard_stats and copy old stats to new stats.
		 * if new_stats == NULL, don't free qbd->shard_stats in case
		 * that loses old stat info.
		 */
		new_stats = krealloc(qbd->shard_stats, sizeof(struct qbd_shard_stat) * vol->shard_count,
				     GFP_KERNEL | __GFP_ZERO);
		if (new_stats == NULL) {
			write_unlock(&qbd->sysfs_lock);
			qbd_err("[%s] krealloc shard_stats[%d] failed", qbd->devname, vol->shard_count);
			ret = -ENOMEM;
			goto out_free_shards;
		}
		qbd->shard_stats = new_stats;

		/* update qbd->vol->shard_count */
		qbd->vol->shard_count = vol->shard_count;
	}
	if (copy_from_user(qbd->vol->shards, vol->shards,
			   qbd->vol->shard_count * sizeof(struct qbd_client_shard))) {
		write_unlock(&qbd->sysfs_lock);
		qbd_err("[%s] copy_from_user shards failed", qbd->devname);
		ret = -EFAULT;
		goto out_free_shards;
	}
	write_unlock(&qbd->sysfs_lock);
	/*
	 * If qbd->shard_count has changed and qbd->shards update successfully,
	 * re-register qbd shards attr on sysfs.
	 */
	if (cflag) {
		qbd_shards_group_destroy(qbd);
		ret = qbd_shards_group_create(qbd);
		if (ret)
			goto out_free_shards;
	}

	/* If the volume size has changed, update disk size */
	if (qbd->vol->size < vol->size) {
		qbd->vol->size = vol->size;
		qbd_wq_queue_work(&qbd->disk_resize_work);
	}

	if (qbd_auto_update_iodepth && qbd->vol->max_io_depth != vol->max_io_depth && vol->max_io_depth > 0) {
		bool resizing = false;

		spin_lock_irq(&qbd->lock);
		if (test_bit(QBD_DEV_FLAG_IODEPTH_RESIZING, &qbd->flags))
			resizing = true;
		spin_unlock_irq(&qbd->lock);

		if (!resizing) {
			qbd_info("[%s] iodepth change detected, from %d to %d",
				 qbd->devname,
				 qbd->vol->max_io_depth,
				 vol->max_io_depth);
			qbd->vol->max_io_depth = vol->max_io_depth;
			qbd_wq_queue_work(&qbd->iodepth_resize_work);
		} else {
			qbd_info("[%s] iodepth is resizing", qbd->devname);
		}
	}

	goto out_put_qbd;

out_free_shards:
	write_lock(&qbd->sysfs_lock);
	kfree(qbd->vol->shards);
	qbd->vol->shard_count = 0;
	qbd->vol->shards = NULL;
	write_unlock(&qbd->sysfs_lock);
out_put_qbd:
	qbd_device_put(qbd);
out:
	qbd_info("[%s] %s %s:%d", qbd->devname, __func__, ret == 0 ? "succeed" : "failed", ret);
	return ret;
}

static int qbd_device_setthrottle(struct qbd_device *qbd, struct qbd_volume *vol)
{
	int loop;

	if (qbd_device_try_get(qbd))
		return -ENOENT;

	for (loop = THROTTLE_SET_READ_BPS; loop < THROTTLE_SET_MAX_NUM; loop++)
		if (vol->throttle.value[loop] != UINT64_MAX)
			qbd->vol->throttle.value[loop] = vol->throttle.value[loop];

	qbd_device_put(qbd);
	return 0;
}

static int qbd_device_suspend(struct qbd_device *qbd, struct qbd_volume *vol)
{
	if (qbd_device_try_get(qbd))
		return -ENOENT;

	qbd_blk_stop_queue(qbd->disk->queue);

	qbd_device_put(qbd);
	qbd_info("[%s] device suspended", qbd->devname);
	return 0;
}

static int qbd_device_resume_normal(struct qbd_device *qbd, struct qbd_volume *vol)
{
	if (qbd_device_try_get(qbd))
		return -ENOENT;

	qbd->vol->resume_type = QBD_IOC_RESUME_NORMAL_VOLUME;
	qbd_blk_start_queue(qbd->disk->queue);

	qbd_device_put(qbd);
	qbd_info("[%s] device resumed to normal", qbd->devname);
	return 0;
}

static int qbd_device_resume_error(struct qbd_device *qbd, struct qbd_volume *vol)
{
	if (qbd_device_try_get(qbd))
		return -ENOENT;

	qbd->vol->resume_type = QBD_IOC_RESUME_ERROR_VOLUME;
	qbd_blk_start_queue(qbd->disk->queue);

	qbd_device_put(qbd);
	qbd_info("[%s] device resumed to error", qbd->devname);
	return 0;
}

static int qbd_device_resume_discard(struct qbd_device *qbd, struct qbd_volume *vol)
{
	if (qbd_device_try_get(qbd))
		return -ENOENT;

	qbd->vol->resume_type = QBD_IOC_RESUME_DISCARD_VOLUME;
	qbd_blk_start_queue(qbd->disk->queue);

	qbd_device_put(qbd);
	qbd_info("[%s] device resumed to discard", qbd->devname);
	return 0;
}

static long qbdctl_ioctl(struct file *filp, unsigned cmd, unsigned long arg)
{
	struct qbd_device *qbd;
	struct qbd_volume *vol;
	int ret = -ENXIO;

	/* Only process qbd can do this */
	if (strcmp(current->comm, "qbd")) {
		qbd_err("only qbd is allowed to add qbd devices");
		return -EPERM;
	}

	vol = kmalloc(sizeof(struct qbd_volume), GFP_KERNEL);
	if (!vol) {
		qbd_err("/dev/qbdctl qbd_volume kmalloc failed, ioctl:%d", cmd);
		return -ENOMEM;
	}
	if (copy_from_user(vol, (const void __user *)arg, USER_VOLUME_COPY_SIZE)) {
		qbd_err("/dev/qbdctl copy_from_user qbd_volume failed, ioctl:%d", cmd);
		ret = -EINVAL;
		goto out_free_vol;
	}
	mutex_lock(&ctl_mutex);
	list_for_each_entry(qbd, &qbd_device_list, node) {
		/*
		 * Because qbd util cannot get vol_id, and snap_name is not used,
		 * so take name & cfg_file & type as an uniq qbd_device in kernel.
		 * As neonsan volume is case insensitive, we are not allowed to map
		 * same volume with mixed cases, and qbd actions should be take
		 * volume with case sensitive.
		 */
		if (cmd == QBD_IOC_MAP_VOLUME) {
			/*
			 * udev rule will generate different /dev/qbd/pool/vol with same link to different device,
			 * so volume with same name but different cfg_name and type is not allowed to be mapped.
			 */
			if (!strcasecmp(qbd->vol->name, vol->name)) {
				    ret = 0;
				    break;
			}
		} else if (!strcmp(qbd->vol->name, vol->name) &&
			   !strcmp(qbd->vol->cfg_file, vol->cfg_file) &&
			    qbd->vol->type == vol->type) {
				    ret = 0;
				    break;
		}
	}
	mutex_unlock(&ctl_mutex);
	/* Notice: vol->shards is still __user pointer */
	switch (cmd) {
	case QBD_IOC_MAP_VOLUME:
		if (!ret) {
			qbd_err("/dev/qbdctl volume %s%s%s%s:%s already mapped",
				vol->legacy_protocol ? "" : (vol->type == RDMA ? "rdma://" : "tcp://"),
				vol->name,
				vol->snap_name[0] == '\0' ? "" : "@",
				vol->snap_name[0] == '\0' ? "" : vol->snap_name,
				vol->cfg_file);
			ret = -EEXIST;
			goto out_free_vol;
		}
		ret = qbd_device_map(vol);
		break;
	case QBD_IOC_UNMAP_VOLUME:
		if (ret) {
			qbd_err("/dev/qbdctl volume %s%s%s%s:%s not mapped",
				vol->legacy_protocol ? "" : (vol->type == RDMA ? "rdma://" : "tcp://"),
				vol->name,
				vol->snap_name[0] == '\0' ? "" : "@",
				vol->snap_name[0] == '\0' ? "" : vol->snap_name,
				vol->cfg_file);
			goto out_free_vol;
		}
		ret = qbd_device_unmap(qbd);
		break;
	case QBD_IOC_REMAP_VOLUME:
		if (ret) {
			qbd_err("/dev/qbdctl volume %s%s%s%s:%s not mapped",
				vol->legacy_protocol ? "" : (vol->type == RDMA ? "rdma://" : "tcp://"),
				vol->name,
				vol->snap_name[0] == '\0' ? "" : "@",
				vol->snap_name[0] == '\0' ? "" : vol->snap_name,
				vol->cfg_file);
			goto out_free_vol;
		}
		ret = qbd_device_remap(qbd, vol);
		break;
	case QBD_IOC_SETTHROTTLE_VOLUME:
		if (ret) {
			qbd_err("/dev/qbdctl volume %s%s%s%s:%s not mapped",
				vol->legacy_protocol ? "" : (vol->type == RDMA ? "rdma://" : "tcp://"),
				vol->name,
				vol->snap_name[0] == '\0' ? "" : "@",
				vol->snap_name[0] == '\0' ? "" : vol->snap_name,
				vol->cfg_file);
			goto out_free_vol;
		}
		ret = qbd_device_setthrottle(qbd, vol);
		break;
	case QBD_IOC_SUSPEND_VOLUME:
		if (ret) {
			qbd_err("/dev/qbdctl volume %s%s%s%s:%s not mapped",
				vol->legacy_protocol ? "" : (vol->type == RDMA ? "rdma://" : "tcp://"),
				vol->name,
				vol->snap_name[0] == '\0' ? "" : "@",
				vol->snap_name[0] == '\0' ? "" : vol->snap_name,
				vol->cfg_file);
			goto out_free_vol;
		}
		ret = qbd_device_suspend(qbd, vol);
		break;
	case QBD_IOC_RESUME_NORMAL_VOLUME:
		if (ret) {
			qbd_err("/dev/qbdctl volume %s%s%s%s:%s not mapped",
				vol->legacy_protocol ? "" : (vol->type == RDMA ? "rdma://" : "tcp://"),
				vol->name,
				vol->snap_name[0] == '\0' ? "" : "@",
				vol->snap_name[0] == '\0' ? "" : vol->snap_name,
				vol->cfg_file);
			goto out_free_vol;
		}
		ret = qbd_device_resume_normal(qbd, vol);
		break;
	case QBD_IOC_RESUME_ERROR_VOLUME:
		if (ret) {
			qbd_err("/dev/qbdctl volume %s%s%s%s:%s not mapped",
				vol->legacy_protocol ? "" : (vol->type == RDMA ? "rdma://" : "tcp://"),
				vol->name,
				vol->snap_name[0] == '\0' ? "" : "@",
				vol->snap_name[0] == '\0' ? "" : vol->snap_name,
				vol->cfg_file);
			goto out_free_vol;
		}
		ret = qbd_device_resume_error(qbd, vol);
		break;
	case QBD_IOC_RESUME_DISCARD_VOLUME:
		if (ret) {
			qbd_err("/dev/qbdctl volume %s%s%s%s:%s not mapped",
				vol->legacy_protocol ? "" : (vol->type == RDMA ? "rdma://" : "tcp://"),
				vol->name,
				vol->snap_name[0] == '\0' ? "" : "@",
				vol->snap_name[0] == '\0' ? "" : vol->snap_name,
				vol->cfg_file);
			goto out_free_vol;
		}
		ret = qbd_device_resume_discard(qbd, vol);
		break;
	default:
		qbd_err("/dev/qbdctl volume %s%s%s%s:%s not supported ioctl:%#x",
				vol->legacy_protocol ? "" : (vol->type == RDMA ? "rdma://" : "tcp://"),
				vol->name,
				vol->snap_name[0] == '\0' ? "" : "@",
				vol->snap_name[0] == '\0' ? "" : vol->snap_name,
				vol->cfg_file,
				cmd);
		ret = -ENOTTY;
		break;
	}
out_free_vol:
	kfree(vol);
	return ret;
}

static const struct file_operations qbdctl_fops = {
	.unlocked_ioctl	= qbdctl_ioctl,
	.owner		= THIS_MODULE,
};

static struct miscdevice qbd_ctl = {
	.minor	= MISC_DYNAMIC_MINOR,
	.name	= "qbdctl",
	.fops	= &qbdctl_fops,
};

int qbd_ctl_init(void)
{
	return misc_register(&qbd_ctl);
}

void qbd_ctl_cleanup(void)
{
	misc_deregister(&qbd_ctl);
}
