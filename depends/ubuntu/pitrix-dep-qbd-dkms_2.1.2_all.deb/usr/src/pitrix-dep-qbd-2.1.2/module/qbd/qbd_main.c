/*
   - Export NeonSAN block device as a Linux block device(qbd)

   Copyright 2017 Yunify, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; see the file COPYING.  If not, write to
   the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.

 */

#include <linux/kernel.h>
#include <linux/device.h>
#include <linux/module.h>
#include <linux/blkdev.h>
#include <linux/mm.h>
#include <linux/vmalloc.h>
#include <linux/kobject.h>
#include <linux/sysfs.h>
#include "linux/blkdev_compat.h"
#include "linux/sched_compat.h"
#include "linux/mm_compat.h"
#include "linux/workqueue_compat.h"

#include "qbd.h"
#include "qbd_ctl.h"
#include "qbd_client.h"
#include "qbd_procfs.h"
#include "qbd_sysfs.h"

const char *QBDAIOStr[QBD_AIO_MAX] = {
	"read",
	"write",
	"partialwrite"
};

DEFINE_MUTEX(ctl_mutex);
LIST_HEAD(qbd_device_list);	/* qbd device list with id sorted, protected by ctl_mutex */
int qbd_major;

struct kmem_cache *kb_request_cache;	/* kernel block request cache */
struct kmem_cache *qb_request_cache;	/* qbd block request cache */

struct workqueue_struct *qbd_wq;

int qbd_warn_delay = 3000;
module_param(qbd_warn_delay, uint, 0644);
MODULE_PARM_DESC(qbd_warn_delay, "QBD default warn delay ms for showing logs");

int qbd_detailed = 0;
module_param(qbd_detailed, uint, 0644);
MODULE_PARM_DESC(qbd_detailed, "QBD default log level, 0:disable, 1:enable");

int qbd_read_wait_write_done = 0;
module_param(qbd_read_wait_write_done, uint, 0644);
MODULE_PARM_DESC(qbd_read_wait_write_done, "QBD IO handle sequence, should read wait write done, 0:no, 1:yes");

int qbd_kvmalloc_noreclaim = 0;
module_param(qbd_kvmalloc_noreclaim, uint, 0644);
MODULE_PARM_DESC(qbd_kvmalloc_noreclaim, "QBD kvmalloc with noreclaim, 0:disable, 1:enable");

int qbd_heartbeat_timeout = 300;
module_param(qbd_heartbeat_timeout, uint, 0644);
MODULE_PARM_DESC(qbd_heartbeat_timeout, "QBD max heartbeat timeout second when no rw io");

int qbd_auto_update_iodepth = 0;
module_param(qbd_auto_update_iodepth, uint, 0644);
MODULE_PARM_DESC(qbd_auto_update_iodepth, "QBD auto update iodepth when remap volume, 0:disable, 1:enable");

int qbd_remap_max_retry = 1;
module_param(qbd_remap_max_retry, uint, 0644);
MODULE_PARM_DESC(qbd_remap_max_retry, "QBD remap retry max times, 0:forever, x: retry remap x times");
EXPORT_SYMBOL(qbd_remap_max_retry);

int qbd_retire_seconds = 60;
module_param(qbd_retire_seconds, uint, 0644);
MODULE_PARM_DESC(qbd_retire_seconds, "QBD retire seconds until next retry when open/reopen finally failed");
EXPORT_SYMBOL(qbd_retire_seconds);

/* the timeout of the whole period of kernel io handled in qbd */
int qbd_kernel_io_timeout = 300;
module_param(qbd_kernel_io_timeout, uint, 0644);
MODULE_PARM_DESC(qbd_kernel_io_timeout, "QBD kernel io timeout in seconds, default is 300, 0:ignore");
EXPORT_SYMBOL(qbd_kernel_io_timeout);

static int qbd_slab_init(void)
{
	kb_request_cache = kmem_cache_create("kb_request_cache", sizeof(struct kb_request),
					     __alignof(sizeof(struct kb_request)), 0, NULL);
	if (!kb_request_cache)
		goto error_kb_request;

	qb_request_cache = kmem_cache_create("qb_request_cache", sizeof(struct qb_request),
					     __alignof(sizeof(struct qb_request)), 0, NULL);
	if (!qb_request_cache)
		goto error_qb_request;

	return 0;

error_qb_request:
	kmem_cache_destroy(kb_request_cache);

error_kb_request:
	return -ENOMEM;
}

static void qbd_slab_cleanup(void)
{
	kmem_cache_destroy(qb_request_cache);
	kmem_cache_destroy(kb_request_cache);
}

static int __init qbd_init(void)
{
	int rc;

	rc = qbd_slab_init();
	if (rc)
		return rc;

	rc = qbd_procfs_init();
	if (rc)
		goto err_qbd_slab;

	rc = qbd_ctl_init();
	if (rc) {
		pr_err("qbdctl failed:%d", rc);
		goto err_qbd_procfs;
	}

	qbd_wq = alloc_workqueue("qbd-wq", 0, 0);
	if (!qbd_wq) {
		rc = -ENOMEM;
		pr_err("qbd-wq alloc failed");
		goto err_qbd_ctl;
	}

	qbd_major = register_blkdev(0, QBD_DRV_NAME);
	if (qbd_major < 0) {
		rc = qbd_major;
		goto err_qbd_wq;
	}
	qbd_info(QBD_DESCRIPTION " Loaded, version:%s", VERSION);
	return 0;

err_qbd_wq:
	destroy_workqueue(qbd_wq);
err_qbd_ctl:
	qbd_ctl_cleanup();
err_qbd_procfs:
	qbd_procfs_cleanup();
err_qbd_slab:
	qbd_slab_cleanup();
	return rc;
}

static void __exit qbd_exit(void)
{
	unregister_blkdev(qbd_major, QBD_DRV_NAME);
	destroy_workqueue(qbd_wq);
	qbd_ctl_cleanup();
	qbd_procfs_cleanup();
	qbd_slab_cleanup();
	qbd_info(QBD_DESCRIPTION " Unloaded");
}

module_init(qbd_init);
module_exit(qbd_exit);

MODULE_VERSION(VERSION);
MODULE_AUTHOR("QingCloud Kernel Group <kernel_group@yunify.com>");

MODULE_DESCRIPTION(QBD_DESCRIPTION);
MODULE_LICENSE("GPL");
