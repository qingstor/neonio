#include <linux/module.h>
#include <linux/slab.h>
#include "qbd_queue.h"

int init_queue(struct queue *queue, int length)
{
	spin_lock_init(&queue->lock);
	queue->head = queue->tail = 0;
	queue->length = queue->space = length;
	queue->data = kmalloc(queue->length * sizeof(void *), GFP_KERNEL);
	if (queue->data == NULL)
		return -ENOMEM;
	return 0;
}
EXPORT_SYMBOL(init_queue);

void destroy_queue(struct queue *queue)
{
	kfree(queue->data);
	queue->data = NULL;
}
EXPORT_SYMBOL(destroy_queue);

int __enqueue(struct queue *queue, void *element)
{
	if (queue_is_full(queue))
		return -EAGAIN;

	queue->data[queue->tail] = element;
	queue->tail++;
	queue->tail %= queue->length;
	queue->space--;
	return 0;
}
EXPORT_SYMBOL(__enqueue);

void *__dequeue(struct queue *queue)
{
	void *t;
	if (queue_is_empty(queue))
		return NULL;

	t = queue->data[queue->head];
	queue->head++;
	queue->head %= queue->length;
	queue->space++;
	return t;
}
EXPORT_SYMBOL(__dequeue);
