#include <linux/kernel.h>
#include <linux/sysfs.h>
#include <linux/kobject.h>
#include <linux/device.h>
#include <linux/genhd.h>
#include <linux/vmalloc.h>
#include <linux/blkdev.h>

#include "qbd.h"
#include "qbd_sysfs.h"
#include "qbd_client.h"
#include "qbd_client_tcp.h"
#include "qbd_client_rdma.h"

static ssize_t qbd_status_show(struct device *dev, struct device_attribute *attr, char *buf)
{
	struct gendisk *disk = dev_to_disk(dev);
	struct qbd_device *qbd = disk_to_qbd(disk);
	bool suspend = false;
	char *str;

	if (blk_queue_stopped(disk->queue))
		suspend = true;

	if (suspend) {
		str = "suspended";
	} else {
		switch(qbd->vol->resume_type) {
		case QBD_IOC_RESUME_NORMAL_VOLUME:
			str = "normal";
			break;

		case QBD_IOC_RESUME_ERROR_VOLUME:
			str = "resume to error";
			break;

		case QBD_IOC_RESUME_DISCARD_VOLUME:
			str = "resume to discard";
			break;

		default:
			str = "unknown";
		}
	}
	sprintf(buf, "%s, %s\n", volume_status_str[qbd->vol->status], str);
	return strlen(buf);
}
static DEVICE_ATTR(status, 0444, qbd_status_show, NULL);

static ssize_t qbd_open_count_show(struct device *dev, struct device_attribute *attr, char *buf)
{
	struct gendisk *disk = dev_to_disk(dev);
	struct qbd_device *qbd = disk_to_qbd(disk);
	int count;
	spin_lock_irq(&qbd->lock);
	count = qbd->open_count;
	spin_unlock_irq(&qbd->lock);
	sprintf(buf, "%d\n", count);
	return strlen(buf);
}
static DEVICE_ATTR(open_count, 0444, qbd_open_count_show, NULL);

/*
 * Use volume name as serial
 */
static ssize_t qbd_serial_show(struct device *dev, struct device_attribute *attr, char *buf)
{
	struct gendisk *disk = dev_to_disk(dev);
	struct qbd_volume *vol = disk_to_qbd(disk)->vol;

	sprintf(buf, "%s%s%s\n",
		vol->name,
		vol->snap_name[0] == '\0' ? "" : "@",
		vol->snap_name[0] == '\0' ? "" : vol->snap_name);

	return strlen(buf);
}
static DEVICE_ATTR(serial, 0444, qbd_serial_show, NULL);

static ssize_t qbd_detailed_show(struct device *dev, struct device_attribute *attr, char *buf)
{
	struct gendisk *disk = dev_to_disk(dev);
	sprintf(buf, "%d\n", disk_to_qbd(disk)->detailed);
	return strlen(buf);
}
static ssize_t qbd_detailed_store(struct device *dev,
				  struct device_attribute *attr, const char *buf, size_t size)
{
	int detailed = 0;
	struct gendisk *disk = dev_to_disk(dev);
	if (kstrtoint(buf, 10, &detailed) < 0 || (detailed >> 1) != 0)
		return -EINVAL;
	disk_to_qbd(disk)->detailed = detailed;
	return size;
}
static DEVICE_ATTR(detailed, 0644, qbd_detailed_show, qbd_detailed_store);

static ssize_t qbd_warn_delay_show(struct device *dev, struct device_attribute *attr, char *buf)
{
	struct gendisk *disk = dev_to_disk(dev);
	sprintf(buf, "%d(ms)\n", disk_to_qbd(disk)->warn_delay);
	return strlen(buf);
}
static ssize_t qbd_warn_delay_store(struct device *dev,
				    struct device_attribute *attr, const char *buf, size_t size)
{
	int warn_delay = 0;
	struct gendisk *disk = dev_to_disk(dev);
	if (kstrtoint(buf, 10, &warn_delay) < 0 || warn_delay < 0)
		return -EINVAL;
	disk_to_qbd(disk)->warn_delay = warn_delay;
	return size;
}
static DEVICE_ATTR(warn_delay, 0644, qbd_warn_delay_show, qbd_warn_delay_store);

static ssize_t qbd_kernel_request_count_show(struct device *dev, struct device_attribute *attr, char *buf)
{
	struct gendisk *disk = dev_to_disk(dev);
	sprintf(buf, "%d\n", atomic_read(&disk_to_qbd(disk)->kernel_request_count));
	return strlen(buf);
}
static DEVICE_ATTR(kernel_request_count, 0444, qbd_kernel_request_count_show, NULL);

static ssize_t qbd_heartbeat_timeout_show(struct device *dev, struct device_attribute *attr, char *buf)
{
	struct gendisk *disk = dev_to_disk(dev);
	sprintf(buf, "%d\n", disk_to_qbd(disk)->vol->qbd->heartbeat_timeout);
	return strlen(buf);
}
static ssize_t qbd_heartbeat_timeout_store(struct device *dev, struct device_attribute *attr,
					   const char *buf, size_t size)
{
	int heartbeat_timeout = 0;
	struct gendisk *disk = dev_to_disk(dev);
	if (kstrtoint(buf, 10, &heartbeat_timeout) < 0 || heartbeat_timeout <= 0)
		return -EINVAL;
	disk_to_qbd(disk)->vol->qbd->heartbeat_timeout = heartbeat_timeout;
	return size;
}
static DEVICE_ATTR(heartbeat_timeout, 0644, qbd_heartbeat_timeout_show, qbd_heartbeat_timeout_store);

static ssize_t qbd_qos_setting_show(struct device *dev, struct device_attribute *attr, char *buf)
{
	struct gendisk *disk = dev_to_disk(dev);
	struct qbd_qos_info *qos =  &(disk_to_qbd(disk)->vol->qos);

	sprintf(buf, "%llu %llu %llu %llu\n",
		qos->iops, qos->bps, qos->burst_iops, qos->burst_bps);
	return strlen(buf);
}
static DEVICE_ATTR(qos_setting, 0644, qbd_qos_setting_show, NULL);

static ssize_t qbd_error_count_show(struct device *dev, struct device_attribute *attr, char *buf)
{
	struct gendisk *disk = dev_to_disk(dev);
	sprintf(buf, "%d\n", atomic_read(&(disk_to_qbd(disk)->error_count)));
	return strlen(buf);
}
static ssize_t qbd_error_count_store(struct device *dev, struct device_attribute *attr,
				     const char *buf, size_t size)
{
	struct gendisk *disk = dev_to_disk(dev);
	int i;
	if (kstrtoint(buf, 10, &i) < 0 || i != 0)
		return -EINVAL;
	atomic_set(&(disk_to_qbd(disk)->error_count), 0);
	return size;
}
static DEVICE_ATTR(error_count, 0644, qbd_error_count_show, qbd_error_count_store);

static struct qbd_delay_info default_delay_info_lists[] = {
	{
	.lrange = 0ULL,
	.rrange = 100ULL,
	},
	{
	.lrange = 100ULL,
	.rrange = 100000000ULL,
	},
	{
	.lrange = 100000000ULL,
	.rrange = QBD_DELAY_RANGE_NO_RBOUND,
	}
};

static inline void delay_range_init(struct qbd_delay_info *info, uint64_t lrange, uint64_t rrange)
{
	info->lrange = lrange;
	info->rrange = rrange;
	atomic64_set(&info->send_io_count, 0LL);
	atomic64_set(&info->recv_io_count, 0LL);
	atomic64_set(&info->finish_io_count, 0LL);
}

static int qbd_delay_range_add(struct qbd_device *qbd, uint64_t lrange, uint64_t rrange)
{
	struct qbd_delay_info *info, *new_info;
	struct list_head *delay_info_list = &qbd->delay_info_list;

	if (lrange >= rrange)
		return -EINVAL;

	new_info = kmalloc(sizeof(struct qbd_delay_info), GFP_KERNEL);
	if (!new_info) {
		return -ENOMEM;
	}

	write_lock(&qbd->delay_info_lock);
	list_for_each_entry(info, delay_info_list, node) {
		if (info->lrange == lrange && info->rrange == rrange) {
			write_unlock(&qbd->delay_info_lock);
			kfree(new_info);
			return -EEXIST;
		}
	}
	delay_range_init(new_info, lrange, rrange);
	list_add_tail(&new_info->node, delay_info_list);
	write_unlock(&qbd->delay_info_lock);
	return 0;
}

static int qbd_delay_range_remove(struct qbd_device *qbd, uint64_t lrange, uint64_t rrange)
{
	struct qbd_delay_info *info, *tmp_info;
	int ret = -EINVAL;

	write_lock(&qbd->delay_info_lock);
	list_for_each_entry_safe(info, tmp_info, &qbd->delay_info_list, node) {
		if (info->lrange == lrange && info->rrange == rrange) {
			list_del(&info->node);
			kfree(info);
			ret = 0;
			break;
		}
	}
	write_unlock(&qbd->delay_info_lock);
	return ret;
}

static void delay_info_clear(struct qbd_device *qbd)
{
	struct qbd_delay_info *info;
	struct list_head *delay_info_list = &qbd->delay_info_list;

	write_lock(&qbd->delay_info_lock);
	while(!list_empty(delay_info_list)) {
		info = list_first_entry(delay_info_list, struct qbd_delay_info, node);
		list_del(&info->node);
		kfree(info);
	}
	write_unlock(&qbd->delay_info_lock);
}

int qbd_delay_info_init(struct qbd_device *qbd)
{
	int ret, i;

	INIT_LIST_HEAD(&qbd->delay_info_list);
	rwlock_init(&qbd->delay_info_lock);

	for (i = 0; i < ARRAY_SIZE(default_delay_info_lists); i++) {
		ret = qbd_delay_range_add(qbd, default_delay_info_lists[i].lrange,
					  default_delay_info_lists[i].rrange);
		if (ret)
			goto clear_out;
	}

	return 0;
clear_out:
	delay_info_clear(qbd);
	return ret;
}

void qbd_delay_info_destroy(struct qbd_device *qbd)
{
	if (qbd)
		delay_info_clear(qbd);
}

#define QBD_DELAY_INFO_SUM(__name)	\
void qbd_delay_##__name##_summarize(struct qbd_device *qbd, uint64_t delay)\
{									   \
	struct qbd_delay_info *info;					   \
	struct list_head *delay_info_list = &qbd->delay_info_list;	   \
									   \
	read_lock(&qbd->delay_info_lock);				   \
	list_for_each_entry(info, delay_info_list, node) {		   \
		if (delay >= info->lrange && delay <= info->rrange) 	   \
			atomic64_inc(&info->__name##_io_count);		   \
	}								   \
	read_unlock(&qbd->delay_info_lock);				   \
}
QBD_DELAY_INFO_SUM(send) /* qbd_delay_send_summarize() */
QBD_DELAY_INFO_SUM(recv) /* qbd_delay_recv_summarize() */
QBD_DELAY_INFO_SUM(finish) /* qbd_delay_finish_summarize() */

static ssize_t qbd_delay_info_show(struct device *dev, struct device_attribute *attr, char *buf)
{
	struct gendisk *disk = dev_to_disk(dev);
	struct qbd_device *qbd = disk_to_qbd(disk);
	struct list_head *delay_info_list = &qbd->delay_info_list;
	struct qbd_delay_info *info;
	char str_buf[32];
	char *tmp = buf;

	read_lock(&qbd->delay_info_lock);
	if (!list_empty(delay_info_list)) {
		tmp += sprintf(tmp, "[%s] delay info(ns):\n", qbd->devname);
		tmp += sprintf(tmp, "%-22s|%20s|%20s|%25s|\n", "ranges", "start - send(qbd io)",
						"send - recv(qbd io)", "start - finish(kern io)");

		list_for_each_entry(info, delay_info_list, node) {
			if (info->rrange != QBD_DELAY_RANGE_NO_RBOUND)
				sprintf(str_buf, "%llu - %llu", info->lrange, info->rrange);
			else
				sprintf(str_buf, "%llu - ~", info->lrange);

			tmp += sprintf(tmp, "%-22s", str_buf);
			tmp += sprintf(tmp, "|%20llu|%20llu|%25llu|\n",
						(u64)atomic64_read(&info->send_io_count),
						(u64)atomic64_read(&info->recv_io_count),
						(u64)atomic64_read(&info->finish_io_count));
		}
	}
	read_unlock(&qbd->delay_info_lock);

	return strlen(buf);
}

static inline int parse_delay_range_num(const char *str, char *opt,
					uint64_t *lrange, uint64_t *rrange)
{
	uint64_t lv, rv;
	char op, tilde;
	int ret;

	ret = sscanf(str, "%c %llu , %llu ", &op, &lv , &rv);
	if (ret == 3 && (op == '+' || op == '-')) {
		*opt = op;
		*lrange = lv;
		*rrange = rv;
		return 0;
	}

	ret = sscanf(str, "%c %llu , %c", &op, &lv, &tilde);
	if (ret == 3 && (op == '+' || op == '-') && tilde == '~') {
		*opt = op;
		*lrange = lv;
		*rrange = QBD_DELAY_RANGE_NO_RBOUND;
		return 0;
	}

	return -EINVAL;
}
static ssize_t qbd_delay_info_store(struct device *dev, struct device_attribute *attr,
				    const char *buf, size_t size)
{
	struct gendisk *disk = dev_to_disk(dev);
	struct qbd_device *qbd = disk_to_qbd(disk);
	uint64_t lrange, rrange;
	char opt;
	int ret;

	ret = parse_delay_range_num(buf, &opt, &lrange, &rrange);
	if(!ret) {
		if (opt == '+')
			ret = qbd_delay_range_add(qbd, lrange, rrange);
		else if (opt == '-')
			ret = qbd_delay_range_remove(qbd, lrange, rrange);
	}
	return (ret == 0 ? size : -EINVAL);
}
static DEVICE_ATTR(delay_info, 0644, qbd_delay_info_show, qbd_delay_info_store);

static ssize_t qbd_encrypted_show(struct device *dev, struct device_attribute *attr, char *buf)
{
	struct gendisk *disk = dev_to_disk(dev);
	sprintf(buf, "%s\n", disk_to_qbd(disk)->vol->keyid[0] != '\0' ? "yes" : "no");
	return strlen(buf);
}
static DEVICE_ATTR(encrypted, 0644, qbd_encrypted_show, NULL);

static ssize_t qbd_iotask_stat_show(struct device *dev, struct device_attribute *attr, char *buf)
{
	struct gendisk *disk = dev_to_disk(dev);
	struct qbd_volume *vol = disk_to_qbd(disk)->vol;

	if (vol->type == RDMA) {
		struct qbd_client_rdma *client = (struct qbd_client_rdma *)vol->client;
		struct qbd_iotask_pool_rdma *pool = &client->iotask_pool;
		sprintf(buf, "pool_size:%d  alloced:%d  sending:%d\n",
			pool->size,
			pool->nr_alloced,
			atomic_read(&client->sending_iotask_count));
	} else {
		struct qbd_client_tcp *client = (struct qbd_client_tcp *)vol->client;
		struct qbd_iotask_pool_tcp *pool = &client->iotask_pool;
		sprintf(buf, "pool_size:%d  alloced:%d  sending:%d\n",
			pool->size,
			pool->nr_alloced,
			atomic_read(&client->sending_iotask_count));
	}
	return strlen(buf);
}
static DEVICE_ATTR(iotask_stat, 0444, qbd_iotask_stat_show, NULL);

static ssize_t qbd_wio_range_stat_show(struct device *dev, struct device_attribute *attr, char *buf)
{
	struct gendisk *disk = dev_to_disk(dev);
	struct qbd_device *qbd = disk_to_qbd(disk);

	sprintf(buf, "%llu %llu %llu %llu\n",
		     qbd->read_total, qbd->wio_range_read_hits,
                     qbd->write_total, qbd->wio_range_write_hits);

	return strlen(buf);
}
static DEVICE_ATTR(wio_range_stat, 0444, qbd_wio_range_stat_show, NULL);

static struct attribute *qbd_attrs[] = {
	&dev_attr_status.attr,
	&dev_attr_open_count.attr,
	&dev_attr_serial.attr,
	&dev_attr_detailed.attr,
	&dev_attr_warn_delay.attr,
	&dev_attr_kernel_request_count.attr,
	&dev_attr_heartbeat_timeout.attr,
	&dev_attr_qos_setting.attr,
	&dev_attr_error_count.attr,
	&dev_attr_delay_info.attr,
	&dev_attr_encrypted.attr,
	&dev_attr_iotask_stat.attr,
	&dev_attr_wio_range_stat.attr,
	NULL
};

static struct attribute_group qbd_attr_group = {
	.attrs = qbd_attrs,
};

const struct attribute_group *qbd_attr_groups[] = {
	&qbd_attr_group,
	NULL
};

static ssize_t qbd_shard_show(struct device *dev, struct device_attribute *attr, char *buf)
{
	struct gendisk *disk = dev_to_disk(dev);
	struct qbd_volume *vol = disk_to_qbd(disk)->vol;
	struct qbd_conn_pool *conn_pool;
	char *tmp = buf;
	int shard_i;

	if (vol->type == RDMA)
		conn_pool = &((struct qbd_client_rdma *)vol->client)->conn_pool;
	else
		conn_pool = &((struct qbd_client_tcp *)vol->client)->conn_pool;

	read_lock(&vol->qbd->sysfs_lock);
	if (kstrtoint(attr->attr.name, 10, &shard_i) == 0 && shard_i >= 0 && shard_i < vol->shard_count) {
		int ip_i;
		struct qbd_client_shard *shard_p = &vol->shards[shard_i];
		struct qbd_shard_stat *stat_p = &vol->qbd->shard_stats[shard_i];

		/* print shard ips */
		tmp += sprintf(tmp, "Shard[%d] information([+]:connected [-]:closed [@]:closing [x]:failed [?]:unknown):\n", shard_i);
		for (ip_i = 0; ip_i < 16; ip_i++) {
			struct sockaddr_in *addr = &shard_p->ips[ip_i];

			if (addr->sin_port == 0)
				break;
			tmp += sprintf(tmp, "IP[%d]:%pI4:%hu [%c]\n",
					ip_i, &addr->sin_addr, ntohs(addr->sin_port),
					qbd_conn_status_to_char(conn_pool, addr));
		}

		/* print shard stat */
		tmp += sprintf(tmp, "IO stat: Bytes_read IO_read Bytes_write IO_write\n"
				    "         %-12llu %-12llu %-12llu %-12llu\n",
				    stat_p->bytes[SHARD_STAT_READ], stat_p->ios[SHARD_STAT_READ],
				    stat_p->bytes[SHARD_STAT_WRITE], stat_p->ios[SHARD_STAT_WRITE]);
	}
	else
		sprintf(buf, "Invalid shard[%d],the range of shard is 0-%d.\n", shard_i, vol->shard_count - 1);
	read_unlock(&vol->qbd->sysfs_lock);

	return strlen(buf);
}

/* calculate the number of bytes from 0-num strings*/
static int get_bytes(int num)
{
	int i, tmp, count;
	for (i = 0, tmp = 10; tmp <= num; i++)
		tmp *= 10;
	tmp = (num - npow(10, i) + 1) * (i + 1);
	count = npow(10, i) * i;
	while(i > 1)
		count -= npow(10, --i);
	return count + tmp + (num + 1);
}
static char *qbd_shard_names_create(int count)
{
	char *names = NULL;
	int i, tmp, size;

	size = get_bytes(count - 1);
	names = vmalloc(size);
	if (!names)
		return NULL;
	for (i = 0, tmp = 0; i < count; i++) {
		tmp += sprintf(&names[tmp], "%d", i) + 1;
	}
	return names;
}

static int qbd_shard_attrs_group_create(char *names, int count, struct attribute_group **attrs_group)
{
	struct device_attribute *pdev_attrs = NULL;
	struct attribute_group *p_attrs_group = NULL;
	struct attribute **p_attrs = NULL;
	int err = -ENOMEM;
	int i;

	p_attrs = vmalloc(sizeof(struct attribute*) * (count + 1) + sizeof(struct device_attribute) * count);
	if (!p_attrs)
		goto err_out;

	pdev_attrs = (struct device_attribute*)((char *)p_attrs + sizeof(struct attribute*) * (count + 1));

	for (i = 0; *names != '\0' && i < count; i++) {
		pdev_attrs[i].attr.name = names;
		pdev_attrs[i].attr.mode = 0644;
		pdev_attrs[i].show = qbd_shard_show;
		pdev_attrs[i].store = NULL;
		p_attrs[i] = &pdev_attrs[i].attr;
		while(*(names++) != '\0');
	}
	p_attrs[i] = NULL;

	p_attrs_group = kmalloc(sizeof(struct attribute_group), GFP_KERNEL);
	if (!p_attrs_group)
		goto err_free_attrs;

	memset(p_attrs_group, 0, sizeof(struct attribute_group));
	p_attrs_group->name = "shards";
	p_attrs_group->attrs = p_attrs;

	*attrs_group = p_attrs_group;
	return 0;

err_free_attrs:
	vfree(p_attrs);
err_out:
	return err;
}

int qbd_shards_group_create(struct qbd_device *qbd)
{
	struct qbd_volume *vol = qbd->vol;
	struct kobject *kobj = &disk_to_dev(qbd->disk)->kobj;
	struct attribute_group *attrs_group = NULL;
	char *names = NULL;
	int err = -ENOMEM;

	names = qbd_shard_names_create(vol->shard_count);
	if(!names)
		goto err_out;

	err = qbd_shard_attrs_group_create(names, vol->shard_count, &attrs_group);
	if (err)
		goto err_free_names;

	err = sysfs_create_group(kobj, attrs_group);
	if (err)
		goto err_free_attrs_group;

	qbd->sysfs_shards = kmalloc(sizeof(struct qbd_sysfs_shards), GFP_KERNEL);
	if (!qbd->sysfs_shards) {
		err = -ENOMEM;
		goto err_remove_sysfs_group;
	}
	qbd->sysfs_shards->dir = kobj;
	qbd->sysfs_shards->names = names;
	qbd->sysfs_shards->attrs_group = attrs_group;

	return 0;

err_remove_sysfs_group:
	sysfs_remove_group(kobj, attrs_group);
err_free_attrs_group:
	vfree(attrs_group->attrs);
	kfree(attrs_group);
err_free_names:
	vfree(names);
err_out:
	return err;
}
void qbd_shards_group_destroy(struct qbd_device *qbd)
{
	if (qbd && qbd->sysfs_shards) {
		sysfs_remove_group(qbd->sysfs_shards->dir, qbd->sysfs_shards->attrs_group);
		vfree(qbd->sysfs_shards->attrs_group->attrs);
		kfree(qbd->sysfs_shards->attrs_group);
		vfree(qbd->sysfs_shards->names);
		kfree(qbd->sysfs_shards);
		qbd->sysfs_shards = NULL;
	}
}
