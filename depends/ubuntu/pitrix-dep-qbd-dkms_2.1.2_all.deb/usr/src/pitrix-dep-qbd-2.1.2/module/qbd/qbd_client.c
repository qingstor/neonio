#include "qbd.h"
#include "qbd_sysfs.h"
#include "qbd_message.h"
#include "qbd_client.h"
#include "qbd_hashtable.h"

static LIST_HEAD(qbd_client_list);	/* qbd client/protocol list, should protected by ctl_mutex */

const char *volume_status_str[] = {
	[VOLUME_STATUS_CLOSED]		= "closed",
	[VOLUME_STATUS_OPENED]		= "opened",
	[VOLUME_STATUS_RESETTING]	= "resetting",
	[VOLUME_STATUS_ERROR]		= "error",
};

int qbd_client_register(struct qbd_client_operations *client)
{
	struct qbd_client_operations *cli;
	mutex_lock(&ctl_mutex);
	list_for_each_entry(cli, &qbd_client_list, entry) {
		if (cli->type == client->type) {
			mutex_unlock(&ctl_mutex);
			return -EEXIST;
		}
	}
	list_add_tail(&client->entry, &qbd_client_list);
	mutex_unlock(&ctl_mutex);
	return 0;
}
EXPORT_SYMBOL(qbd_client_register);

int qbd_client_unregister(struct qbd_client_operations *client)
{
	/* client->entry in the qbd_client_list, hold
	 * ctl_mutex avoid other use it at this time
	 */
	mutex_lock(&ctl_mutex);
	list_del(&client->entry);
	mutex_unlock(&ctl_mutex);
	return 0;
}
EXPORT_SYMBOL(qbd_client_unregister);

struct qbd_client_operations *qbd_client_ops_get(enum transport_type type)
{
	struct qbd_client_operations *cli;
	mutex_lock(&ctl_mutex);
	list_for_each_entry(cli, &qbd_client_list, entry) {
		if (cli->type == type) {
			mutex_unlock(&ctl_mutex);
			return cli;
		}
	}
	mutex_unlock(&ctl_mutex);
	return NULL;
}

void qbd_check_ready_timeout(struct qb_request *qbr)
{
	struct kb_request *kbr = qbr->kbr;
	struct qbd_device *qbd = kbr->qbd;
	if (qbd->warn_delay) {
		qbr->ts_ready = get_now_nsec();
		if (qbr->ts_ready - kbr->ts_start > 1000000LL * qbd->warn_delay)
			qbd_dev_info_ratelimited(qbd, "[%s] %s aio[%llu:%d] current[%llu:%d] delayed %llums in qbd_queue, "
						      "left io_count:%d, uio_count:%d",
						 qbd->devname,
						 QBDAIOStr[qbr->cmd], kbr->sector_num,
						 kbr->nb_sectors, qbr->curr_sector * QBD_PER_BDRV,
						 qbr->nb_sectors * QBD_PER_BDRV,
						 (qbr->ts_ready - kbr->ts_start) / 1000000, kbr->io_count, kbr->uio_count);
	}
}

void qbd_check_send_timeout(struct qb_request *qbr)
{
	struct kb_request *kbr = qbr->kbr;
	struct qbd_device *qbd = kbr->qbd;
	if (qbd->warn_delay) {
		qbr->ts_send = get_now_nsec();
		if (qbr->ts_send - kbr->ts_start > 1000000LL * qbd->warn_delay)
			qbd_dev_info_ratelimited(qbd, "[%s] %s aio[%llu:%d] current[%llu:%d] delayed %llums before send to store, "
						      "left io_count:%d, uio_count:%d",
						 qbd->devname,
						 QBDAIOStr[qbr->cmd], kbr->sector_num,
						 kbr->nb_sectors, qbr->curr_sector * QBD_PER_BDRV,
						 qbr->nb_sectors * QBD_PER_BDRV,
						 (qbr->ts_send - kbr->ts_start) / 1000000, kbr->io_count, kbr->uio_count);
	}

	qbd_delay_send_summarize(qbd, qbr->ts_send - kbr->ts_start);
}
EXPORT_SYMBOL(qbd_check_send_timeout);

void qbd_check_recv_timeout(struct qb_request *qbr, bool aligned)
{
	struct kb_request *kbr = qbr->kbr;
	struct qbd_device *qbd = kbr->qbd;
	if (qbd->warn_delay) {
		qbr->ts_recv = get_now_nsec();
		if (qbr->ts_recv - qbr->ts_send > 1000000LL * qbd->warn_delay)
			qbd_dev_info_ratelimited(qbd, "[%s] %s aio[%llu:%d] current[%llu:%d] delayed %llums since send out, "
						      "left io_count:%d, uio_count:%d",
						 qbd->devname,
						 QBDAIOStr[qbr->cmd], kbr->sector_num,
						 kbr->nb_sectors, qbr->curr_sector * QBD_PER_BDRV,
						 qbr->nb_sectors * QBD_PER_BDRV,
						 (qbr->ts_recv - qbr->ts_send) / 1000000,
						 aligned ? (kbr->io_count - 1) : kbr->io_count,
						 aligned ? kbr->uio_count : (kbr->uio_count - 1));
	}

	qbd_delay_recv_summarize(qbd, qbr->ts_recv - qbr->ts_send);
}

void qbd_check_finish_timeout(struct kb_request *kbr)
{
	struct qbd_device *qbd = kbr->qbd;

	if (qbd->warn_delay) {
		kbr->ts_finish = get_now_nsec();
		if (kbr->ts_finish - kbr->ts_start > 1000000LL * qbd->warn_delay)
			qbd_dev_info_ratelimited(qbd, "[%s] %s aio[%llu:%d] delayed finish in %llums",
						 qbd->devname, QBDAIOStr[kbr->cmd],
						 kbr->sector_num, kbr->nb_sectors,
						 (kbr->ts_finish - kbr->ts_start) / 1000000);
	}

	qbd_delay_finish_summarize(qbd, kbr->ts_finish - kbr->ts_start);
}

bool qbd_check_kernel_io_timeout(uint64_t start)
{
	if (start == 0 || qbd_kernel_io_timeout == 0)
		return false;

	if (get_now_nsec() - start > qbd_kernel_io_timeout * NSEC_PER_SEC)
		return true;

	return false;
}
EXPORT_SYMBOL(qbd_check_kernel_io_timeout);
