#include "qbd.h"
#include "qbd_conn.h"
#include "qbd_client.h"
#include "qbd_message.h"
#include "qbd_hashtable.h"

const char *qbd_conn_status_char = "?+@-x";

static struct qbd_conn *alloc_conn(struct qbd_volume *vol)
{
	struct qbd_conn *conn = kmalloc(sizeof(struct qbd_conn), GFP_NOIO);
	if (conn == NULL) {
		qbd_err("[%s] kmalloc qbd_conn failed", vol->qbd->devname);
		return NULL;
	}
	return conn;
}

static struct qbd_conn *get_conn_from_pool(struct qbd_conn_pool *pool, struct qbd_client_shard *shard, int shard_index)
{
	int rc = 0;
	struct qbd_conn *conn;
	struct sockaddr_in *addr = &shard->ips[shard->current_ip];

	conn = sht_find(pool->conn_table, addr);
	if (likely(conn != NULL))
		goto out_conn_shard;

	conn = alloc_conn(pool->vol);
	if (conn == NULL) {
		qbd_err("[%s] alloc qbd_conn failed", pool->vol->qbd->devname);
		return NULL;
	}
	qbd_info("[%s] connect to IP[%d] for shard_index[%d] %pI4:%hu ...",
		 pool->vol->qbd->devname,
		 shard->current_ip,
		 shard_index,
		 &addr->sin_addr,
		 ntohs(addr->sin_port));

	rc = qbd_init_conn(conn, pool->vol, addr);
	if (rc) {
		qbd_err("[%s] connect to IP[%d] for shard_index[%d] %pI4:%hu failed",
			pool->vol->qbd->devname,
			shard->current_ip,
			shard_index,
			&addr->sin_addr,
			ntohs(addr->sin_port));
		kfree(conn);
		return NULL;
	}
	if (sht_insert(pool->conn_table, conn)) {
		qbd_err("[%s] sht_insert IP[%d] for shard_index[%d] %pI4:%hu failed",
			pool->vol->qbd->devname,
			shard->current_ip,
			shard_index,
			&addr->sin_addr,
			ntohs(addr->sin_port));
		_qbd_release_conn(conn);
		return NULL;
	}
	qbd_info("[%s] connect to IP[%d] for shard_index[%d] %pI4:%hu succeed, conn=%px",
		 pool->vol->qbd->devname,
		 shard->current_ip,
		 shard_index,
		 &addr->sin_addr,
		 ntohs(addr->sin_port),
		 conn);
out_conn_shard:
	conn->shard = shard_index;
	return conn;
}

int init_conn_pool(struct qbd_conn_pool *pool, struct qbd_volume *vol)
{
	uint32_t pool_size = 1 << fls(vol->size / QBD_SHARD_SIZE);
	pool->conn_table = sht_init(pool_size);
	if (pool->conn_table == NULL)
		return -1;

	pool->vol = vol;
	return 0;
}
EXPORT_SYMBOL(init_conn_pool);

void release_conn_pool(struct qbd_conn_pool *pool)
{
	sht_destroy(pool->conn_table);
}
EXPORT_SYMBOL(release_conn_pool);

void cleanup_conn_pool(struct qbd_conn_pool *pool)
{
	sht_cleanup(pool->conn_table);
}
EXPORT_SYMBOL(cleanup_conn_pool);

int qbd_init_conn(struct qbd_conn *conn, struct qbd_volume *vol, struct sockaddr_in *addr)
{
	if (vol->cops->init_conn)
		return vol->cops->init_conn(conn, vol, addr);
	return -EINVAL;
}

void qbd_release_conn(struct qbd_conn *conn) {
	if (conn && conn->vol && conn->vol->cops && conn->vol->cops->release_conn)
		conn->vol->cops->release_conn(conn);
}

void _qbd_release_conn(struct qbd_conn *conn) {
	if (conn && conn->vol && conn->vol->cops && conn->vol->cops->_release_conn)
		conn->vol->cops->_release_conn(conn);
}

/*
 * Get connection with shard_index from conn_pool,
 * connections are shared by shards on same node.
 */
struct qbd_conn *qbd_get_shard_conn(struct qbd_volume *vol, struct qbd_conn_pool *conn_pool, int shard_index)
{
	struct qbd_conn *conn = NULL;
	struct qbd_client_shard *shard;

	BUG_ON(shard_index < 0 || shard_index >= vol->shard_count);

	if (unlikely(vol->shards == NULL)) {
		qbd_dev_err_ratelimited(vol->qbd, "[%s] vol->shards get NULL pointer, %s failed",
					vol->qbd->devname,
					__func__);
		return NULL;
	}
	shard = &vol->shards[shard_index];

	while (shard->current_ip < ARRAY_SIZE(shard->ips)) {
		struct sockaddr_in *addr = &shard->ips[shard->current_ip];
		if (addr->sin_port == 0)
			break;

		conn = get_conn_from_pool(conn_pool, shard, shard_index);
		if (conn != NULL)
			return conn;
		++shard->current_ip;
		if (shard->current_ip < ARRAY_SIZE(shard->ips)
		    && shard->ips[shard->current_ip].sin_port != 0) {
			qbd_err("[%s] connect to IP[%d] for shard_index[%d] failed, try IP[%d]:%pI4:%hu",
				vol->qbd->devname,
				shard->current_ip - 1,
				shard_index,
				shard->current_ip,
				&shard->ips[shard->current_ip].sin_addr,
				ntohs(shard->ips[shard->current_ip].sin_port));
		}
	}
	qbd_dev_err_ratelimited(vol->qbd, "[%s] no usable IP[%d] for shard_index[%d], need reopen volume",
				vol->qbd->devname,
				shard->current_ip,
				shard_index);
	return NULL;
}
EXPORT_SYMBOL(qbd_get_shard_conn);

char qbd_conn_status_to_char(struct qbd_conn_pool *pool, struct sockaddr_in *addr)
{
	struct qbd_conn *conn = sht_find(pool->conn_table, addr);
	if (conn && conn->status >= CONN_STATUS_UNKNOWN && conn->status < CONN_STATUS_LAST) {
		return qbd_conn_status_char[conn->status];
	}
	return '?';
}
